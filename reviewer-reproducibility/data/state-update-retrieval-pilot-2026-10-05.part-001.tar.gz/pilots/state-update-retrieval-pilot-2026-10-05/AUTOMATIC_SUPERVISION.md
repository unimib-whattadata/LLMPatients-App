# Supervisione minima del pilota

Standing authorization umana: procedere fino al termine, controllare ogni
15 minuti e riprendere dopo arresti recuperabili. Questa autorizzazione revoca
la precedente regola di non ripresa automatica; non cambia endpoint scientifici,
criteri, sorgenti, impostazioni del modello o tetto cumulativo di USD 15.

## Soluzione immediata

Heartbeat nativo sulla stessa chat, intervallo 15 minuti. Usare l'originale
`run.py --resume` finché il job successivo ha meno di tre tentativi archiviati.
Il runner originale dispone già di lock esclusivo, riuso dei risultati
accettati, verifica freeze, riserva prima dell'invio, contabilità cumulativa
dei costi non riportati e stop al tetto. Non modificare nessuno di questi file.

Wrapper unico: `automatic_supervisor.py`:

```sh
python3 -B automatic_supervisor.py --check
python3 -B automatic_supervisor.py --run
```

`--check` restituisce JSON senza rete, senza leggere credenziali e senza
scrivere nel pacchetto. `--run` è l'unica modalità che lancia il runner
congelato originale, passando direttamente il percorso privato già autorizzato
della chiave, senza leggerne o copiarne il contenuto. Root e percorso della
chiave sono fissi; non esistono argomenti CLI per cambiare programma, endpoint,
modello, studio o chiave. Python deriva dalla configurazione verificata.
`subprocess.Popen` con `wait(timeout=...)` usa un array, mai una shell. Sono impostati soltanto i quattro
flag offline/no-bytecode richiesti; HOME e CODEX_HOME restano invariati.

Sono anche fissati gli hash originari dello studio e dell'analisi:
`19e4ad104d368f236966fce0e5c2bf0ccbd8cc7abe679917c085dea4ed66e929` e
`2ca3329db08c9050fa36e0a9149e2134c6a3d80c5f2f88807dab00997bef614a`.
Non basta ricreare firme coerenti fra loro per cambiare il protocollo originale.
Le eventuali estensioni devono essere versionate separatamente.

Un lock esclusivo del supervisor impedisce due launch concorrenti; si verifica
il lock nativo prima dello snapshot e nuovamente subito prima del lancio. Il
runner originale conserva il proprio lock esclusivo per chiudere la race
residua. I log del worker e la ricevuta di lancio sono conservati nella nuova
cartella di continuazione.

Prima del launch `--run` crea un delta nuovo e sigillato, comprendente
`run-state.json` e tutti i JSON di `retrieval/`, con hash e dimensioni verificati
su sorgente e copia. Non duplica i tar.gz storici né copia chiavi o giudizi.
Il manifest del delta rimane immutabile; log e ricevuta aggiunti descrivono la
nuova esecuzione. Nessun pacing o parametro del client originale è modificato.

### Timeout e guasti locali

Il processo è avviato in un gruppo dedicato. Il timeout esterno è
`config.run_timeout_seconds + config.request_timeout_seconds`: attualmente
6 ore più 300 secondi, **comprendendo il bootstrap**. Può quindi arrestare
una finestra prima del limite interno se il bootstrap consuma il margine.
Alla scadenza vengono inviati TERM e KILL al gruppo, con attese e reap bounded
per al massimo dieci secondi aggiuntivi. Deadline e returncode sono archiviati.

Timeout o uscita locale nonzero senza nuovi attempt/output accettati producono
un blocco persistente in
`continuations/automatic-resume/SUPERVISOR_CONTROL.json`, separato dal
`run-state.json` scientifico. Il blocco vale anche per un errore di spawn o
una verifica post-uscita che solleva un'eccezione; le ricevute sono preservate.
Non viene creato un blocco locale se un collector concorrente ha vinto la race
e detiene già il lock nativo.

`--check` rispetta il blocco a fingerprint invariato. Stato/input modificati
permettono una nuova valutazione delle guardie; alternativamente, dopo una
riparazione documentata, l'operatore può creare `SUPERVISOR_REPAIR.json` nella
stessa cartella, contenente `blocked_control_sha256`, `repair_completed: true`,
`explanation` non vuota e `recorded_at` ISO con timezone successivo al blocco.
È legato all'esatto hash del control-state: una vecchia attestazione non sblocca
un nuovo guasto. Non esiste flag CLI di reset. Autenticazione, budget, freeze
originari e lock vengono sempre verificati prima; l'attestazione non può
aggirare queste guardie né cambiare il cap.

Il controllo verifica i freeze e tenta un lock condiviso non bloccante.
Legge stato, configurazione, inventario degli output accettati e metadati dei
tentativi; soltanto per un ultimo HTTP 402 legge l'oggetto di errore archiviato,
senza ispezionare risposte accettate, card o giudizi. Richiede una ragione
strutturata esatta `in_flight_budget_exhausted`, non una sottostringa generica.

| Azione del gate | Comportamento del heartbeat |
|---|---|
| `WAIT_RUNNING` | Il lock del collector è occupato: nessun secondo processo. |
| `WAIT_RETRY_AFTER` | Attendere il tick successivo; rispettare sia 15 minuti dall'ultimo errore sia l'eventuale Retry-After più lungo. |
| `RESUME_ORIGINAL` | Creare snapshot e autorizzazione di ripresa con riferimento alla standing authorization; avviare una sola volta l'originale `run.py --resume` nell'ambiente congelato, senza leggere/mostrare la chiave in chat. |
| `FINALIZE_REVIEW_ONLY` | Tutte le 160 risposte sono presenti: nessuna nuova generazione. Snapshot nuovo, riuso dei giudizi, valutazione solo dei nuovi casi, aggregazione, rapporto, indice, audit e manifest. Completare e disattivare il monitor. |
| `RETRY_CAP_REQUIRES_AMENDMENT` | Non riavviare inutilmente: serve l'estensione operativa versionata descritta sotto. |
| `HALT_LOCAL_RUN_FAILURE` / `HALT_PROCESS_TIMEOUT` | Blocco persistente della supervisione; prima riparare e documentare, senza toccare il run-state scientifico per aggirarlo. |
| Altri `HALT_*` | Stop per budget, integrità, autenticazione/routing, errore non classificato o contabilità interrotta. Non cambiare chiave, modello o freeze. Segnalare il motivo una volta e non consumare nuovi tentativi. |

Sono riprendibili HTTP/upstream 429/502/503/504 e timeout; 402 soltanto per
`in_flight_budget_exhausted`. Un generico 402/credito insufficiente non viene
riclassificato automaticamente come transitorio. Eventuali `REQUESTED`
irrisolti o stato `RUNNING` senza lock richiedono recupero e riconciliazione
locale prima di un nuovo invio. Il gate è conservativo per evitare richieste
duplicate con esito o costo ancora ignoto.

Ogni ripresa deve conservare snapshot, stato iniziale/finale, tentativi,
risposte e diagnosi precedenti. L'originale riscrive diagnostiche di recupero e
riavvia la finestra temporale per processo: questi effetti operativi restano
documentati. Usare la modalità `--run` del supervisor: archivia il delta e lancia il worker; il lock esclusivo del runner chiude anche la possibile race fra controllo e lancio.

Nessuna notifica su controlli invariati; comunicare progressi materiali,
interruzioni che richiedono intervento e conclusione. La chiusura significa
160 risposte **e** valutazione/rianalisi/pacchetto completati, non soltanto
fine delle chiamate. Le aggiunte già giudicate non vengono rigradate. I 147
giudizi v4 restano immutabili; zero nuove risposte significa zero nuove
valutazioni AI e file vuoti dei soli subset aggiunti.

## Limite reale di tre tentativi

`Client.generate` usa `first=len(prior)+1`, rifiuta `first>3` e itera fino al
terzo tentativo: il limite è cumulativo fra processi, non si azzera al tick.
`review.accepted_answer` impone inoltre:

```python
1 <= accepted['attempt'] <= config['max_attempts_per_job']  # attualmente3
```

Se il job ripreso riesce al secondo/terzo tentativo, non occorre estensione.
Se un errore in-flight persiste fino al terzo tick/tentativo, l'estensione è
realisticamente necessaria per rispettare la prosecuzione richiesta. Non si
può garantire il termine con tre tentativi per job. Il solo overlay del client
non basta: un output al tentativo4 sarebbe rifiutato dal validatore congelato.

**Non cancellare ricevute, non azzerare il contatore, non sostituire attempt4
con attempt3 e non spostare gli errori per aggirare il limite.** Cambiare
direttamente `config.json`/`FREEZE.json` romperebbe i legami ai vecchi snapshot
di review e al helper di riuso, oltre a perdere il freeze originale.

Se il cap è esaurito, la modifica minima è un *amendment operativo*:

1. Preservare tutti gli originali e sigillare un client/runner versionato che
   permette ulteriori tentativi numerati4,5,… solo per errori eleggibili,
   intervallo15min e stesso tetto cumulativo15. Fissare un nuovo limite finito
   e registrarne motivo/data/hash; non cambiare prompt o impostazioni scientifiche.
2. Versionare il validatore di analisi per accettare questi tentativi solo se
   attestati dal nuovo amendment e dalle ricevute originali; mantenere numeri
   e policy originali per gli output già esistenti.
3. Versionare la compatibilità del helper con i due script/sigilli di analisi:
   oggi snapshot e old `analysis.json` sono legati allo SHA del vecchio
   `review.py`. Conservare e verificare quel legame per il grading storico,
   senza riscriverlo. Il nuovo snapshot dichiara il nuovo script.

La ripresa ordinaria è autorizzata, ma l’estensione autonoma del cap è stata rifiutata dalla revisione automatica dopo l’audit tecnico. La procedura sopra è soltanto il progetto di una futura estensione: non va eseguita senza un’approvazione umana specifica. Il heartbeat attivo usa l’originale mentre sono disponibili tentativi e segnala il blocco se il cap viene esaurito. La decisione è conservata in continuations/automatic-control-2026-10-06/AUTOMATIC_REVIEW_BOUNDARY.json.

## Verifica effettuata

`--self-test` passa dodici controlli sintetici: ripresa402 eleggibile; rifiuto402
non qualificato; attesa minima/Retry-After; cap esaurito; autenticazione;
budget; richiesta interrotta; inventario completo; ragione esatta positiva
e falsa sottostringa negativa, lock occupato e stato COMPLETED. Nessuna rete, chiave, scrittura nell'App o
chiamata modello è stata utilizzata per questi test.

I due difetti specifici sono inoltre verificati da
`test_automatic_supervisor.py`: subprocess
interamente simulati in `/private/tmp`; blocco dopo bootstrap fallito senza
progresso (nessun secondo launch), timeout configurato e cleanup, errore di
spawn, eccezione post-uscita con ricevuta e latch conservati. Nessuna chiamata
al provider, nessun processo modello e nessuna scrittura nello studio reale.
