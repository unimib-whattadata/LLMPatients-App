> **Invii sospesi per credito OpenRouter insufficiente:** l’ultimo HTTP 402 è `weight_exceeds_budget`, distinto dagli arresti temporanei precedenti. Il provider chiede una ricarica; il controllo non ripete richieste finché il problema resta irrisolto. [Ricevuta del blocco](continuations/automatic-control-2026-10-06/CREDIT_BLOCK_NOTIFICATION.json).

> **Aggiornamento operativo del 6 ottobre 2026:** raccolte **149/160 risposte**; 11 mancanti. La valutazione riportata sotto riguarda ancora le **147 risposte dello snapshot rating-v4** e non comprende le due aggiunte successive. È attivo un controllo automatico ogni 15 minuti per riprendere dopo arresti temporanei e completare poi la valutazione. [Autorizzazione e protocollo operativo](continuations/automatic-control-2026-10-06/AMENDMENT.md), [stato corrente](run-state.json).

# Indice dei dati e ricalcolo offline

Pacchetto: `evaluation/reviewer-comment-1/outputs/state-update-retrieval-pilot-2026-10-05/` nel repository **LLMPatients-App**. Ultimo stato analizzato: **147/160 risposte disponibili**, 13 allora mancanti; lo stato operativo aggiornato è indicato sopra. Iniziare dal [rapporto](REPORT.md). La Tabella D1 raccoglie i percorsi relativi alla radice del pacchetto.

**Tabella D1. Artefatti di raccolta, valutazione e verifica.**

| Che cosa verificare | Percorso |
|---|---|
| Disegno, condizioni, limiti e arresto | [PROTOCOL.md](PROTOCOL.md), [config.json](config.json), [schedule.json](schedule.json) |
| Rubrica e congelamento | [RUBRIC.md](RUBRIC.md), [FREEZE.json](FREEZE.json), [ANALYSIS_FREEZE.json](ANALYSIS_FREEZE.json), [PRECOLLECTION_AUDIT.md](PRECOLLECTION_AUDIT.md) |
| Dialoghi, profili e domande senza gold generativo | [inputs/](inputs/); esempio [alder_glass_01/case.json](inputs/alder_glass_01/case.json) |
| Soluzioni attese e fonti separate | [review/private/](review/private/); esempio [alder_glass_01-gold.json](review/private/alder_glass_01-gold.json) |
| Codice e versione nativa Agent | [engine.py](engine.py), [run.py](run.py), [client.py](client.py), [source/](source/), [SOURCE_PROVENANCE.json](SOURCE_PROVENANCE.json) |
| Ambiente, tokenizer e modello semantico | [source/runtime-calibration.json](source/runtime-calibration.json), [source/tokenizer.model](source/tokenizer.model), [source/embedding-source-manifest.json](source/embedding-source-manifest.json), [PREFLIGHT.json](PREFLIGHT.json) |
| Prompt completi costruiti | [constructed-prompts/](constructed-prompts/) |
| Richieste, risposte, ricevute e output accettati | [requests/](requests/); ogni tentativo ha `attempt-NN-request.json.gz`, `attempt-NN-response.json.gz`, `attempt-NN-receipt.json`; i job riusciti hanno `accepted.json` e `answer.txt` |
| Memoria completa e versioni dei fatti | [runtime/native/](runtime/native/); copia senza perdita per caso, ad esempio [complete-native-store.jsonl.gz](runtime/alder_glass_01/complete-native-store.jsonl.gz) |
| Fonti, consolidamenti, checkpoint e riassunti | [runtime/](runtime/); esempio [source-map.json](runtime/alder_glass_01/source-map.json), [s11-consolidation.json](runtime/alder_glass_01/s11-consolidation.json), [s11-summary-full.txt](runtime/alder_glass_01/s11-summary-full.txt), [s11-summary-budget.json](runtime/alder_glass_01/s11-summary-budget.json) |
| Evidenze recuperate e vettori | [retrieval/](retrieval/), [runtime/embedding-cache.json.gz](runtime/embedding-cache.json.gz) |
| Valutazione precedente, 133 risposte | [review/rating-v1/](review/rating-v1/), [GRADING_PROVENANCE.json](GRADING_PROVENANCE.json); conservata senza modificare i giudizi |
| Valutazione storica, 141 risposte | [review/rating-v2/](review/rating-v2/); include gli otto giudizi aggiunti nella prima ripresa |
| Valutazione storica, 145 risposte | [review/rating-v3/](review/rating-v3/); giudizi e analisi conservati senza rivalutazione |
| Inventario corrente, 147 risposte | [review/rating-v4/](review/rating-v4/), [snapshot](review/rating-v4/private/review-snapshot.json) |
| 2 nuove schede per valutatore | [A](review/rating-v4/continuation/cards/grader-A-new.json), [B](review/rating-v4/continuation/cards/grader-B-new.json) |
| Nuovi giudizi e provenienza | [fresh A](review/rating-v4/continuation/fresh-grader-A.json), [fresh B](review/rating-v4/continuation/fresh-grader-B.json), [GRADING_PROVENANCE.json](review/rating-v4/continuation/GRADING_PROVENANCE.json) |
| Riuso dei 145 giudizi precedenti | [helper](continue_review_v2.py), [nota](CONTINUATION_REVIEW_V2.md), [BUILD_FREEZE.json](review/rating-v4/continuation/private/BUILD_FREEZE.json), [MERGE_PROVENANCE.json](review/rating-v4/continuation/merged/MERGE_PROVENANCE.json) |
| Giudizi combinati, 147 per A/B | [A](review/rating-v4/continuation/merged/grader-A.json), [B](review/rating-v4/continuation/merged/grader-B.json) |
| Risultati correnti | [analysis.json](review/rating-v4/analysis.json), [ANALYSIS.md](review/rating-v4/ANALYSIS.md), [run-state.json](run-state.json) |
| Prima ripresa e snapshot a 133 | [autorizzazione](continuations/resume-2026-10-06-01/RESUME_AUTHORIZATION.json), [snapshot](continuations/resume-2026-10-06-01/partial-2026-10-05.tar.gz) |
| Seconda ripresa e snapshot a 141 | [autorizzazione](continuations/resume-2026-10-06-02/RESUME_AUTHORIZATION.json), [stato](continuations/resume-2026-10-06-02/RESUME_STATUS.json), [snapshot](continuations/resume-2026-10-06-02/partial-141-answers.tar.gz) |
| Terza ripresa e snapshot a 145 | [autorizzazione](continuations/resume-2026-10-06-03/RESUME_AUTHORIZATION.json), [stato](continuations/resume-2026-10-06-03/RESUME_STATUS.json), [snapshot](continuations/resume-2026-10-06-03/partial-145-answers.tar.gz) |
| Richieste fallite conservate | [alder_glass_01-q1-currency-ablated tentativo 01](requests/alder_glass_01-q1-currency-ablated/attempt-01-response.json.gz); [cobalt_fern_02-q6-raw-rag tentativo 01](requests/cobalt_fern_02-q6-raw-rag/attempt-01-response.json.gz); [cobalt_fern_02-q6-summary-rag tentativo 01](requests/cobalt_fern_02-q6-summary-rag/attempt-01-response.json.gz); [plum_lantern_04-q3-native tentativo 01](requests/plum_lantern_04-q3-native/attempt-01-response.json.gz) |
| Controlli e preservazione | [audit iniziale](INDEPENDENT_AUDIT.md), [prima ripresa](RESUME_AUDIT.md), [seconda](RESUME_02_AUDIT.md), [terza](RESUME_03_AUDIT.md), [audit rapporto finale](FINAL_REPORT_AUDIT.md), [memoria](MEMORY_BUILD_AUDIT.json) |
| Ricalcolo offline | [RETRIEVAL_RECOMPUTE.json](RETRIEVAL_RECOMPUTE.json), [rianalisi v4](review/rating-v4/OFFLINE_REANALYSIS.json), [nota numerica](RECOMPUTE_IMPLEMENTATION.md), [modifica](RECOMPUTE_AMENDMENT.json) |
| Controllo automatico e sue verifiche | [automatic_supervisor.py](automatic_supervisor.py), [test offline](test_automatic_supervisor.py), [protocollo operativo](AUTOMATIC_SUPERVISION.md), [audit](AUTOMATIC_SUPERVISION_AUDIT.md), [autorizzazione](continuations/automatic-control-2026-10-06/AUTHORIZATION.json), [limiti approvati](continuations/automatic-control-2026-10-06/AUTOMATIC_REVIEW_BOUNDARY.json) |
| Integrità finale | [RESULTS_MANIFEST.json](RESULTS_MANIFEST.json), [ARTIFACT_AUDIT.json](ARTIFACT_AUDIT.json) |

## Verificare hash e archivi

Il manifest della radice verifica l’ultimo stato stabile registrato. Durante una nuova esecuzione i file operativi possono avanzare: usare gli snapshot per le verifiche storiche ed evitare di confrontare un manifest precedente con un processo attivo. Il manifest e gli audit vengono aggiornati a raccolta ferma e al completamento finale.

Eseguire i comandi dalla radice del pacchetto, con Python 3.12 su macOS o Linux. Usano la libreria standard e i dati salvati: nessuna chiave, nuovo modello o chiamata di rete. Gli hash del manifest riguardano i byte compressi; gli hash delle ricevute riguardano i corpi decompressi. Il manifest esclude se stesso, il proprio audit e l'eventuale lock del processo.

```bash
python3 - <<'PY'
import hashlib, json
from pathlib import Path
root = Path('.')
manifest = json.loads((root / 'RESULTS_MANIFEST.json').read_text())
for relative, record in manifest['files'].items():
    raw = (root / relative).read_bytes()
    assert len(raw) == record['bytes'], relative
    assert hashlib.sha256(raw).hexdigest() == record['sha256'], relative
print('Hash verificati:', len(manifest['files']))
PY
python3 -B verify_artifacts.py --root .
```
Leggere un errore conservato senza sostituire il file originale:

```bash
python3 - <<'PY'
import gzip, json
from pathlib import Path
p = Path('requests/cobalt_fern_02-q6-raw-rag/attempt-01-response.json.gz')
print(json.dumps(json.loads(gzip.decompress(p.read_bytes())), indent=2))
PY
```

Ogni `.jsonl.gz` conserva un deposito completo: `gzip.decompress` lo estrae senza perdita in una directory di lavoro separata; ogni riga è un record JSON. I **tre snapshot** `.tar.gz` preservano il pacchetto a 133, 141 e 145 risposte, inclusi rapporti e analisi storici, con percorsi originali. Prima di estrarli in directory separate, verificarne lo SHA-256 contro il `RESUME_AUTHORIZATION.json` nella stessa cartella dell’archivio; ciascun `RESULTS_MANIFEST.json` interno verifica il relativo stato storico. Il manifest corrente verifica invece il pacchetto a 147 risposte. Non applicare un manifest storico al pacchetto corrente.

## Ricostruire selezione e prompt

```bash
python3 -B recompute-v2.py --root .
```

Per il precedente stato valutato a 147 risposte, l’esito conservato era `PARTIAL`, **148/160 contesti verificati**, 12 non costruiti e una richiesta fallita senza risposta. La raccolta successiva è documentata dal `run-state.json`; non usare il vecchio numero di contesti come verifica del nuovo stato. Il prossimo ricalcolo completo viene conservato al termine della raccolta. Il comando usa vettori salvati e controlla selezione, ordine, testo e hash; tolleranza `1e-12` soltanto sui punteggi. Nessun modello viene chiamato.

## Ricalcolare l’ultima valutazione disponibile (147 risposte)

La raccolta corrente contiene 148 risposte, ma la valutazione `rating-v4` è sigillata sull’inventario di 147. Per ricalcolarla estrarre [baseline-147.tar.gz](continuations/automatic-control-2026-10-06/baseline-147.tar.gz) in una cartella separata, dopo averne verificato lo SHA-256 in [AUTHORIZATION.json](continuations/automatic-control-2026-10-06/AUTHORIZATION.json). Per verificare l’intero manifest storico aggiungere anche i tre archivi immutabili elencati in `preserved_archive_dependencies` ai loro percorsi originali e verificare i rispettivi hash. Il ricalcolo dei punteggi usa soltanto i file già presenti nella baseline e non richiede questi archivi aggiuntivi. `aggregate` scrive analisi: eseguirlo dalla radice della copia di lavoro a 147 risposte, senza usare il pacchetto in raccolta.

```bash
python3 -B review.py aggregate --root . \
  --review-dir review/rating-v4 \
  --a review/rating-v4/continuation/merged/grader-A.json \
  --b review/rating-v4/continuation/merged/grader-B.json
```

Esito atteso: **147 risposte, 259 campi**; nessuna adjudication necessaria. [Hash rianalisi](review/rating-v4/OFFLINE_REANALYSIS.json). Si ricalcolano i punteggi dai 145 giudizi conservati e dai due nuovi; soltanto le aggiunte sono state giudicate da una quarta coppia AI. Questo ricalcolo non è una replica stocastica, una nuova valutazione AI o una validazione clinica. Per stati a 133, 141 o 145 risposte usare il corrispondente snapshot: gli inventari storici sono sigillati.

[Helper v2](continue_review_v2.py) e [nota](CONTINUATION_REVIEW_V2.md) documentano il riuso. I percorsi di provenienza sono quelli originari: in un checkout trasferito ricreare un output `build` locale e poi `merge`; il normale ricalcolo non dipende da quei percorsi. Il solo helper richiede `.runner.lock`; in una copia offline crearne uno vuoto se escluso dal trasferimento. Stato `STOPPED` o `COMPLETED` obbligatorio.

**Non eseguire `run.py` o `preflight.py` per verifiche offline.** Il collector è fermo; questo indice non attesta commit o push.
