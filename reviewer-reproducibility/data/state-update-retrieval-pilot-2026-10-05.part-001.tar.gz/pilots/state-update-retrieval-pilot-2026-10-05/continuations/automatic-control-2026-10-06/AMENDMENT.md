# Controllo periodico e riprese automatiche

Il 6 ottobre 2026 l’utente ha richiesto di procedere fino al completamento e di controllare periodicamente l’esecuzione, riavviandola dopo un arresto. Questa autorizzazione sostituisce l’obbligo precedente di attendere una nuova istruzione manuale per ogni ripresa. Il protocollo originale e i suoi hash restano conservati.

## Ambito operativo

Il controllo della stessa chat è attivo ogni 15 minuti. Prima di una ripresa verifica stato, lock, hash e ricevute. Un processo attivo viene lasciato procedere; non si avvia un secondo collector. Gli arresti temporanei del servizio, incluso HTTP 402 con `in_flight_budget_exhausted`, possono essere ripresi al controllo successivo. Retry-After e backoff sono rispettati.

Restano invariati modello `google/gemini-2.5-pro` tramite OpenRouter, prompt, memoria, dati, ordine, parametri, rubrica e criterio primario. Restano il tetto cumulativo USD 15, comprese le riserve per costi ignoti, e il divieto di rigenerare risposte già accettate. Errori di credenziali, integrità, spesa o esaurimento dei tentativi richiedono gestione distinta, senza aggirare le verifiche. Il limite originale di tre tentativi cumulativi per job non è modificato da questa nota: un’eventuale estensione richiede un ulteriore emendamento operativo, codice versionato e validazione compatibile dei tentativi prima di altre chiamate. L’utente ha autorizzato il controllo e le riprese ordinarie, per cui non si richiede una nuova conferma a ogni ripresa. La revisione automatica ha invece rifiutato di autorizzare modifiche autonome a runner/validatore per superare il cap: tale estensione richiede un’approvazione umana specifica. L’automazione attiva conserva il limite originale.

Ogni finestra conserva stato precedente, nuovi tentativi ed errori. Lo snapshot iniziale a 147 risposte conserva ogni file nei percorsi originali eccetto i tre archivi storici già salvati, che sono dipendenze immutabili registrate in AUTHORIZATION.json. Per ricostruire l’intero stato storico estrarre baseline-147.tar.gz in una cartella separata, aggiungere gli archivi elencati ai rispettivi percorsi originali e verificare il RESULTS_MANIFEST.json interno. Le riprese successive possono salvare gli intermedi modificabili come delta senza duplicare gli archivi storici.

## Completamento

Il controllo termina dopo 160 risposte, valutazione delle sole aggiunte con due contesti nuovi mascherati, riuso verificato dei giudizi precedenti, ricalcolo offline, aggiornamento di rapporto/indice/audit/manifest. Risultati favorevoli, sfavorevoli, parità e mancanze vengono tutti conservati. Nessun cambiamento al manoscritto è autorizzato da questa nota.

## Verifica diagnostica della chiave

Una lettura separata di `GET /api/v1/key` ha confermato autenticazione valida e nessun limite monetario specificato sulla chiave (`limit` e `limit_remaining` null). Il saldo complessivo dell’account non è stato verificato: la chiave non è una management key e non è stato chiamato l’endpoint riservato `/credits`. Questi metadati non dimostrano né saldo nullo né credito sufficiente per la richiesta seguente. Sono conservati soltanto campi sanitizzati in KEY_BUDGET_DIAGNOSTIC.json, senza identificatori, nomi, etichette, uso globale o credenziali. La lettura non invia dati ai modelli e non è conteggiata fra i tentativi della raccolta. Il controllo locale `--check` del supervisor resta senza rete.
