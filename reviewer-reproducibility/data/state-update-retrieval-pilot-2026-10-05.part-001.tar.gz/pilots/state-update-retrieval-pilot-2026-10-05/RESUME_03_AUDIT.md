# Audit indipendente della terza ripresa — 6 ottobre 2026

## Esito e perimetro

**PASS nel perimetro tecnico verificato.** La terza ripresa manuale ha aggiunto **2 risposte accettate in 3 nuovi tentativi**, fermandosi al quarto HTTP 402 della raccolta. Stato corrente: **257/270 job accettati, 261 tentativi, 147/160 risposte e 13 mancanti**. Estrazioni e riassunti restano 55+55.

Audit locale in sola lettura, senza rete, chiavi o chiamate a modelli. Non sono stati aperti file dei grader, schede o voti, né rivalutate risposte. Nessuna modifica App/LaTeX: questa nota è l'unico file scritto. Il ricalcolo usa esclusivamente i vettori salvati e il codice congelato, con connessione socket disabilitata nel processo di verifica.

## Snapshot e preservazione

Archivio: `continuations/resume-2026-10-06-03/partial-145-answers.tar.gz`.

- SHA-256 verificato: `19ef30f4aab3741b8ff0b911ac569f4804eb43b783b3234862db06dde6b4b26b`, corrispondente all'autorizzazione.
- **2.075 file**, **55.203.621 byte non compressi** e **40.389.557 byte dell'archivio compresso**. Il numero di file e i byte non compressi coincidono con RESUME_AUTHORIZATION.json. Il run-state archiviato coincide esattamente con prior_state: 255 accepted, 258 tentativi, 145 risposte.
- Tutti i **1.284 file precedenti sotto requests/** sono identici byte per byte: i 258 tentativi con ricevute/richieste/risposte, i 255 accepted e rispettivi answer, comprese tutte le 145 risposte precedenti.
- Tutti i **256 prompt precedenti** sono identici byte per byte.
- Tutti i **251 file runtime** sono identici byte per byte: 5 store nativi, 5 copie complete compresse, 5 source map, 15 checkpoint, 55 consolidamenti, 55 riassunti completi, 55 riassunti bounded, 55 registrazioni del budget e cache di 1.292 embedding. Nessun nuovo tentativo di estrazione o riassunto.
- Tutti i 5 file inputs e i 10 source sono identici. Configurazione, schedule, protocollo, rubric, collector/retrieval/review, entrambi i helper e documentazione della tolleranza numerica controllati sono invariati.
- Freeze di raccolta invariata: `19e4ad104d368f236966fce0e5c2bf0ccbd8cc7abe679917c085dea4ed66e929`; freeze di analisi invariata: `2ca3329db08c9050fa36e0a9149e2134c6a3d80c5f2f88807dab00997bef614a`. Verificati 30 hash della prima freeze e tutti i 5 della seconda; esclusi dalla lettura i 10 percorsi della prima sotto review/, rispettando il mandato.

Non è stato sostituito alcun output già accettato. Le sole aggiunte nei percorsi di raccolta sono 13 file requests, 2 retrieval e 2 prompt.

## Recupero indipendente

Confronto snapshot/corrente: dei **146 retrieval precedenti**, 103 sono identici byte per byte. Gli altri **43** differiscono soltanto in **62 valori BM25**, differenza assoluta massima **3,552713678800501e-15**. Il confronto ricorsivo conferma identità di selezione, ordine, tutti gli altri campi, testi e hash di memoria/prompt. Lo snapshot conserva i valori diagnostici originari.

Ricalcolo indipendente di **tutti i 148 contesti correnti**, usando i 1.292 vettori salvati e nessun encoder: selezione, ordine, campi non numerici, memoria renderizzata e prompt corrispondono esattamente agli archivi. Hash di memoria/prompt esatti. In questo diverso processo 32 contesti/44 valori BM25 differiscono soltanto negli ultimi bit, massimo 3,552713678800501e-15, entro la tolleranza 1e-12. Nessuna differenza di score nativo, cosine o RRF. Massimo osservato **1.800 token stimati di memoria**.

**148 contesti = 147 risposte + contesto dell'ultimo 402; 12 contesti non costruiti.** I 13 esiti mancanti comprendono il fallimento corrente.

## Nuove richieste e parametri

La Tabella 1 riporta i tre nuovi tentativi nell'ordine congelato. Coincidono esattamente con i primi tre job mancanti nello schedule e nell'autorizzazione.

**Tabella 1. Nuovi tentativi della terza ripresa.**

| Job | Tentativo | Esito | Costo registrato USD |
|---|---:|---|---:|
| cobalt_fern_02-q6-summary-rag | 02 | HTTP 200, accepted | 0,011345 |
| cobalt_fern_02-q6-currency-ablated | 01 | HTTP 200, accepted | 0,009035 |
| cobalt_fern_02-q6-raw-rag | 01 | HTTP 402, stop | non riportato |

Il precedente tentativo 01 di cobalt_fern_02-q6-summary-rag è conservato. Il corpo decompresso della richiesta 02 è identico a quello della richiesta 01, SHA-256 `58bbfdaaad9d1bd7fd07aee07744b989f1bec215eb2b8ff1d1c2de2af31a94dc`. Nessun job supera due tentativi: 255 job con un tentativo e tre con due.

Verificati tutti i 261 archivi contro gli hash delle ricevute; tutte le richieste contro prompt e impostazioni congelate; tutti i 257 accepted contro answer/hash, generation ID, usage e contenuto originale. Cap locali e nativi rispettati. Tutti i 257 accepted, inclusi i due nuovi, riportano modello `google/gemini-2.5-pro` e provider `Google`.

Parametri delle nuove risposte invariati: temperatura 0,7, top_p 0,95, massimo output 2.048, reasoning massimo 1.024, require_parameters=true, allow_fallbacks=false, context-compression disabilitata. Nessuna modifica a modello richiesto, endpoint, impostazioni o metodi scientifici.

Tutti i tentativi sono seriali senza sovrapposizione. Intervallo minimo fra inizi nella terza ripresa **10,003904 s**; nell'intera raccolta **10,003756 s**. Le tre nuove richieste iniziano fra 6 ottobre **13:03:53,912418 e 13:04:14,455464 UTC**, ossia 15:03–15:04 ora italiana. Durata del processo corrente **173,768134 s**, circa 2,90 minuti. È la quarta finestra della raccolta complessiva; questa durata non include i processi precedenti, gli intervalli fra essi o la valutazione successiva.

## Quarto 402 e costi

Payload dell'ultimo errore verificato direttamente: cobalt_fern_02-q6-raw-rag, tentativo 01; HTTP/code 402, reason **in_flight_budget_exhausted**, limit_source **openrouter_in_flight_budget**, Retry-After **120 secondi**. Il messaggio riguarda il budget disponibile considerando richieste in corso e non dimostra saldo complessivo nullo.

La ricevuta termina alle **13:04:14,757727 UTC**; STOPPED è registrato alle **13:04:14,759163 UTC**. Nessun tentativo successivo nel pacchetto e nessun tentativo 02 per questo job. Il codice congelato esclude 402 dal retry automatico.

La Tabella 2 mostra il ricalcolo decimale dei costi. Ogni costo registrato nelle ricevute coincide con usage.cost del payload originale.

**Tabella 2. Contabilità cumulativa dopo la terza ripresa.**

| Voce | USD |
|---|---:|
| Registrato prima della terza ripresa | 4,351049375 |
| Due nuove risposte | 0,020380000 |
| Registrato cumulativo | **4,371429375** |
| Riserva per costo non riportato dei quattro 402 | **0,122880000** |
| Totale conservativo | **4,494309375** |
| Cap cumulativo congelato | 15,000000000 |

Le riserve di 0,03072 per errore non sono addebiti osservati. Stato e ricevute concordano entro 1e-12; le differenze nelle ultime cifre derivano dalla rappresentazione floating point.

## Disponibilità e limiti dell'audit

- Risposte: native, currency-ablated e summary-rag **37/40** ciascuno; raw-rag **36/40**.
- Primarie **17/20 per tutti i bracci**. Secondarie native/currency-ablated/summary-rag **20/20**, raw-rag **19/20**.
- Denominatori dei campi derivati esclusivamente da requested_fields degli input e presenza di accepted: **65 native, 65 currency-ablated, 65 summary-rag e 64 raw-rag**, totale **259**. Sono campi disponibili, non giudizi di correttezza.
- Primaria completa ancora in **3/5 casi**: cobalt_fern_02, plum_lantern_04 e saffron_echo_03. La media primaria sui cinque casi resta indisponibile.
- I due nuovi esiti devono essere valutati secondo la procedura prevista prima di aggiornare i punteggi; l'audit tecnico non estende i precedenti successi a queste risposte. La successiva provenienza dovrà distinguere i 145 giudizi riusati per serie A/B dai due nuovi.

Nessun blocco tecnico riscontrato per aggiornare gli artefatti derivati. Il collector resta fermo; nessun riavvio o ulteriore chiamata è autorizzato da questa nota.
