# State/update/retrieval pilot: fixed scenario inventory

Protocol: memory component 11-session replay. These are predetermined fictional conversations, not full generated patient trajectories. All five patients and all other named people are simulated. No diagnoses are asserted.

The five cases were authored together before any production extraction, summary, retrieval, or recall output was inspected. No previous scenario outcomes were read. There is no outcome-based filtering, title recycling, or deliberate baseline-failure construction. Each arm should receive the same dialogue history and the same ordinary final questions.

## Files and input boundary

- `state_pilot_scenarios_20261005.json`: complete scripted histories, separate common profiles, final questions, therapist-sourced gold, and gold-free checkpoint metadata.
- `state_pilot_scenario_notes_20261005.md`: inventory, construction rationale, and provenance rules.
- Generation input consists of the relevant profile/history or arm-produced memory plus the selected question. Do not include `gold`, `field_sources`, `criterion`, this note, or audit checkpoints in extraction, summarization, or recall prompts.
- Profiles supply only simulated identity and a brief everyday context. Name and age can be included as the same compact CASE profile for every arm, separately from the changing memory. Identity is secondary and is not treated as a memory-only challenge.

## Counts

| Unit | Per case | Full inventory |
|---|---:|---:|
| Cases | 1 | 5 |
| Sessions | 11 | 55 |
| Exchanges (therapist plus patient) | 55 | 275 |
| Individual utterances | 110 | 550 |
| Core exchanges / supporting exchanges | 22 / 33 | 110 / 165 |
| Final ordinary questions | 8 | 40 |
| Positive primary / secondary questions | 4 / 4 | 20 / 20 |
| Scored requested fields | 14 | 70 |
| Offline checkpoints | 3 | 15 |

The fourteen scored fields are below the sixty-target-detail cap. Each appointment-slot field comprises a weekday and a clock time; counting those subcomponents separately gives seventeen primitive scored details per case. Supporting dialogue adds ordinary reported experience rather than additional scored facts.

## Families

| Case ID | Simulated patient | Everyday context | Latest optional-call status |
|---|---|---|---|
| alder_glass_01 | Neris Bellafonte, 39 | pottery and small household routines | Confirmed after cancellation |
| cobalt_fern_02 | Dorian Valegro, 46 | container gardening and everyday breaks | Cancelled after reconfirmation |
| saffron_echo_03 | Elian Corvani, 32 | listening to music and settling daily routines | Confirmed after cancellation |
| plum_lantern_04 | Mara Solenne, 54 | local walks and household pacing | Cancelled after reconfirmation |
| mint_horizon_05 | Tessa Arvello, 41 | casual photography and arranging quiet time | Confirmed after cancellation |

Each family has its own notebook title, two appointment slots plus one proposed slot, partner, former/current venues, and completed/planned exercise titles. The factual values do not reuse a prior case collection. Families share a controlled chronology to support comparison, while personal contexts, proper nouns, clock times, reminder methods, distractor order, and core turn positions differ.

## Final-question inventory

| Question | Role | Category | Requested fields |
|---|---|---|---|
| q1 | Positive primary | Stable title | title |
| q2 | Positive primary | Appointment | current_slot; former_slot; unconfirmed_proposal; partner |
| q3 | Positive primary | Venue | current_venue; former_venue |
| q4 | Positive primary | Activity status | completed_title; planned_title |
| q5 | Secondary | Cancellation/reconfirmation | current_status |
| q6 | Secondary | Speaker authority | agreed_reminder_method |
| q7 | Secondary | Identity | name; age |
| q8 | Secondary | Never-established detail | office_extension |

All questions are separate, ordinary queries after session 11. None supplies a gold value, requests target-guided extraction, or adds a new event to the conversation. The missing-detail query is secondary; it is not counted as a positive primary recall success.

## Fixed chronology and evidence design

| Session | Core source events, in within-session order |
|---|---|
| 1 | Confirmed identity and unchanged notebook title; initial agreed appointment and partner |
| 2 | Initial agreed venue; explicit completed exercise |
| 3 | Agreed future exercise and initial optional call; agreed reminder method |
| 4 | Explicit appointment replacement; explicit venue replacement |
| 5 | Unconfirmed alternative appointment proposal; repeated correction of current/former appointment |
| 6 | Completed/planned distinction reaffirmed; explicit cancellation of optional call |
| 7 | Patient-proposed reminder alternative distinguished from therapist agreement; stable title reaffirmed and extension absence recorded |
| 8 | Venue correction repeated; appointment correction and proposal status repeated |
| 9 | Therapist reminder agreement corrected/reaffirmed; optional call explicitly reconfirmed |
| 10 | Completed/planned distinction repeated; same appointment partner and extension absence reaffirmed |
| 11 | Final appointment correction with former/proposed/partner distinctions; latest optional-call status and stable title reaffirmed |

The current appointment replaces exactly one formerly agreed slot. The venue likewise has exactly one replacement. The alternative appointment slot is always an unconfirmed proposal. The completed activity is explicitly described as completed; the future activity never acquires completed status. Every positive agreement, confirmation, and completed-activity record uses the literal terms `agreed`, `confirmed`, or `completed`, as appropriate, so conservative production validation has explicit evidence.

The optional call is initially agreed, explicitly cancelled, and explicitly reconfirmed. Two cases then explicitly cancel it again; three retain the reconfirmation. Thus the current status depends on the final therapist record, not on a fixed rule that reconfirmation or cancellation must always win.

For speaker authority, the patient suggests another reminder method and wonders whether it might appear in the record. The patient does not assert a fabricated confirmed past agreement. The therapist explicitly distinguishes that suggestion from the confirmed method and repeats the correction. The extension is never provided by either speaker, and its absence is explicitly recorded twice.

## Position, supporting dialogue, and blind scope

There are two core exchanges and three supporting exchanges in every session. For zero-based case index c and session index s, the two core positions are `(c + 2*s) mod 5` and that position plus two modulo five, sorted so event chronology stays intact. This deterministic rotation distributes source facts through early, middle, and late turns. Every family uses all five turn positions. Supporting-exchange order also rotates deterministically by case.

Supporting turns concern sensory observations, household tasks, everyday conversations, attention, uncertainty, and ordinary preferences. Their utterance lengths are comparable to the core turns. They introduce no competing appointment dates, venue names, exercise titles, telephone numbers, or confirmed reminder arrangements. They contain no artificial system instructions, role overrides, adversarial prompt injection, or clinical diagnosis claims.

Case selection, scope, positive-primary categories, and all gold values were fixed without model outcomes. The purpose is to measure retention, explicit updates, status distinctions, and source authority under natural supporting detail. The inventory is not engineered to cause a particular arm to fail. Production extraction and summarization should use their actual implementation and validation rules.

## Sources and checkpoints

Within each case, `s01t01` identifies the first exchange of session 1; IDs run through `s11t05`. A globally unique provenance key is the case ID plus source ID plus speaker. The stored therapist and patient texts remain immutable across arms. Gold evidence uses only therapist utterances; every field source records `source_id`, `session_index`, `turn_index`, and `speaker: therapist`.

Gold `expected` keys exactly match each question’s `requested_fields`. Multiple sources document introductions, replacements, and later corrections. They are provenance for offline scoring, not text to include in a generation prompt. For q8, expected null denotes unknown/not established; a fabricated extension fails that criterion.

Checkpoints after sessions 3, 7, and 11 contain only source IDs, indices, speaker, generic topic, and event type for the newly covered interval. They contain no factual values or answer keys. They enable offline grounding and update audits without adding any questions or model calls.

The planned bounded execution is one production extraction and one summary update for each of the 55 sessions, followed by one answer per arm/question for 5 cases × 4 arms × 8 questions: 55 extraction + 55 summary + 160 recall = 270 jobs. This scenario package itself performs none of those calls.

## Validation performed

Local validation checked 5 × 11 × 5 exchange counts, unique source IDs within each case, eight questions and fourteen fields per case, exact requested-field/gold-key alignment, valid therapist-only source descriptors, literal support for each non-null gold value in its cited therapist sources, no gold values embedded in question text, and checkpoint endpoints/absence of value fields. No production extractor, summarizer, or answer model was run during data construction.
