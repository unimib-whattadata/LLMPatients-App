# Continuazione dei giudizi del pilota — helper offline

Codice: `/private/tmp/state-pilot-continue-review-20261006.py`.
Solo libreria standard Python. Nessuna rete, credenziale, chiamata a modelli,
preparazione di snapshot o modifica del pacchetto scientifico originario.

## Uso dopo l'arresto della raccolta

`review.py prepare --allow-partial` deve avere già prodotto il nuovo snapshot.
Il programma rifiuta un collector attivo tramite lock condiviso non bloccante e
stato `STOPPED`/`COMPLETED`. Il lock rimane detenuto per tutta l'operazione.

```sh
python3 -B /private/tmp/state-pilot-continue-review-20261006.py build \
  --root STUDY \
  --old-review STUDY/review/rating-v1 \
  --new-review STUDY/review/rating-v2 \
  --out STUDY/review/rating-v2/continuation

python3 -B /private/tmp/state-pilot-continue-review-20261006.py merge \
  --out STUDY/review/rating-v2/continuation \
  --a-new FRESH-A.json \
  --b-new FRESH-B.json
```

Sul nuovo snapshot parziale del 6 ottobre: **133 giudizi preesistenti riusati e
8 schede nuove per valutatore; 141 risposte disponibili, 19 mancanti**.
Il conteggio è derivato dai due snapshot, non fissato nel codice: ulteriori
snapshot completi o parziali sono supportati purché includano tutti i vecchi job.

## Controlli

- Verifica freeze scientifico e freeze di analisi; importa il `review.py`
  congelato senza generare cache Python.
- Controlla separatamente il sigillo v1: la funzione nativa `sealed_review`
  deve rifiutarlo dopo l'ampliamento dell'inventario, quindi viene applicata
  integralmente solo al nuovo snapshot v2.
- Per A/B distinti, mappa per `job_id`, non per posizione o presunta modifica
  degli ID. Controlla bijezione e uguaglianza di tutta la scheda escluso
  `card_id`, inclusi risposta, domande, gold ed evidenze. Preserva anche i tipi
  JSON mediante confronto canonico.
- Verifica i byte di `accepted.json` e `answer.txt` contro gli SHA-256 sigillati
  nel vecchio mapping e quelli del nuovo mapping. Il sigillo nativo v2 controlla
  inoltre risposta, prompt e archivi HTTP correnti. Nei vecchi snapshot gli
  originali metadati accettati sono attestati tramite hash, non copie separate.
- Copia ogni vecchia riga giudizio cambiando soltanto `card_id`; valida ogni
  vecchio file e ogni nuovo subset con il `load_grades` congelato. L'originale
  grading v1 resta intatto anche quando gli ID v1/v2 coincidono.
- I nuovi subset mantengono l'ordine v2. Non contengono giudizi riusati,
  mapping, braccio sperimentale o metadati del collector.
- Merge: campi/Booleani/estratti rigorosi, nessun overlap, duplicato, job
  sconosciuto o giudizio mancante; completa esattamente tutte le schede v2.
  Ricontrolla hash di vecchi giudizi, metadati, risposte e sorgenti.
- Scrive output nuovi senza sovrascrivere file esistenti. `private/BUILD_FREEZE.json`
  sigilla la provenienza e i file generati; `merged/MERGE_PROVENANCE.json`
  collega hash del build, hash dei nuovi giudizi e dei file completi.

## Distribuzione ai nuovi valutatori

Ogni contesto nuovo e isolato riceve **soltanto** il proprio
`cards/grader-A-new.json` oppure `cards/grader-B-new.json` e `RUBRIC.md`.
Non fornire `private/`, voti precedenti, sorgenti, mapping, file dell'altro
valutatore o questa nota. L'indipendenza fra contesti è responsabilità del
dispatcher; un helper locale non isola i permessi di accesso del valutatore.

Il merge non adjudica divergenze e non calcola risultati. Usare poi il
`review.py aggregate` congelato con `--review-dir` v2 e i due file in `merged/`.
Le chiamate mancanti rimangono mancanti; non diventano insuccessi fattuali.

## Verifiche e limiti

Build reale verificato offline in una directory **solo `/private/tmp`**:
133+8=141 per A/B. Un controllo sintetico delle funzioni pure ha verificato
ID diversi, copia immutata dei giudizi e rifiuto di domanda/risposta alterate.
Il programma controlla schema e provenienza, non la correttezza semantica dei
nuovi giudizi. Nessun modello è stato chiamato e nessuna nuova risposta è stata
valutata per preparare il codice.

I sigilli SHA-256 sono controlli locali d'integrità, non firme digitali.
Conservare l'hash del `BUILD_FREEZE.json` in un manifest esterno/pubblicato.
La provenienza registra percorsi assoluti; per spostare lo studio, rieseguire
il build indicando i percorsi del nuovo checkout, senza alterare gli snapshot.
