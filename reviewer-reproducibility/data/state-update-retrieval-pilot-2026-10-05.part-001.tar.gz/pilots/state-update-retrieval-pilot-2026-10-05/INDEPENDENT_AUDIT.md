# Independent offline technical audit

## Material passport

- Study: state-update-retrieval-pilot-2026-10-05.
- Scope: artifact integrity, native extraction replay, summary replay, retrieval replay, operational stopping, and partial-result denominators.
- Context: separate technical audit in a shared conversation context; not a blinded independent scientific replication or accuracy assessment.
- Restrictions respected: no provider/network calls, no restarts, no edits to the study package, no grader A/B files read, no contact with graders. The only authored file is this report.

## Finding

No discrepancy was found in the checked collection artifacts or reproduced memory/retrieval behavior. Collection is partial, and the full prespecified five-history primary contrast cannot be reported as complete. Final outcome grades were not inspected or assessed.

## Artifact and request integrity

Every file listed in FREEZE.json and ANALYSIS_FREEZE.json matches its SHA-256 digest. All 244 archived request and response bodies match their receipt hashes. The actual request messages equal the corresponding constructed prompt bytes, and phase generation settings match the frozen configuration. All 243 accepted outputs match their archived response content, hashes, usage, requested model identifier and stop finish reason. Native prompt counts are within their phase caps.

The observed request order is exactly the first 244 jobs of the frozen schedule. Every job has one attempt; minimum request-start spacing was 10.003756 seconds. There were 55 accepted extraction jobs, 55 accepted summary jobs and 133 accepted recall jobs.

Recorded cost recomputed from receipts is USD 4.230316875. The failed attempt's separate unknown-cost upper allowance is USD 0.030720000000000004; the conservative combined amount is USD 4.261036875. State accounting matches the receipts.

## Stop condition

The sole failure was the first attempt of alder_glass_01-q1-currency-ablated: HTTP 402, provider reason in_flight_budget_exhausted, Retry-After 120. The frozen retry whitelist excludes 402. The run stopped without another request, consistently with its stopping rule. This response does not establish that the user's entire account balance was zero or that the study's USD 15 cap was reached.

## Native and summary replay

For all five cases, the compressed complete native store equals the live JSONL store. The 275 immutable therapist/patient source pairs and all source-ID mappings match the scripted inputs.

I replayed all 55 native consolidations entirely in memory, supplying their original archived extraction responses. Each reconstructed extraction prompt equals its original constructed prompt. Accepted facts, rejected proposals, validation outcome, source IDs, batch IDs and extraction-response bytes reproduce exactly; no gold-fact insertion or semantic repair was needed.

Independent totals reproduce MEMORY_BUILD_AUDIT.json: 275 raw turns, 55 fact batches, 953 accepted historical/current facts, 135 rejected proposals, zero invalid batches and 55 summary updates. Rejection reasons are 77 unsupported committed-status assertions, 32 literal quote/value grounding failures and 26 invalid source/speaker/status proposals. These counts describe validation behavior, not answer accuracy.

All 55 rolling-summary prompts reproduce from the same session and preceding bounded summary. Bounded summaries reproduce exactly. None loses words to the cap; reported truncation count is zero.

## Retrieval reproduction

I independently reranked all 134 constructed recall contexts using saved vectors and the frozen native/RAG implementations. Selected item count, IDs, order and every non-score field matched. Rendered memory and complete prompt hashes matched exactly; every joined memory met the 1,800-token local estimate. No native A/B separator adjustment was required in these observed contexts.

In this independent process, 36 contexts differed only in the last bits of BM25 scores; the maximum absolute difference was 3.552713678800501e-15. Native score, cosine and RRF values matched exactly. The differences follow process-dependent summation order over query-term sets and did not change selected evidence or prompts.

I reviewed the separate recompute-v2.py amendment and ran it successfully. Its only semantic change is numerical tolerance for score/bm25/cosine/rrf comparisons; it still requires exact non-score content/order, budgets and memory/prompt hashes. Its result correctly reports PARTIAL with 134 checked contexts and 26 unconstructed contexts. The original frozen checker remains intact.

There are 133 accepted recall answers, not 134: one constructed context produced the 402 failure. Therefore 27 planned answers are missing: one failed and 26 never requested.

## Denominators and interpretation

| Arm | Accepted/all planned | Primary available/planned | Secondary available/planned | Fields available/planned |
|---|---:|---:|---:|---:|
| Native | 33/40 | 14/20 | 19/20 | 59/70 |
| Currency ablation | 33/40 | 14/20 | 19/20 | 59/70 |
| Raw RAG | 33/40 | 14/20 | 19/20 | 59/70 |
| Summary + RAG | 34/40 | 15/20 | 19/20 | 60/70 |

Only cobalt_fern_02 and saffron_echo_03 have all four primary questions available in every arm. The remaining histories have one, two and three complete A/B primary pairs, respectively. Thus only two of five histories can supply their complete four-question case contrast; the planned five-history mean must remain unavailable. A descriptive mean across those two histories must be labelled partial.

Static review of review.py confirms that it separates missing from failed content, reports planned/graded denominators, and returns no complete five-history mean unless all five case contrasts are complete. Accuracy claims and final rendered report consistency remain outside this technical audit until final analysis artifacts are available. Native source availability, literal coverage and validation status must not substitute for graded accuracy.

Audit completed at 2026-10-05T18:16:58.237217+00:00.
