#!/usr/bin/env python3
"""Fixed-study heartbeat wrapper: --check readonly; --run original frozen runner.

--run is authorized standing supervision; it snapshots only mutable state and
retrieval then invokes unchanged run.py --resume with no shell or parameter edits.
The wrapper itself never reads a key, calls the API, grades or changes the cap3.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from decimal import Decimal
import email.utils
import fcntl
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import uuid

TRANSIENT = {429, 502, 503, 504}
ROOT = Path("/Users/marco/Sites/LLMPatients-App/evaluation/reviewer-comment-1/outputs/state-update-retrieval-pilot-2026-10-05")
KEY_FILE = Path("/Users/marco/Sites/LLMPatients-Agent/config/openrouter-api-key.txt")
SUPERVISOR_LOCK = Path("/private/tmp/state-pilot-supervisor-20261006.lock")
CONTROL_NAME = "SUPERVISOR_CONTROL.json"
REPAIR_NAME = "SUPERVISOR_REPAIR.json"
EXPECTED_FREEZE_SHA256 = "19e4ad104d368f236966fce0e5c2bf0ccbd8cc7abe679917c085dea4ed66e929"
EXPECTED_ANALYSIS_FREEZE_SHA256 = "2ca3329db08c9050fa36e0a9149e2134c6a3d80c5f2f88807dab00997bef614a"


def require(value, message):
    if not value:
        raise ValueError(message)


def read(path):
    def pairs(items):
        data = {}
        for key, value in items:
            require(key not in data, "Duplicate JSON key")
            data[key] = value
        return data
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=pairs)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def decimal(value):
    require(type(value) in (int, float, str), "Invalid accounting value")
    result = Decimal(str(value))
    require(result.is_finite() and result >= 0, "Invalid accounting value")
    return result


def action(code, **details):
    return {"action": code, **details}


def retry_wait(receipt, now):
    if not receipt:
        return 0
    end = receipt.get("ended_at") or receipt.get("started_at")
    target = None
    if end:
        target = datetime.fromisoformat(end.replace("Z", "+00:00")).timestamp() + 900
    value = receipt.get("retry_after")
    if value:
        try:
            seconds = float(value)
            require(math.isfinite(seconds) and seconds >= 0, "Invalid Retry-After")
            if end:
                target = max(target, datetime.fromisoformat(end.replace("Z", "+00:00")).timestamp() + seconds)
        except ValueError:
            date = email.utils.parsedate_to_datetime(value)
            require(date.tzinfo is not None, "Ambiguous Retry-After date")
            target = max(target or 0, date.timestamp())
    return max(0, target-now.timestamp()) if target is not None else 0


def inflight_reason(value):
    """Require an exact structured reason, not a substring of an error message."""
    if isinstance(value, dict):
        return any((key in {"reason", "code", "type", "subcode", "error_code"} and
                    item == "in_flight_budget_exhausted") or
                   (isinstance(item, (dict, list)) and inflight_reason(item))
                   for key, item in value.items())
    if isinstance(value, list):
        return any(inflight_reason(item) for item in value)
    return False


def decision(state, config, receipts, inflight_402=False, remaining=1, now=None):
    """Pure rule; receives metadata only, never an answer or credential."""
    now = now or datetime.now(timezone.utc)
    status = state.get("status")
    if remaining == 0:
        return action("FINALIZE_REVIEW_ONLY", remaining_answers=0)
    if status == "COMPLETED":
        return action("HALT_INCONSISTENT_COMPLETION", remaining_answers=remaining)
    if status not in {"STOPPED", "RUNNING"}:
        return action("HALT_UNKNOWN_STATE")
    if status == "RUNNING":
        return action("HALT_INTERRUPTED_ACCOUNTING", reason="Runner lock is free but state says RUNNING; inspect durable recovery/accounting before another API call")
    require(config["max_attempts_per_job"] == 3, "Frozen cap unexpectedly changed")
    total = decimal(state["recorded_cost_usd"]) + decimal(state["unknown_cost_upper_usd"])
    phase = state.get("phase")
    require(phase in config["phases"], "Unknown stopped phase")
    limits = config["phases"][phase]
    reserve = decimal(limits["prompt_cap"])*decimal(config["pricing"]["prompt"]) + decimal(limits["max_tokens"])*decimal(config["pricing"]["completion"])
    if total + reserve > decimal(config["budget_usd"]):
        return action("HALT_BUDGET", conservative_cost_usd=str(total), next_call_reserve_usd=str(reserve))
    if not receipts:
        return action("HALT_UNCLASSIFIED_STOP", reason="No archived failure receipt; do not infer service failure from text alone")
    numbers = [row.get("attempt") for row in receipts]
    require(numbers == list(range(1, len(receipts)+1)), "Receipt numbering is not contiguous")
    latest = receipts[-1]
    require(latest["job_id"] == state["current_job"], "Receipt/stopped job differs")
    if latest.get("status") == "REQUESTED":
        return action("HALT_INTERRUPTED_ACCOUNTING", reason="Unresolved REQUESTED receipt; recover/reconcile offline")
    if latest.get("status") != "FAILED":
        return action("HALT_UNCLASSIFIED_STOP", reason="Current job has no terminal failed receipt")
    http, upstream = latest.get("http_status"), latest.get("upstream_error_code")
    if http in {401, 403} or upstream in {401, 403}:
        return action("HALT_AUTH_OR_ROUTING")
    retryable = (http in TRANSIENT or upstream in TRANSIENT or
                 latest.get("error") == "transport_timeout" or
                 (http == 402 and inflight_402))
    if not retryable:
        return action("HALT_NONTRANSIENT", http_status=http, upstream_error_code=upstream,
                      error=latest.get("error"))
    if len(receipts) >= 3:
        return action("RETRY_CAP_REQUIRES_AMENDMENT", attempts=len(receipts),
                      reason="Original client and accepted-answer validator both cap cumulative attempts at3")
    wait = retry_wait(latest, now)
    if wait > 0:
        return action("WAIT_RETRY_AFTER", minimum_wait_seconds=round(wait, 3))
    return action("RESUME_ORIGINAL", next_attempt=len(receipts)+1,
                  remaining_answers=remaining, conservative_cost_usd=str(total),
                  reason="Eligible transient; archive snapshot/amendment then invoke unchanged run.py --resume")


def inspect(root):
    root = Path(root).resolve()
    lock = root / ".runner.lock"
    require(lock.is_file(), "Collector lock is missing")
    with lock.open("rb") as file:
        try:
            fcntl.flock(file, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            return action("WAIT_RUNNING", reason="Original runner holds its exclusive lock")
        try:
            require(sha((root/"FREEZE.json").read_bytes()) == EXPECTED_FREEZE_SHA256,
                    "Original study freeze anchor changed")
            require(sha((root/"ANALYSIS_FREEZE.json").read_bytes()) == EXPECTED_ANALYSIS_FREEZE_SHA256,
                    "Original analysis freeze anchor changed")
            freeze = read(root / "FREEZE.json")
            for rel, expected in freeze["files"].items():
                path = (root / rel).resolve()
                require(path.is_relative_to(root) and path.is_file() and sha(path.read_bytes()) == expected,
                        "Scientific frozen artifact changed")
            analysis_freeze = read(root / "ANALYSIS_FREEZE.json")
            require(analysis_freeze["study_freeze_sha256"] == sha((root/"FREEZE.json").read_bytes()), "Analysis freeze differs")
            for rel, expected in analysis_freeze["files"].items():
                path = (root/rel).resolve()
                require(path.is_relative_to(root) and path.is_file() and sha(path.read_bytes()) == expected,
                        "Frozen analysis artifact changed")
            state, config, schedule = read(root/"run-state.json"), read(root/"config.json"), read(root/"schedule.json")
            require(state["freeze_sha256"] == sha((root/"FREEZE.json").read_bytes()), "Run state freeze differs")
            recall = schedule["recall"]
            remaining = sum(not (root/"requests"/row["job_id"]/"accepted.json").is_file() for row in recall)
            directory = root/"requests"/state["current_job"]
            require(directory.resolve().is_relative_to(root/"requests"), "Stopped job path escapes requests")
            receipts = [read(p) for p in sorted(directory.glob("attempt-*-receipt.json"))]
            inflight = False
            # Only a terminal HTTP402 error body is read; accepted outputs and
            # message content, grades, cards and keys are never inspected here.
            if receipts and receipts[-1].get("status") == "FAILED" and receipts[-1].get("http_status") == 402:
                payload_path = directory/f"attempt-{receipts[-1]['attempt']:02d}-response.json.gz"
                if payload_path.is_file():
                    payload = json.loads(gzip.decompress(payload_path.read_bytes()))
                    error = payload.get("error", {}) if isinstance(payload, dict) else {}
                    inflight = inflight_reason(error)
            result = decision(state, config, receipts, inflight_402=inflight, remaining=remaining)
            result["read_only"] = True
            return result
        finally:
            fcntl.flock(file, fcntl.LOCK_UN)


def write_new(path, value):
    with path.open("x", encoding="utf-8") as file:
        json.dump(value, file, indent=2, ensure_ascii=False, allow_nan=False)
        file.write("\n")


def control_path(root):
    return root/"continuations"/"automatic-resume"/CONTROL_NAME


def control_fingerprint(root):
    """Metadata fingerprints only; no private key content or grading reads."""
    try:
        config = read(root/"config.json")
    except (ValueError,KeyError,OSError):
        config = {}
    value = {"files":{}, "python":{}, "supervisor_sha256":sha(Path(__file__).read_bytes())}
    for rel in ("run-state.json", "config.json", "FREEZE.json", "ANALYSIS_FREEZE.json"):
        try:
            value["files"][rel] = sha((root/rel).read_bytes())
        except OSError as exc:
            value["files"][rel] = "UNREADABLE:"+type(exc).__name__
    if type(config.get("python")) is str:
        python = Path(config["python"])
        if python.exists():
            stat = python.stat()
            value["python"] = {"size":stat.st_size,"mtime_ns":stat.st_mtime_ns,"mode":stat.st_mode}
    return sha(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def repair_document_matches(root, control, path):
    repair = root/"continuations"/"automatic-resume"/REPAIR_NAME
    if not repair.is_file():
        return False
    record = read(repair)
    if type(record.get("recorded_at")) is not str:
        return False
    try:
        stamp = datetime.fromisoformat(record["recorded_at"].replace("Z", "+00:00"))
        blocked = datetime.fromisoformat(control["recorded_at"])
    except ValueError:
        return False
    return (record.get("blocked_control_sha256") == sha(path.read_bytes()) and
            record.get("repair_completed") is True and
            type(record.get("explanation")) is str and bool(record["explanation"].strip()) and
            stamp.tzinfo is not None and blocked.tzinfo is not None and stamp > blocked)


def check_with_control(root):
    baseline = inspect(root)  # Auth, budget, integrity and current live lock win.
    if baseline["action"] in {"WAIT_RUNNING", "HALT_AUTH_OR_ROUTING", "HALT_BUDGET",
                              "HALT_INCONSISTENT_COMPLETION", "HALT_NONTRANSIENT"}:
        return baseline
    path = control_path(root)
    if path.is_file():
        control = read(path)
        require(control["action"] in {"HALT_LOCAL_RUN_FAILURE", "HALT_PROCESS_TIMEOUT"}, "Invalid supervisor control latch")
        unchanged = control["fingerprint"] == control_fingerprint(root)
        if unchanged and not repair_document_matches(root, control, path):
            return action(control["action"], reason=control["reason"],
                          control_file=str(path), snapshot=control["snapshot"],
                          requires="Changed state/input fingerprint or repair-completed record bound to this exact control hash; invariant guards remain mandatory")
    return baseline


def latch_local_failure(root, folder, code, reason):
    path = control_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    record = {"action":code,"reason":reason,"recorded_at":datetime.now(timezone.utc).isoformat(),
              "fingerprint":control_fingerprint(root), "snapshot":str(folder),
              "scope":"Operational supervisor latch only; scientific run-state, source, parameters and attempts are untouched."}
    temporary = path.with_suffix(".tmp")
    with temporary.open("w", encoding="utf-8") as file:
        json.dump(record,file,indent=2,ensure_ascii=False,allow_nan=False)
        file.write("\n")
    temporary.replace(path)
    return record


def terminate_group(process):
    """Bounded cleanup of a dedicated process group, including descendants."""
    signals = []
    for sig, delay in ((signal.SIGTERM,5),(signal.SIGKILL,5)):
        try:
            os.killpg(process.pid,sig)
            signals.append(sig.name)
        except ProcessLookupError:
            pass
        try:
            process.wait(timeout=delay)
        except subprocess.TimeoutExpired:
            continue
    # Always send the group KILL pass, even if the leader exited on TERM.
    return {"signals":signals,"returncode":process.poll(),"cleanup_bound_seconds":10}


def worker_result(root, folder, before_counts, exit_code, timed_out, local_error, cleanup):
    """Archive first; preserve a latch even when post-exit inspect fails."""
    try:
        state = read(root/"run-state.json")
        after_counts = (state.get("attempts",0),state.get("completed_jobs",0))
        after = inspect(root)
        inspect_error = None
    except Exception as exc:
        after_counts = before_counts
        after = action("HALT_INTEGRITY_OR_PROTOCOL",reason=type(exc).__name__)
        inspect_error = type(exc).__name__
    progress = after_counts[0]>before_counts[0] or after_counts[1]>before_counts[1]
    live_race = after["action"] == "WAIT_RUNNING"
    code = ("HALT_PROCESS_TIMEOUT" if timed_out else
            "HALT_LOCAL_RUN_FAILURE" if (local_error or exit_code not in (None,0)) and not progress and not live_race else None)
    reason = ("External config run_timeout_seconds + request_timeout_seconds expired; process group terminated and reaped" if timed_out else
              "Original process failed locally without any increase in attempts or accepted jobs; old failure receipt must not trigger another launch")
    receipt = {"status":code or "ORIGINAL_RUNNER_EXITED","exit_code":exit_code,
               "ended_at":datetime.now(timezone.utc).isoformat(),"counts_before":before_counts,
               "counts_after":after_counts,"progress":progress,"after_gate":after,
               "local_error":local_error,"post_inspect_error":inspect_error,"timeout_cleanup":cleanup}
    log = folder/"worker-output.log"
    if log.is_file():
        receipt["log_sha256"] = sha(log.read_bytes())
    write_new(folder/"LAUNCH.json",receipt)
    if code:
        record = latch_local_failure(root,folder,code,reason)
        write_new(folder/"CONTROL_LATCH.json",record)
        return action(code,exit_code=exit_code,snapshot=str(folder),after_gate=after)
    return action("ORIGINAL_RUNNER_EXITED",exit_code=exit_code,snapshot=str(folder),after_gate=after)


def snapshot_before(root):
    """Caller holds native shared lock: source bytes are stable until sealed."""
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
    folder = root/"continuations"/"automatic-resume"/stamp
    folder.mkdir(parents=True, exist_ok=False)
    files = [root/"run-state.json"] + sorted((root/"retrieval").rglob("*.json"))
    manifest = {}
    for source in files:
        resolved = source.resolve()
        require(resolved.is_relative_to(root) and source.is_file(), "Snapshot source escapes fixed study")
        raw = source.read_bytes()
        relative = str(source.relative_to(root))
        destination = folder/"before"/relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as file:
            file.write(raw)
        require(destination.read_bytes() == raw and source.read_bytes() == raw, "Snapshot bytes changed")
        manifest[relative] = {"bytes":len(raw), "sha256":sha(raw)}
    write_new(folder/"BEFORE_MANIFEST.json", {
        "created_at":datetime.now(timezone.utc).isoformat(),"files":manifest,
        "study_freeze_sha256":sha((root/"FREEZE.json").read_bytes()),
        "supervisor_sha256":sha(Path(__file__).read_bytes()),
        "scope":"Immutable delta of run-state and retrieval only; historical tar archives, grades and keys are not copied.",
        "authorization":"Human standing authorization on2026-10-06 to complete the study and supervise automatic resumption every15minutes; cap3 and cumulativeUSD15 unchanged."})
    return folder, sha((root/"run-state.json").read_bytes())


def run_original():
    before = check_with_control(ROOT)
    if before["action"] != "RESUME_ORIGINAL":
        return before
    # Stable snapshot under native shared lock; a second collector cannot start.
    with (ROOT/".runner.lock").open("rb") as native:
        try:
            fcntl.flock(native, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            return action("WAIT_RUNNING")
        try:
            confirm = check_with_control(ROOT)
            if confirm["action"] != "RESUME_ORIGINAL":
                return confirm
            config = read(ROOT/"config.json")
            python = Path(config["python"])
            require(python.is_absolute() and python.is_file(), "Frozen Python unavailable")
            require(KEY_FILE.is_file(), "Configured private key file unavailable")
            folder, state_hash = snapshot_before(ROOT)
            state = read(ROOT/"run-state.json")
            before_counts = (state["attempts"],state["completed_jobs"])
        finally:
            fcntl.flock(native, fcntl.LOCK_UN)
    # Reacquire immediately before launch. Release so original runner can take
    # LOCK_EX; original nonblocking exclusive lock still resolves the final race.
    with (ROOT/".runner.lock").open("rb") as native:
        try:
            fcntl.flock(native, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            write_new(folder/"LAUNCH.json", {"status":"SKIPPED_NATIVE_RUNNING"})
            return action("WAIT_RUNNING", snapshot=str(folder))
        try:
            confirm = check_with_control(ROOT)
            if confirm["action"] != "RESUME_ORIGINAL" or sha((ROOT/"run-state.json").read_bytes()) != state_hash:
                write_new(folder/"LAUNCH.json", {"status":"SKIPPED_CHANGED_STATE","gate":confirm["action"]})
                return action("WAIT_CHANGED_STATE", snapshot=str(folder))
        finally:
            fcntl.flock(native, fcntl.LOCK_UN)
    environment = os.environ.copy()
    environment.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                       TOKENIZERS_PARALLELISM="false", PYTHONDONTWRITEBYTECODE="1")
    command = [str(python), "-B", str(ROOT/"run.py"), "--root", str(ROOT),
               "--key-file", str(KEY_FILE), "--resume"]
    # No shell; no alternate root, program, model, key path or flags from CLI.
    log = folder/"worker-output.log"
    started = datetime.now(timezone.utc).isoformat()
    hard_timeout = config["run_timeout_seconds"] + config["request_timeout_seconds"]
    require(type(hard_timeout) is int and hard_timeout>0, "Invalid external process timeout")
    write_new(folder/"LAUNCH_START.json",{"started_at":started,"hard_timeout_seconds":hard_timeout,
        "timeout_scope":"Whole child lifetime including bootstrap; config run timeout plus one request timeout, then at most10seconds TERM/KILL cleanup",
        "runner_sha256":sha((ROOT/"run.py").read_bytes()),
        "credential_scope":"Existing private key path passed directly; credential bytes never read by supervisor"})
    exit_code,timed_out,local_error,cleanup = None,False,None,None
    try:
        with log.open("xb") as output:
            process = subprocess.Popen(command,cwd=ROOT,env=environment,stdout=output,
                                       stderr=subprocess.STDOUT,start_new_session=True)
            try:
                exit_code = process.wait(timeout=hard_timeout)
            except subprocess.TimeoutExpired:
                timed_out = True
                cleanup = terminate_group(process)
                exit_code = process.returncode
    except OSError as exc:
        local_error = type(exc).__name__  # No raw exception/key contents in control logs.
    return worker_result(ROOT,folder,before_counts,exit_code,timed_out,local_error,cleanup)


def supervised(mode):
    # Fixed temporary coordination file; --check writes no App artifact.
    with SUPERVISOR_LOCK.open("a") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return action("WAIT_SUPERVISOR_RUNNING")
        try:
            return check_with_control(ROOT) if mode == "check" else run_original()
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def self_test():
    config = {"max_attempts_per_job":3, "budget_usd":15,
              "phases":{"answer":{"prompt_cap":8192,"max_tokens":2048}},
              "pricing":{"prompt":0.00000125,"completion":0.00001}}
    state = {"status":"STOPPED","current_job":"synthetic","phase":"answer",
             "recorded_cost_usd":4,"unknown_cost_upper_usd":0.1}
    receipt = {"job_id":"synthetic","attempt":1,"status":"FAILED","http_status":402,
               "error":"http_error","ended_at":"2026-10-06T10:00:00+00:00","retry_after":"120"}
    now = datetime.fromisoformat("2026-10-06T10:16:00+00:00")
    assert decision(state,config,[receipt],True,13,now)["action"] == "RESUME_ORIGINAL"
    assert decision(state,config,[receipt],False,13,now)["action"] == "HALT_NONTRANSIENT"
    assert decision(state,config,[receipt],True,13,datetime.fromisoformat("2026-10-06T10:02:00+00:00"))["action"] == "WAIT_RETRY_AFTER"
    assert decision(state,config,[dict(receipt,attempt=i) for i in (1,2,3)],True,13,now)["action"] == "RETRY_CAP_REQUIRES_AMENDMENT"
    assert decision(state,config,[dict(receipt,http_status=401)],True,13,now)["action"] == "HALT_AUTH_OR_ROUTING"
    assert decision(dict(state,recorded_cost_usd=15),config,[receipt],True,13,now)["action"] == "HALT_BUDGET"
    assert decision(state,config,[dict(receipt,status="REQUESTED")],True,13,now)["action"] == "HALT_INTERRUPTED_ACCOUNTING"
    assert decision(state,config,[receipt],True,0,now)["action"] == "FINALIZE_REVIEW_ONLY"
    assert inflight_reason({"metadata":{"reason":"in_flight_budget_exhausted"}})
    assert not inflight_reason({"message":"not in_flight_budget_exhausted"})
    assert decision(dict(state,status="COMPLETED"),config,[receipt],True,0,now)["action"] == "FINALIZE_REVIEW_ONLY"
    with tempfile.TemporaryDirectory(prefix="state-supervisor-lock-test-",dir="/private/tmp") as tmp:
        path = Path(tmp)/"lock"
        with path.open("a") as first, path.open("a") as second:
            fcntl.flock(first,fcntl.LOCK_EX|fcntl.LOCK_NB)
            try:
                fcntl.flock(second,fcntl.LOCK_SH|fcntl.LOCK_NB)
            except BlockingIOError:
                pass
            else:
                raise AssertionError("Occupied native lock not detected")
    print(json.dumps({"synthetic_only":True,"checks":12,"status":"PASS","provider_calls":0,"study_writes":0}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--check", action="store_true")
    modes.add_argument("--run", action="store_true")
    modes.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    try:
        if args.self_test:
            self_test()
        else:
            print(json.dumps(supervised("check" if args.check else "run"), ensure_ascii=False))
    except (ValueError, KeyError, OSError) as exc:
        print(json.dumps(action("HALT_INTEGRITY_OR_PROTOCOL", reason=type(exc).__name__), ensure_ascii=False))
        raise SystemExit(2)
