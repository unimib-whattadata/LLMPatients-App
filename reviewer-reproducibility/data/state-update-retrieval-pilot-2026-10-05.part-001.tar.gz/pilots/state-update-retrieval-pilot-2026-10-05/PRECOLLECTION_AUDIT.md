# Precollection audit

A separate native agent reviewed the concrete protocol and code before model collection. This was a shared-context development audit, not blinded outcome grading.

Corrections: zero-BM25 matches contribute no lexical reciprocal-rank score; budget reserves are durable before POST; summary packing preserves complete-sentence prefixes; joined memory budgets include separator bytes; authorized resume recovers durable successful responses and reconstructs counters. Unresolved archived responses fail closed.

Native source, historical facts, raw fallback and alias expansion remain intact. Currency ablation removes only a ranking tie-break and rendered current/superseded labels. Gold is isolated from API input. The first-attempt maximum is USD12.80; USD15 does not guarantee every retry. No first-collection blockers remained at the final audit.

The offline preflight and production encoder calibration passed before collection. A preflight fixture was corrected from a cap that accommodated its entire text to a smaller cap that actually exercised sentence packing; no model outcomes were involved.
