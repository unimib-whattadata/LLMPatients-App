# Audit finale del rapporto dopo la terza ripresa — 6 ottobre 2026

## Esito e perimetro

**PASS nel perimetro esaminato. Nessuna correzione materiale richiesta.** REPORT.md e DATA_INDEX.md aggiornati a 147 risposte sono coerenti con l'analisi rating-v4, le ricevute di rianalisi, le provenienze di valutazione/merge, RESUME_STATUS della terza ripresa e run-state.json.

Audit locale in sola lettura, senza rete, chiamate a modelli, chiavi, riavvii o modifiche App/LaTeX. Sono stati consultati documenti, analisi aggregate e metadati autorizzati. Non sono stati aperti file grezzi dei grader o schede e nessuna risposta è stata rivalutata. Questa nota è l'unico file scritto durante l'audit finale. Non sono stati aggiunti controlli estranei al mandato.

## Risultati e denominatori

- Stato **STOPPED**, **257/270 job accettati**, **261 tentativi**: 55 estrazioni, 55 riassunti, **147/160 risposte**.
- Analisi: native **37/37**, currency-ablated **37/37**, raw-rag **36/36**, summary-rag **37/37**; campi rispettivamente **65/65, 65/65, 64/64, 65/65**, totale **259/259**. Tutti i valori della Tabella 2 coincidono con l'analisi.
- Primarie **17/17 per ogni braccio**, su 20 pianificate; secondarie **20/20** per A/B/D e **19/19** per C, su 20 pianificate. I denominatori disponibili sono distinti da quelli pianificati.
- **13 risposte mancanti**: un tentativo con l'ultimo 402 e 12 job mai richiesti. La lista dell'analisi coincide esattamente con schedule meno accepted.
- **148 contesti**: 147 con risposta e uno per cobalt_fern_02-q6-raw-rag, terminato con 402; **12 contesti non costruiti**. L'inventario coincide con RETRIEVAL_RECOMPUTE.json e i file retrieval.
- Contrasti completi in **3/5 storie**: cobalt_fern_02, plum_lantern_04, saffron_echo_03. A–B, A–C e A–D sono zero in ciascuna. La media primaria completa sui cinque casi è **null/non disponibile**, correttamente distinta dai confronti disponibili. A–B resta il contrasto primario, A–C/A–D descrittivi.

Il 100% viene attribuito alle risposte disponibili, non a tutti gli esiti pianificati; le mancanze operative non vengono trasformate in errori fattuali.

## Provenienza della valutazione

Il rapporto descrive correttamente **quattro coppie di valutatori**, sui gruppi **133 + 8 + 4 + 2**. I **145 giudizi precedenti per serie A/B** sono riusati senza rivalutazione. La quarta coppia ha valutato soltanto **2 nuove risposte e 2 nuovi campi per valutatore**.

GRADING_PROVENANCE e MERGE_PROVENANCE concordano sui conteggi e sul riuso. Gli hash dei nuovi giudizi dichiarati nelle due provenienze coincidono; gli hash dei file combinati coincidono con gli input hash dell'analisi. L'accordo aggregato **259/259 campi e 147/147 domande**, senza adjudication necessaria, coincide con l'analisi. Non viene attribuita a un'unica coppia la valutazione dell'intero inventario.

Sono dichiarati anonimizzazione e contesti nuovi/isolati, modello richiesto gpt-6-astra con xhigh, identificativo servito indisponibile e possibili errori correlati da modello/rubrica condivisi. Queste caratteristiche sono riscontrate nelle provenienze dichiarate; le schede e i giudizi grezzi non sono stati riletti. L'accordo non è presentato come validazione clinica.

La preservazione di **67 file delle tre valutazioni storiche** è attestata dal **coordinatore in RESUME_STATUS.json**. Questo audit ne verifica la corretta descrizione e attribuzione della verifica, senza ripetere il confronto leggendo file di voto esclusi dal mandato.

## Stop, finestre temporali e costi

Il quarto HTTP 402 è correttamente collocato nella quarta finestra di raccolta, ossia terza ripresa manuale. Il motivo in_flight_budget_exhausted corrisponde al payload controllato nell'audit tecnico precedente; non viene interpretato come prova di saldo complessivo nullo. I tre job precedentemente falliti sono riusciti al secondo tentativo, mentre l'ultimo 402 ha arrestato la raccolta.

Costo registrato **USD 4,371429375**, incremento **USD 0,02038**, riserva distinta **USD 0,12288**, totale conservativo **USD 4,494309375**, entro USD 15. Stato, analisi e RESUME_STATUS concordano entro 1e-12. La riserva non è presentata come addebito osservato. Durata del quarto processo circa **2,90 minuti**, separata dagli altri processi, dagli intervalli e dalla valutazione AI.

Il testo distingue esplicitamente **valutazione AI in Codex dopo lo stop** e **verifiche locali**, precisando l'assenza di ulteriori chiamate di raccolta OpenRouter. Non descrive il grading AI come una verifica offline.

## Disegno e interpretazione

La descrizione mantiene l'ablazione circoscritta di etichette current/superseded e spareggio current; non la confonde con la rimozione di ogni struttura. Sono espliciti il limite di otto elementi per A/B, il recupero nei controlli C/D, il cap di 1.800 token stimati e la quota fino a 900 per il riassunto. Non si dichiara parità dei token effettivi.

L'interpretazione resta descrittiva: nessun vantaggio osservato; nessuna equivalenza o necessità universale dimostrata. Sono dichiarati effetto soffitto possibile, storie artificiali con schema temporale comune, una costruzione della memoria e una risposta per cella, dipendenza fra campi/domande, quattro finestre temporali, limiti dell'identificatore modello e assenza di inferenze sulla popolazione clinica. La media sui cinque casi non viene sostituita dai dati incompleti.

## Collegamenti, tabelle e ricalcolo

- **38 collegamenti relativi nel REPORT** (36 destinazioni distinte) e **79 nel DATA_INDEX** (76 distinte): **117 complessivi, tutti esistenti** e risolti contro la radice del pacchetto. Per schede e voti è stata verificata solo l'esistenza del percorso.
- Le quattro tabelle del rapporto hanno ciascuna didascalia e richiamo in prosa; anche la Tabella D1 dell'indice.
- Il comando di recupero usa recompute-v2.py, con esito PARTIAL 148/160 e tolleranza 1e-12 soltanto sui punteggi. Il ricalcolo indipendente di tutti i 148 contesti era già passato nell'audit della terza ripresa; selezione, ordine, testi e hash dei prompt erano esatti.
- Il comando aggregate punta a rating-v4 e ai giudizi combinati; viene richiesto di usarlo su una copia perché scrive gli output. Non si propone run.py/preflight.py per la verifica offline.
- Gli snapshot storici a 133, 141 e 145 risposte sono distinti dal pacchetto corrente a 147 e dai rispettivi manifest. L'istruzione su .runner.lock riguarda correttamente il solo helper su una copia trasferita.
- Gli hash di analysis.json e ANALYSIS.md corrispondono alla ricevuta OFFLINE_REANALYSIS v4. La ricevuta attesta ricalcolo byte-identical. Questo audit non ha rieseguito l'aggregatore, per non aprire i voti grezzi: sono stati verificati i risultati e gli hash dichiarati, senza replicare il grading.

## Chiusura

FINAL_REPORT_AUDIT.md presente durante la verifica è ancora la nota storica a 145 risposte; il coordinatore lo sostituirà con questa nota. RESULTS_MANIFEST.json e ARTIFACT_AUDIT.json finali saranno rigenerati dopo tale copia. La verifica dei collegamenti non attesta anticipatamente quel manifest futuro. Nessun altro rilievo materiale pendente nel perimetro esaminato; questa nota non autorizza nuove chiamate o riprese.

## Hash esaminati

- REPORT.md: `462dedebb9d80504dcb744580297a0e5e94fd53d31bf73a35855604062b4182d`.
- DATA_INDEX.md: `8d45b645f43439cb442433bf65f4fb4e65b844cca7fdbecf589396993dd339f4`.
- review/rating-v4/analysis.json: `572ce7de794eb4c035938f33e5743d895b9aa068548d222f12d76fa6b3c94d95`.
- review/rating-v4/ANALYSIS.md: `be2256931c23f8a5ed3f51a1baba5710a2fbfe2c86ad2996aae896d4572f79fe`.
