## Material Passport

- Origin Skill: ars-codex:academic-research-suite / experiment-agent
- Origin Mode: run + validate
- Origin Date: 2026-10-06
- Verification Status: ANALYZED — raccolta parziale; rianalisi deterministica verificata, generazione stocastica non replicata
- Version Label: state_update_retrieval_report_v4
- Upstream Dependencies: [protocollo](PROTOCOL.md), [freeze](FREEZE.json), [freeze analisi](ANALYSIS_FREEZE.json), [analisi corrente](review/rating-v4/analysis.json)

> **Invii sospesi per credito OpenRouter insufficiente:** l’ultimo HTTP 402 è `weight_exceeds_budget`, distinto dagli arresti temporanei precedenti. Il provider chiede una ricarica; il controllo non ripete richieste finché il problema resta irrisolto. [Ricevuta del blocco](continuations/automatic-control-2026-10-06/CREDIT_BLOCK_NOTIFICATION.json).

> **Aggiornamento operativo del 6 ottobre 2026:** raccolte **149/160 risposte**; 11 mancanti. La valutazione riportata sotto riguarda ancora le **147 risposte dello snapshot rating-v4** e non comprende le due aggiunte successive. È attivo un controllo automatico ogni 15 minuti per riprendere dopo arresti temporanei e completare poi la valutazione. [Autorizzazione e protocollo operativo](continuations/automatic-control-2026-10-06/AMENDMENT.md), [stato corrente](run-state.json).

# Aggiornamento e recupero della memoria lungo undici sessioni

## Risultati e stato al momento dell’ultima valutazione

**Nelle 147 risposte disponibili tutte e quattro le condizioni raggiungono il 100%: non si osserva un vantaggio della memoria strutturata.** Mancano 13 delle 160 risposte previste. La media primaria prevista sulle cinque storie resta **N/V**, perché il confronto non è completo in tutti e cinque i casi. I risultati descrittivi non dimostrano equivalenza o necessità generale della struttura.

La terza ripresa autorizzata ha aggiunto **2 risposte**, portando a quattro le finestre di raccolta. Il processo si è fermato immediatamente al quarto HTTP 402 della raccolta. Il payload indica `in_flight_budget_exhausted`: il budget disponibile considerando richieste in corso non permetteva quella richiesta, senza dimostrare un saldo complessivo nullo. Dopo lo stop sono state completate la valutazione AI in Codex e le verifiche locali; nessuna ulteriore chiamata a OpenRouter.

## Disegno e confronto

Cinque storie interamente simulate, scritte in anticipo, ciascuna con **11 sessioni di cinque scambi**: 55 sessioni, 275 coppie di interventi terapeuta/paziente e 550 enunciati. Alla fine vengono poste separatamente otto domande in ogni condizione. È un test dei componenti della memoria su conversazioni predeterminate, senza esecuzione dell'intera applicazione o generazione delle traiettorie dei pazienti.

La Tabella 1 descrive i quattro sistemi. Condividono profilo, archivio sorgente, istruzioni di risposta, domande e impostazioni. I metodi determinano quale memoria arriva al modello.

**Tabella 1. Condizioni confrontate.**

| Condizione | Memoria fornita alla domanda finale |
|---|---|
| **A — strutturata nativa** | Fatti estratti e validati, versioni e fonti, più eventuali enunciati grezzi recuperati da `EvidenceMemory`; massimo otto elementi selezionati. |
| B — ablazione | Stessa estrazione e stesso archivio di A; rimozione delle sole etichette `current/superseded` nel testo e della preferenza per `current` a parità di punteggio. Restano cronologia, autore, stato, collegamenti e altre strutture. |
| **C — cronologia grezza + RAG** | Scambi interi con autore e posizione temporale; ricerca lessicale BM25 e ricerca semantica MiniLM con fusione delle graduatorie. Nessun limite artificiale di otto scambi. |
| **D — riassunto progressivo + RAG** | Riassunto aggiornato una volta per sessione senza conoscere le domande finali, più scambi recuperati dall'archivio completo. |

Ogni condizione dispone di un **tetto di 1.800 token stimati di memoria**. D ne può assegnare fino a 900 al riassunto e usa il resto per il recupero; nessuno dei 55 riassunti ha richiesto tagli al contenuto. Sono uguali i tetti stimati, non i token effettivamente inviati. A e B inviano al massimo otto elementi recuperati, **non tutto il deposito**. La variabile nativa `current` vale entro un gruppo entità/attributo/autore/stato; non è una soluzione attesa che identifica automaticamente l'accordo corrente fra etichette diverse. B è un'ablazione circoscritta, non la rimozione di ogni struttura. [Protocollo](PROTOCOL.md), [implementazione](engine.py).

## Valutazione e risultati

Le quattro domande primarie verificano un titolo introdotto all'inizio, appuntamento attuale/precedente/solo proposto, luogo attuale/sostituito e attività completata/ancora pianificata. Le quattro secondarie riguardano annullamento e riconferma, autore dell'affermazione e promemoria concordato, identità presente anche nel profilo e un interno telefonico mai stabilito. Una domanda supera la prova soltanto se tutti i valori e le relazioni richiesti sono corretti e non contraddetti. Le risposte parziali falliscono; le chiamate mancanti non sono errori fattuali. [Rubrica congelata](RUBRIC.md).

La Tabella 2 riporta tutti gli esiti disponibili. I denominatori dopo la barra sono elementi valutati; erano previste 20 domande primarie, 20 secondarie e 70 campi per condizione.

**Tabella 2. Successi sulle risposte disponibili; raccolta parziale.**

| Condizione | Primarie corrette / disponibili | Secondarie corrette / disponibili | Totale corrette / disponibili | Mancanti / 40 | Campi corretti / disponibili |
|---|---:|---:|---:|---:|---:|
| A — strutturata | 17/17 (100%) | 20/20 (100%) | 37/37 (100%) | 3 | 65/65 (100%) |
| B — ablazione | 17/17 (100%) | 20/20 (100%) | 37/37 (100%) | 3 | 65/65 (100%) |
| C — cronologia + RAG | 17/17 (100%) | 19/19 (100%) | 36/36 (100%) | 4 | 64/64 (100%) |
| D — riassunto + RAG | 17/17 (100%) | 20/20 (100%) | 37/37 (100%) | 3 | 65/65 (100%) |

Il contrasto primario fissato è A meno B: punteggio sulle quattro domande primarie di ogni storia, poi media sui cinque casi. I confronti A–C e A–D sono descrittivi. Il confronto primario è completo in **3/5 storie**: `cobalt_fern_02`, `plum_lantern_04` e `saffron_echo_03`. In ciascuna di queste storie **A–B, A–C e A–D sono tutti 0 punti percentuali**. La media prevista sulle cinque storie resta non disponibile; i confronti parziali non la sostituiscono.

Esiti per caso, domanda e campo: [analysis.json](review/rating-v4/analysis.json), [ANALYSIS.md](review/rating-v4/ANALYSIS.md).

I **145 giudizi precedenti per serie A/B** sono stati riusati senza rivalutazione: 133 nella prima valutazione, otto nella prima ripresa e quattro nella seconda. Il [helper v2](continue_review_v2.py) verifica identità di schede, risposte, metadati e giudizi, inclusi gli hash dell’analisi precedente. Una **quarta coppia di valutatori AI nuovi e isolati** ha giudicato soltanto le **2 aggiunte (2 campi)**, con schede anonime e ordini distinti, senza bracci, prompt, risultati precedenti o giudizi del collega. L’accordo combinato è **259/259 campi** e **147/147 domande**; proviene da **4 coppie**, non da una sola coppia sull’intero inventario. Nessun disaccordo ha richiesto adjudication. Modello richiesto: `gpt-6-astra`, sforzo `xhigh`; identificativo effettivamente servito non disponibile. Modello richiesto e rubrica comuni possono produrre errori correlati: l’accordo non è validazione clinica. [Provenienza della valutazione](review/rating-v4/continuation/GRADING_PROVENANCE.json), [riuso](review/rating-v4/continuation/merged/MERGE_PROVENANCE.json).

## Impostazioni e dati conservati

Modello richiesto tramite **OpenRouter**: `google/gemini-2.5-pro`; tutti i 257 esiti accettati riportano lo stesso identificativo. Le quattro finestre sono documentate; lo stesso identificativo non prova una revisione immutabile di pesi o infrastruttura. `top_p=0.95`, ragionamento massimo 1.024, nessun seed API o `top_k`, fallback e compressione disabilitati. La Tabella 3 riporta i limiti congelati.

**Tabella 3. Parametri richiesti per fase.**

| Fase | Temperatura | Massimo output | Tetto locale del prompt completo |
|---|---:|---:|---:|
| Estrazione dei fatti | 0,2 | 8.192 | 16.384 |
| Aggiornamento del riassunto | 0,2 | 2.048 | 16.384 |
| Risposta finale | 0,7 | 2.048 | 8.192 |

[Configurazione](config.json), [prompt esatti](constructed-prompts/), [richieste e ricevute](requests/), [memorie e riassunti](runtime/). Versione nativa Agent `ef8972d7bde2e185b453730fbe71329e00b8eb73`: [SOURCE_PROVENANCE.json](SOURCE_PROVENANCE.json). MiniLM è fissato nel [manifest](source/embedding-source-manifest.json); i vettori utilizzati sono salvati.

La memoria contiene 275 scambi, 953 fatti accettati comprese le versioni e 135 proposte respinte; 55 batch di fatti e 55 riassunti, 0 batch invalidi e 0 riassunti troncati. Nessuna nuova estrazione o sintesi nella ripresa. Sono proprietà operative, non accuratezza delle risposte. [Audit della memoria](MEMORY_BUILD_AUDIT.json).

Totale: **257/270 lavori accettati**, **261 tentativi**, 147 risposte finali e 110 aggiornamenti. Errori conservati: 4 tentativi con HTTP 402 (http_error). Delle **13 risposte mancanti**, una è fallita e 12 non sono ancora state richieste. I tre precedenti job falliti sono riusciti al tentativo 02 nelle rispettive riprese autorizzate. [Stato corrente](run-state.json), [autorizzazione](continuations/resume-2026-10-06-03/RESUME_AUTHORIZATION.json), [stato della ripresa](continuations/resume-2026-10-06-03/RESUME_STATUS.json).

Risposte di errore conservate: [primo 402](requests/alder_glass_01-q1-currency-ablated/attempt-01-response.json.gz), [secondo](requests/plum_lantern_04-q3-native/attempt-01-response.json.gz), [terzo](requests/cobalt_fern_02-q6-summary-rag/attempt-01-response.json.gz), [quarto](requests/cobalt_fern_02-q6-raw-rag/attempt-01-response.json.gz).

Costo registrato totale **USD 4,371429375**; costo aggiuntivo della quarta finestra USD 0,02038. Riserva separata per costi non riportati **USD 0,12288**, non un addebito osservato. Totale conservativo **USD 4,494309375** entro il tetto cumulativo di **USD 15**. Ultimo processo: 2,9 minuti. Tempi per finestra conservati nei relativi stati; sono esclusi intervalli fra processi e valutazione AI. Non si inferisce un confronto completo dei costi dai dati parziali.

## Verifiche, preservazione e limiti

Prima di ogni ripresa sono stati salvati snapshot completi verificati a [133 risposte](continuations/resume-2026-10-06-01/partial-2026-10-05.tar.gz), [141](continuations/resume-2026-10-06-02/partial-141-answers.tar.gz) e [145](continuations/resume-2026-10-06-03/partial-145-answers.tar.gz), con rapporto, analisi e diagnostiche storiche. Nell’ultima ripresa i 255 output accettati, i 258 tentativi precedenti, tutti i relativi prompt, memorie, fonti e riassunti sono rimasti identici byte per byte. Sono rimasti identici anche i 67 file delle tre valutazioni precedenti. [Audit della terza ripresa](RESUME_03_AUDIT.md), [verifica finale del rapporto](FINAL_REPORT_AUDIT.md); gli audit precedenti restano conservati in [RESUME_AUDIT.md](RESUME_AUDIT.md) e [RESUME_02_AUDIT.md](RESUME_02_AUDIT.md).

Il [verificatore offline](recompute-v2.py) ricostruisce esattamente **148 contesti**: 147 con risposta e uno con l’ultimo 402; 12 non sono ancora stati costruiti. La sola tolleranza numerica dei punteggi (`1e-12`) è documentata nella [nota](RECOMPUTE_IMPLEMENTATION.md); selezione, ordine, contenuto e hash dei prompt restano esatti. Il verificatore originale resta conservato. [Esito del recupero](RETRIEVAL_RECOMPUTE.json), [rianalisi deterministica](review/rating-v4/OFFLINE_REANALYSIS.json). Nessuna modifica a scenari, impostazioni, rubrica o criterio primario.

Le cinque storie sono casi fissi degli sviluppatori con un modello temporale comune e correzioni ripetute: possono produrre un effetto soffitto e non discriminare questi sistemi. Una sola costruzione stocastica della memoria e una risposta per cella, raccolte in quattro finestre. Domande e campi sono dipendenti; non rappresentano pazienti indipendenti o una popolazione clinica. Il freeze locale non è preregistrazione pubblica. Il test riguarda componenti e un’ablazione circoscritta, non l’intera applicazione. Nessun p-value, intervallo di popolazione, equivalenza o necessità universale è dedotto dai conteggi.

**Interpretazione sostenuta:** nelle risposte disponibili tutte le condizioni rispondono correttamente; non emerge un vantaggio della memoria strutturata. L’eventuale assenza di differenze non dimostra equivalenza. La raccolta resta ferma: una prosecuzione richiede un’istruzione esplicita dell’utente e servizio disponibile, conservando gli output accettati.

### Controllo dell’interpretazione statistica: 11 aspetti

La Tabella 4 registra i limiti dell’interpretazione; è un controllo metodologico consultivo.

**Tabella 4. Controllo delle fallacie statistiche.**

| Aspetto | Valutazione |
|---|---|
| Paradosso di Simpson | Esiti aggregati, per caso e per categoria riportati; i confronti sulle storie complete sono distinti dai totali disponibili. |
| Fallacia ecologica | Nessuna inferenza su persone reali dai casi artificiali. |
| Paradosso di Berkson | Nessuna correlazione stimata; i casi progettati limitano la generalizzazione. |
| Bias da collider | Nessun aggiustamento o modello causale; disponibilità e mancanze esplicitate. |
| Trascurare il tasso di base | Nessun trasferimento dell’accuratezza a una prevalenza clinica reale. |
| Regressione verso la media | Nessuna selezione su punteggi estremi o interpretazione pre/post. |
| Bias di sopravvivenza | Tutte le 13 mancanze enumerate; accuratezza calcolata soltanto sulle risposte disponibili. |
| Ricerca selettiva dei risultati | Tutte le condizioni, successi, errori, parità e mancanze sono riportati. |
| Molteplicità delle scelte analitiche | Criteri congelati invariati, modifiche operative documentate; nessuna qualifica di preregistrazione pubblica. |
| Correlazione e causalità | Nessuna superiorità causale o necessità universale attribuita all’architettura. |
| Causalità inversa | Gli output finali non entrano nelle storie o nelle memorie. |

Il [DATA_INDEX.md](DATA_INDEX.md) contiene percorsi e comandi offline. Il rapporto aggiorna il pacchetto sperimentale; manoscritto e risposta LaTeX non sono modificati.
