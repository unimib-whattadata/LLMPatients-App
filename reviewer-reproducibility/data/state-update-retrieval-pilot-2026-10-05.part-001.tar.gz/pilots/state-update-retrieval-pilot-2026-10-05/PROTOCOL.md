## Material Passport

- Origin Skill: ars-codex:academic-research-suite / experiment-agent
- Origin Mode: run — prospective execution protocol
- Origin Date: 2026-10-05
- Verification Status: UNVERIFIED
- Version Label: state_update_retrieval_protocol_v1
- Upstream Dependencies: state_pilot_scenarios_20261005.json; state_pilot_scenario_notes_20261005.md; frozen Agent source and experiment configuration

# Updating and retrieving memory across eleven scripted sessions

## Question and scope

Does the production memory component's derived currency information improve accurate recall of changing arrangements, compared with the same extracted facts without that information? How do both conditions compare with competent retrieval from raw dialogue and with a rolling narrative summary supplemented by raw-dialogue retrieval?

This is a developer-designed, descriptive pilot of memory components. It replays predetermined dialogue through extraction and summary updates; it does not regenerate patients, execute the complete application or test clinical effectiveness. It can support a contribution under the tested conditions. It cannot establish that structured memory is universally necessary, superior to every alternative, or equivalent to an alternative after a tie.

The five histories were authored together without inspecting their extraction, summary or recall outcomes. Their values are distinct, but they share an event template. They are neither a public preregistration nor an independent held-out benchmark. All people and dialogue are fictional; the user authorized their submission to OpenRouter.

## Inventory and collection boundary

Each of five cases contains eleven sessions of five therapist/patient exchanges: 55 sessions, 275 exchanges and 550 utterances. After session eleven, eight ordinary questions are submitted separately in each of four conditions. Four positive-recall questions are primary; cancellation/reconfirmation, speaker authority, identity and an unestablished detail are secondary.

There is one memory build and one answer per case, condition and question: **55 native extraction jobs + 55 rolling-summary jobs + 160 recall jobs = 270 planned jobs**. Three local checkpoints per case, after sessions 3, 7 and 11, support provenance audits without additional model calls. Recall output never enters the scripted history or later memory.

Generation inputs contain only the shared fictional profile, relevant source dialogue or condition-produced memory, and the selected ordinary question. Gold values, field-source annotations, scenario notes, audit checkpoints, grading files and other conditions' answers are excluded. Case order, update order and recall schedule are fixed before collection; record the exact schedule and any local randomization seed separately from API settings.

## Conditions

All conditions have access to the same profile and source archive. They receive the same recall instructions, question text and generation settings. Their retrieval or summary methods determine which memory reaches the model. Packing checks include separators in the joined text. If native per-item packing slightly exceeds the complete-text estimate, the unchanged native selector is rerun with a smaller allowance until it fits; this deterministic separator adjustment is recorded and applied identically to A/B.

| Condition | Memory supplied at recall | Controlled boundary |
|---|---|---|
| A — native EvidenceMemory | Production retrieval and rendering of accepted facts and eligible raw-turn fallback | Native limit: eight returned evidence items and 1,800 conservatively estimated memory tokens |
| B — currency ablation | The same accepted extraction lineage, archive, related-value alias expansion and retrieval implementation | Remove only the derived current/superseded rendering and the currency ranking tie-break; retain assertion status, chronology, speaker, provenance, historical values and other structure |
| C — raw-dialogue RAG | Whole attributed therapist/patient turn pairs, retrieved from all raw dialogue | BM25 (`k1=1.5`, `b=0.75`) plus the same local MiniLM encoder; reciprocal-rank fusion (`k=60`, no lexical contribution for zero BM25 hits); exact question query; whole chunks packed to 1,800 estimated tokens |
| D — rolling summary + raw RAG | Query-independent summary updated once per session, plus retrieval from the complete raw archive | Summary capped at 900 estimated tokens; RAG receives the remainder of the 1,800-token allowance, including unused summary capacity |

For A and B, retain all historical fact versions and raw turns in the store. The native `current` value is derived within an entity/attribute/speaker/assertion-status group; it is not an oracle for the latest agreed arrangement across every extracted label. B is therefore a narrow currency ablation, not removal of extraction, updating, provenance or the entire structured architecture. Both conditions share exactly one extraction build per case.

C has no arbitrary eight-chunk cap and preserves speaker attribution and source chronology. Neither C nor D receives gold terms, target-specific expansions or hand-selected sources. D's summary update is told to retain values and temporal/status distinctions, but never receives final questions. Save the full generated summary; if it exceeds its allowance, keep a prefix of complete sentences/paragraphs in original order using the frozen boundary rule. Do not retain half a sentence or select material by its answer value. Report any truncation. Do not repair, regenerate or select summaries after seeing accuracy.

The production lexical/semantic retrieval, validation and quarantine behavior remain unchanged in A. The embedding model is the cached `sentence-transformers/all-MiniLM-L6-v2`, used locally on CPU for every semantic arm. Pin the model snapshot, relevant weight hashes, dependency versions and resulting embedding cache. The isolated SciPy dependency repair changes runtime loading, not the existing Agent environment or retrieval source.

## Memory replay and audit

Record every scripted turn with native source identifiers and a mapping back to the immutable case/session/turn/speaker coordinates. Consolidate each session once using the production extraction prompt, parser and validation rules. Preserve rejected or quarantined extractions and operational status; do not insert gold facts to remedy a miss. Independently update the narrative summary from that same session and its own preceding summary.

At recall, archive the constructed prompt, selected evidence or chunks, their scores/source identifiers, the full native store, summary versions and exact visible answer. Audit separately whether a value is supported in the raw archive, accepted into facts, selected at retrieval and correctly stated in the answer. Source availability and extraction coverage are diagnostic measurements, not substitutes for answer accuracy.

## Model, limits and cost

Provider: OpenRouter; requested model: `google/gemini-2.5-pro`. Record the returned model identifier, provider when present, generation ID, finish reason, usage and cost. Do not infer an immutable model revision from the requested identifier.

| Phase | Temperature | Maximum output tokens | Full local prompt cap | Reasoning budget |
|---|---:|---:|---:|---:|
| Native extraction | 0.2 | 8,192 | 16,384 | 1,024 |
| Summary update | 0.2 | 2,048 | 16,384 | 1,024 |
| Recall | 0.7 | 2,048 | 8,192 | 1,024 |

All phases use `top_p=0.95`. No API seed or top-k is supplied; no alternate model is allowed. Required-parameter routing is enabled and automatic context compression is explicitly disabled. Save exact request bodies and prompt hashes. Output limits include reasoning under the provider's accounting; retain usage rather than reconstructing it from visible answers alone.

Memory packing uses the production conservative estimate. Full prompt caps use the pinned local SentencePiece tokenizer; archive its hash and calibration provenance. Also report provider-native prompt usage. A shared estimated allowance is a resource control, **not a claim of equal actual token counts**.

The declared cost cap is **USD 15**, applied to recorded native costs plus a conservative upper allowance for attempts lacking cost metadata. Durably reserve one full uncached attempt before each send using the frozen public model prices (`USD 0.00000125/input token`, `USD 0.00001/output token`) and phase caps; reconcile that reserve when native cost metadata is available. The first-attempt maximum for all 270 jobs is USD 12.80; the cap does not guarantee enough headroom for every permitted retry. Price uncertainty or missing cost metadata can stop collection early. Report recorded charges and unknown-cost allowance separately; this client-side estimate is not a guarantee about later provider billing.

## Operational stopping rules

Requests are serial, at least ten seconds between starts, with a 300-second request timeout and a six-hour run window. At most three attempts are permitted per job, only for HTTP or in-band 429/502/503/504 or transport timeouts. The bounded backoff is 30 then 60 seconds, at least 60 seconds for 429; honor a larger Retry-After only within 600 seconds and the remaining run window. Archive every failed attempt and wait.

There is no retry for an inaccurate answer, unwanted wording, empty semantic extraction or poor summary. Native extraction validation may quarantine content as designed; preserve that outcome. Unresolved service failure, unexpected/non-transient failure, exhausted attempt count, exceeded prompt/cost/time limit or insufficient disk stops further calls and leaves the run explicitly partial. Do not automatically restart or resume the process. A later user-authorized resume must verify frozen hashes and reuse already accepted outputs without collecting extra variants; an exhausted job requires a documented amendment before additional attempts.

## Outcomes and grading

The primary outcome is complete-question accuracy over q1–q4: **20 questions per condition**. Each question succeeds only if every requested value and its state or relation are correct and uncontradicted; partial answers fail. Report category counts and each case's four-question score. The prespecified primary contrast is A minus B, computed within each of the five cases and then averaged; report C and D alongside both. Secondary questions contribute 20 per condition, all-question accuracy 40, and descriptive field accuracy 70. Slot day/time are two required components of one field, not extra independent observations.

Use [RUBRIC.md](RUBRIC.md) for matching and contradictions. Two fresh isolated graders independently receive opaque shuffled cards containing only the question, gold/criterion, permitted source evidence and visible answer. They receive no condition labels, generation prompts, token/cost metadata, answer-ID mapping or peer grades. Request `gpt-6-astra` at `xhigh`; report the requested versus observed grader model without inventing unavailable runtime metadata. A third similarly masked grader adjudicates disagreements. Derive question pass programmatically from adjudicated field judgments and contradiction flags; retain all original judgments and adjudications.

Transport failures are missing outputs, not factual errors silently relabeled as answers. If collection is incomplete, enumerate missing planned cells and report available descriptive scores with explicit denominators; do not present an incomplete subset as the complete primary comparison. Do not drop a difficult case or rerun a weak condition to complete a favorable table.

## Analysis and interpretation

Use counts, percentages, per-case contrasts, returned-source support and extraction diagnostics. The experimental unit for pairing is the fixed history; questions, fields and four answers to one question are dependent. No hypothesis-test p-values, population confidence interval, power claim or equivalence conclusion is planned. A large pooled percentage cannot imply five independent patients or independent scenario families.

Positive, tied, negative and partial results receive the same report. A–B identifies at most the contribution of the two removed currency mechanisms under this implementation; differences from C/D compare systems whose representations and retrieval differ. Neither contrast isolates all causes or proves necessity. Explicitly discuss the shared chronology, repeated corrections, small fixed inventory, one stochastic build and one answer per cell, summary/encoder implementation choices, and component replay rather than complete application behavior.

Before calls, freeze hashes for protocol, rubric, scenario inputs, gold, configuration, source snapshots, prompt builders and schedule. Timestamp this local freeze; do not call it public preregistration. Keep amendments as separate files with reasons and timing. Preserve exact requests/responses, retries, stores, prompts, selected evidence, grading and unfavorable cases; publish no credentials. The final report must link to these artifacts, provide offline recomputation and distinguish model-call reproducibility from deterministic reanalysis.
