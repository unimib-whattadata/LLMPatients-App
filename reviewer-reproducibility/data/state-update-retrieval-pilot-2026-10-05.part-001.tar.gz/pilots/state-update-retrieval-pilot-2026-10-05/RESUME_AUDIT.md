# Audit indipendente della ripresa — 6 ottobre 2026

## Esito e perimetro

Nessun problema tecnico di preservazione riscontrato. La ripresa autorizzata ha aggiunto **8 risposte accettate**, effettuando **9 tentativi**; si è fermata al secondo HTTP 402. Totale: **251 job accettati su 270**, cioè 55 estrazioni, 55 riassunti e **141 risposte su 160**. I tentativi complessivi sono **253**; mancano **19 risposte**.

Audit locale in sola lettura, senza rete o chiamate a modelli. Non sono stati letti output dei grader, schede di valutazione o file sotto `review/`; non è stata valutata la correttezza delle risposte. Nessuna scrittura nel pacchetto App o in LaTeX: questa nota è l'unico file scritto.

## Snapshot e preservazione

Archivio: `continuations/resume-2026-10-06-01/partial-2026-10-05.tar.gz`.

- SHA-256 verificato: `f4a450a83f59a4217811c17cef6fd7402c5da85c71dffa1a21d806f0eb73675d`, uguale a `RESUME_AUTHORIZATION.json`.
- Inventario: 1.919 file, 20.721.414 byte non compressi, come dichiarato. Lo stato archiviato coincide esattamente con `prior_state` nell'autorizzazione.
- Tutti i **1.218 file precedenti sotto `requests/`** sono identici byte per byte: ricevute e archivi dei 244 tentativi precedenti, i 243 `accepted.json` e i rispettivi `answer.txt`, incluse le 133 risposte precedenti.
- Tutti i **244 prompt precedentemente costruiti** sono identici byte per byte.
- Tutti i **251 file runtime precedenti** sono identici byte per byte: 5 store nativi, 5 copie complete compresse, 5 source map, 15 checkpoint, 55 consolidamenti, 55 riassunti completi, 55 riassunti bounded, 55 registrazioni del budget e la cache di 1.292 embedding. Nessuna nuova estrazione o chiamata di riassunto.
- I 5 file `inputs/`, i 10 file `source/`, configurazione, schedule, protocollo, rubric e codice controllati sono identici allo snapshot. `FREEZE.json` e `ANALYSIS_FREEZE.json` sono invariati. Verificati 30 hash della freeze di raccolta e tutti i 5 hash della freeze di analisi; i 10 percorsi della prima freeze sotto `review/` sono stati esclusi dalla lettura per rispettare il mandato.
- SHA-256 freeze di raccolta: `19e4ad104d368f236966fce0e5c2bf0ccbd8cc7abe679917c085dea4ed66e929`; freeze di analisi: `2ca3329db08c9050fa36e0a9149e2134c6a3d80c5f2f88807dab00997bef614a`.

Dei 134 file retrieval precedenti, 99 sono identici byte per byte. Gli altri 35 differiscono **esclusivamente in 42 valori BM25**, con differenza assoluta massima **3,552713678800501e-15**. Confronto ricorsivo: ogni altro campo, item, ordine, testo e hash di memoria/prompt è esattamente uguale. È la variazione floating point già documentata; non modifica gli input delle risposte. Lo snapshot conserva anche i valori diagnostici originari.

## Nuovi tentativi

I nuovi tentativi seguono esattamente i primi nove job ancora mancanti nell'ordine congelato:

| Job | Tentativo | Esito |
|---|---:|---|
| alder_glass_01-q1-currency-ablated | 02 | Accettato |
| alder_glass_01-q1-raw-rag | 01 | Accettato |
| alder_glass_01-q1-native | 01 | Accettato |
| plum_lantern_04-q4-currency-ablated | 01 | Accettato |
| plum_lantern_04-q4-raw-rag | 01 | Accettato |
| plum_lantern_04-q4-native | 01 | Accettato |
| plum_lantern_04-q4-summary-rag | 01 | Accettato |
| plum_lantern_04-q3-raw-rag | 01 | Accettato |
| plum_lantern_04-q3-native | 01 | HTTP 402, stop |

Il precedente 402 di `alder_glass_01-q1-currency-ablated` è conservato come tentativo 01. Il nuovo tentativo 02 ha un corpo di richiesta decompresso identico byte per byte al tentativo 01, SHA-256 `5863bce2315022b8bbbc0919fbeb3383978f1d05e44376f81a155d41baa0fea1`. I due contenitori gzip hanno nomi diversi nell'header e non sono identici come file compressi. Nessun job ha più di due tentativi; nessuna variante aggiunta per un job già accettato.

Verificati tutti i 253 archivi di richiesta/risposta contro gli hash delle ricevute, tutti i prompt contro i file costruiti e tutti i 251 accepted contro testo, hash, generation ID e usage della risposta originale. Tutte le richieste mantengono le impostazioni congelate. Le nuove risposte richiedono `google/gemini-2.5-pro`, temperatura 0,7, top_p 0,95, max_tokens 2.048, reasoning max_tokens 1.024, require_parameters=true, allow_fallbacks=false e context-compression disabilitata. Tutti i 251 esiti accettati riportano lo stesso identificatore modello e provider `Google`.

I cap locali e nativi sono rispettati; massimo budget memoria osservato nei 142 contesti: 1.800 token stimati. Tutti i 253 tentativi sono seriali senza sovrapposizioni. Intervallo minimo fra inizi nella ripresa: **10,005963 s**; nell'intera raccolta: **10,003756 s**.

Le nuove richieste iniziano fra il 5 ottobre 22:17:46,730958 UTC e il 5 ottobre 22:19:51,022847 UTC, cioè **6 ottobre 00:17–00:19 ora italiana**. La ripresa è una distinta finestra temporale autorizzata e va dichiarata; l'identificatore modello comune non prova l'identità dei pesi o dell'infrastruttura del provider tra finestre.

## Secondo 402 e costi

Payload attuale verificato direttamente:

- Job `plum_lantern_04-q3-native`, tentativo 01; HTTP/code 402.
- `metadata.reason`: `in_flight_budget_exhausted`; `metadata.limit_source`: `openrouter_in_flight_budget`.
- Il messaggio riferisce il superamento del budget disponibile considerando le richieste in corso; `Retry-After: 120`. Non dimostra un saldo del conto pari a zero.
- Ricevuta conclusa il 5 ottobre 22:19:51,269134 UTC; stato `STOPPED` registrato alle 22:19:51,270750 UTC. Nessun tentativo successivo nel pacchetto. Il codice esclude 402 dal retry automatico; nessun tentativo 02 per questo nuovo job.

Ricalcolo dai costi delle ricevute, verificati contro `usage.cost` originale:

| Voce | USD |
|---|---:|
| Costo registrato prima della ripresa | 4,230316875 |
| Incremento registrato, 8 risposte | 0,079063750 |
| Costo registrato totale | **4,309380625** |
| Riserva totale per costo non riportato, due 402 | **0,061440000** |
| Totale conservativo | **4,370820625** |
| Cap congelato | 15,000000000 |

Le riserve di 0,03072 USD per ciascun 402 non sono costi effettivamente addebitati conosciuti. Le differenze nelle ultime cifre dello stato JSON sono la rappresentazione floating point; il ricalcolo decimale concorda entro 1e-12.

## Denominatori e aggiornamento documentale

- Risposte disponibili: native 35/40; currency-ablated 35/40; raw-rag 36/40; summary-rag 35/40.
- Domande primarie disponibili: rispettivamente 16/20, 16/20, 17/20 e 16/20. Questi conteggi non sono punteggi di accuratezza.
- La primaria è completa in tutti e quattro i bracci ancora soltanto per **2/5 casi**: cobalt_fern_02 e saffron_echo_03. La media primaria sui cinque casi resta indisponibile.
- **142 contesti** costruiti = 141 risposte accettate + 1 richiesta terminata col nuovo 402; **18 contesti non ancora costruiti**. I 19 esiti mancanti includono quindi quel 402.
- La precedente analisi su 133 risposte va conservata come versione storica. Gli 8 nuovi esiti richiedono la valutazione prevista prima di aggiornare le percentuali; il nuovo report deve distinguere prosecuzione, stop e denominatori correnti.
- Le 250,022399 s di `elapsed_process_seconds` descrivono esclusivamente il processo di ripresa; non sostituiscono le 3.566,449555 s del primo processo. Somma dei due processi circa 3.816,471954 s, escluso l'intervallo fra essi.

Non emerge necessità di modificare la freeze per descrivere questa continuazione autorizzata dello stesso disegno. Restano da aggiornare separatamente documentazione e analisi derivate, conservando la versione precedente nello snapshot. Nessuna nuova chiamata è richiesta o autorizzata da questa nota.
