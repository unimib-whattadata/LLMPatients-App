# Eleven-session state/update/retrieval pilot

Developer-designed component replay of five fictional histories. Requested model: `google/gemini-2.5-pro`, through OpenRouter. This is a descriptive pilot; results cannot establish universal necessity of structured memory.

- [Protocol](PROTOCOL.md) and [grading rubric](RUBRIC.md)
- [Scenario construction](SCENARIO_NOTES.md) and gold-free [generation inputs](inputs/)
- [Frozen schedule](schedule.json), [settings](config.json), [source provenance](SOURCE_PROVENANCE.json)
- [Offline checks](PREFLIGHT.json), [precollection audit](PRECOLLECTION_AUDIT.md), [runtime calibration](source/runtime-calibration.json)
- Live collection status is recorded in `run-state.json`. Exact requests/responses are compressed without loss in `requests/`; selected evidence, constructed prompts and stores are saved separately.

The process has no automatic restart. User-authorized continuation requires the frozen inputs and accepted outputs to remain unchanged. Credentials are read only from the private key file at runtime and never included in the package.

After collection, retain masked independent grading and offline reanalysis alongside every favorable, tied, adverse or partial result.
