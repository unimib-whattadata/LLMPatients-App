# Audit del supervisor automatico — 6 ottobre 2026

**Esito: PASS nel perimetro verificato; nessun blocco materiale residuo.** I due difetti operativi individuati prima dell’uso sono stati corretti. Questa nota è un controllo tecnico consultivo, non una nuova autorizzazione né una modifica del protocollo scientifico.

## Artefatti esaminati

- Supervisor: `/private/tmp/state-pilot-supervisor-check-20261006.py`, SHA-256 `c23c3032db92c7865ea154d8a0144378a20e57ad9e4e0aff952f951a8657d598`.
- Nota operativa: `/private/tmp/state-pilot-supervisor-20261006-NOTE.md`, SHA-256 `cb644a07fd42e80874b5eaa99c38f0b11214109c7ff3a23af030e09fa6cac219`.
- Suite sintetica: `/private/tmp/state-pilot-supervisor-two-fixes-tests-20261006.py`.
- Destinazione fissa: pacchetto `state-update-retrieval-pilot-2026-10-05` nell’App; stato disponibile al controllo: raccolta arrestata dopo 148 risposte, 258 job accettati e 263 tentativi, come comunicato dal coordinatore. Non è stato ripetuto l’audit completo della delta di questa esecuzione.

## Controlli statici

La modalità `--check` legge metadati, inventario dei file accettati, freeze e, solo per un ultimo errore HTTP 402, il payload di errore archiviato. Non legge la chiave né gli output accettati o i giudizi. Il lock di coordinamento è in `/private/tmp`; questa modalità non scrive nel pacchetto App.

La modalità `--run` ha root e percorso della chiave fissi, usa il Python della configurazione verificata e un array di argomenti senza shell. Imposta i quattro flag HF_HUB_OFFLINE, TRANSFORMERS_OFFLINE, TOKENIZERS_PARALLELISM e PYTHONDONTWRITEBYTECODE senza sostituire HOME/CODEX_HOME. Il wrapper non legge i byte della credenziale. Invoca il runner originale con `--resume`; riuso degli output accettati, riserve, numerazione e contabilità rimangono quelli del client congelato.

Il lock esclusivo del supervisor serializza i wrapper. Lo snapshot di run-state e retrieval viene sigillato sotto lock condiviso nativo, con confronto dei byte sorgente/copia, hash e dimensioni. Una seconda verifica di gate e hash dello stato precede il lancio. L’ultimo intervallo fra rilascio e lancio resta protetto dal lock esclusivo del runner originale; un collector concorrente produce attesa, non un secondo flusso di chiamate. Gli stati WAIT_RUNNING e WAIT_SUPERVISOR_RUNNING vanno entrambi trattati dal heartbeat come attesa senza riavvio parallelo.

Il gate verifica le due ancore SHA originali e i rispettivi file congelati. Conserva budget cumulativo USD 15, riserve per costi ignoti e per la prossima richiesta, cap originale di tre tentativi, stop su contabilità interrotta e su errori non eleggibili. HTTP 402 è riprendibile soltanto con valore strutturato esatto `in_flight_budget_exhausted`; una citazione nel solo messaggio non basta. Il backoff è il massimo fra 900 secondi dall’ultimo errore e Retry-After. Non viene inferito alcun saldo dell’account.

## Correzioni dei due difetti

1. **Bootstrap/processo bloccato:** il limite esterno è 21.900 secondi, somma dei due limiti congelati, applicato all’intera vita del figlio incluso bootstrap. Popen crea una sessione dedicata; alla scadenza sono inviati TERM e KILL al gruppo, con attese limitate a complessivi dieci secondi e tentativo di reap. KILL non viene saltato se il processo principale termina già dopo TERM. Il margine può ridurre la finestra utile rispetto al timeout interno quando il bootstrap è lungo; è documentato e conservativo.
2. **Ripetizione del vecchio 402 dopo guasto locale:** timeout o uscita nonzero/errore di spawn senza incremento di tentativi o job accettati producono una ricevuta e un blocco operativo persistente separato dal run-state scientifico. Il blocco sopravvive ai tick con lo stesso fingerprint. È possibile riesaminare il gate dopo un cambiamento di stato/input oppure dopo un record di riparazione completata, datato e legato all’hash esatto del blocco. Non esiste reset generico da CLI; le guardie originali restano obbligatorie. La race con un altro collector vivo non viene classificata come fallimento locale.

## Verifica locale eseguita

- `--self-test`: PASS, dodici controlli sintetici su errori, budget, cap, backoff, ragione 402 e lock.
- Suite dei due difetti rieseguita: PASS; Popen simulato, bootstrap senza progresso, timeout, errore di spawn e verifica post-uscita fallita. Nessun secondo lancio dopo il medesimo guasto locale.
- Asserzioni indipendenti aggiuntive: PASS per TERM seguito sempre da KILL, attese di cinque secondi ciascuna, persistenza del blocco, rifiuto di una riparazione legata all’hash sbagliato, accettazione della riparazione esatta senza bypass del budget, assenza di un nuovo blocco locale nella race WAIT_RUNNING. Processi e segnali erano simulati.
- `--check` sul pacchetto reale: PASS; risposta `WAIT_RETRY_AFTER`, con 47,298 secondi residui al momento del controllo. Eseguito sotto audit-hook che rifiutava connessioni di rete, avvio di processi, letture della chiave/raw grading/card e scritture App. Nessuna violazione.

## Perimetro e limiti

Nessun `--run` reale, nessuna chiamata al provider o altro modello, nessuna lettura di credenziali, risposte, card o giudizi, nessuna scrittura App o LaTeX. I test dei processi sono simulati: non dimostrano il comportamento di un processo realmente non terminabile dal sistema operativo. Il lock nativo e il blocco persistente rimangono difese contro una nuova raccolta concorrente o non riconciliata. Questa nota non certifica disponibilità futura del provider né il completamento delle dodici risposte ancora mancanti.

Il wrapper conserva il cap tre. Se questo limite diventa il blocco concreto, prima di un tentativo quattro occorrono amendment operativo, client/runner e validatore/helper di analisi compatibili e versionati, preservando gli originali. L’autorizzazione permanente dell’utente permette il lavoro necessario; questa versione del supervisor non estende implicitamente il limite. La valutazione finale e il pacchetto aggiornato sono successivi al completamento della raccolta; i 147 giudizi rating-v4 restano storici e immutati.
