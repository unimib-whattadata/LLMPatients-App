# Offline retrieval-verification adjustment

After collection stopped and before outcome grading, the original frozen `recompute.py` found a last-bit BM25 score difference across Python processes (12.779390853913032 versus12.77939085391303). The query-term set iteration order is process-dependent. Selected items, order and content were identical in that check.

`recompute-v2.py` retains the frozen collector, inputs, original checker and all archived numerical scores. It requires identical selected item counts, order and every non-score field, plus exact rendered-memory and prompt hashes. Only the recomputed relevance scores use relative and absolute tolerance1e-12. Any selection, text, budget or hash difference still fails. This is an offline implementation amendment, not an outcome, extraction, sampling, grading or endpoint change. No new model calls were made.
