# Helper v2 per continuare i giudizi del pilota

Nuovo codice: `continue_review_v2.py`.
Non sostituisce `continue_review.py` né il precedente helper. Non modifica
freeze, rating-v1, rating-v2, giudizi originali o artefatti di raccolta.

## Motivo della versione

Lo snapshot rating-v2 ha **141 risposte già valutate**, comprese le 8 aggiunte
alla precedente raccolta di 133. I suoi giudizi completi si trovano in
`continuation/merged/grader-A.json` e `grader-B.json`; usare soltanto le vecchie
133 righe perderebbe i giudizi già acquisiti.

La funzione `resolve_old_grade_path(old_review, label)` considera esattamente
due candidati per ciascun valutatore:

1. `old_review/grader-X.json`;
2. `old_review/continuation/merged/grader-X.json`.

Deve esisterne **uno solo**. Percorsi ambigui, file mancanti, link fuori dallo
snapshot o hash non corrispondenti vengono rifiutati. Il file selezionato deve
coincidere in byte con `analysis.json` → `input_hashes.grader_A_sha256` oppure
`grader_B_sha256`. Si verificano anche i riferimenti dell'analisi al relativo
snapshot, freeze scientifico e script di analisi. `analysis.json` entra nella
provenienza sigillata insieme ai giudizi selezionati.

## Uso

Preparare il nuovo snapshot soltanto dopo l'arresto del collector. Il helper
non esegue `prepare`, non riavvia la raccolta e non chiama alcun modello.
Il contratto CLI resta invariato:

```sh
python3 -B continue_review_v2.py build \
  --root STUDY \
  --old-review STUDY/review/rating-v2 \
  --new-review STUDY/review/rating-v3 \
  --out STUDY/review/rating-v3/continuation

python3 -B continue_review_v2.py merge \
  --out STUDY/review/rating-v3/continuation \
  --a-new FRESH-A.json \
  --b-new FRESH-B.json
```

Se le 19 richieste mancanti vengono completate, il build riusa **141 giudizi**
e produce **19 schede nuove** per A/B. Se la raccolta si arresta nuovamente,
il conteggio viene ricavato dallo snapshot parziale effettivo. Nessuna richiesta
mancante viene convertita in un errore fattuale.

Ogni nuovo contesto isolato riceve **soltanto il proprio subset di nuove
schede e la rubrica**. Non fornire giudizi precedenti o del collega, mapping,
cartelle private, dati di raccolta o questa nota. Non rigradare i vecchi casi.

## Controlli mantenuti

Lock condiviso non bloccante per tutta l'operazione e stato collector
`STOPPED`/`COMPLETED`; sigilli vecchio/nuovo snapshot; bijezione per `job_id`;
schede identiche escluso `card_id`; uguaglianza degli hash dei byte originali
di metadati accettati e risposte; schema rigoroso tramite `load_grades`
congelato; nessun duplicato, overlap o giudizio mancante. Il merge rilegge i
141 giudizi originali risolti e confronta esattamente ogni riga riusata,
consentendo soltanto la sostituzione di `card_id`.

`BUILD_FREEZE.json` sigilla provenienza e file; il merge ricontrolla anche
`analysis.json` e rifiuta una sorgente dei vecchi voti diversa da quella del
build. Dopo il merge usare il consueto `review.py aggregate` con rating-v3 e
i due file completi in `continuation/merged/`, adjudicando le divergenze come
previsto dal protocollo.

## Verifiche effettuate senza rete né modifiche al pacchetto

- Rating-v2: resolver e `load_grades` congelato verificano **141/141** righe
  per ciascuno dei due valutatori; hash conformi all'analisi.
- Audit indipendente: entrambi i layout v1/v2 sono riconosciuti e validati;
  nessun blocco concreto del contratto rilevato.
- Fixture sintetiche esclusivamente in `/private/tmp`: layout piatto e
  annidato accettati; doppio candidato, hash alterato, link esterno e riferimento
  allo snapshot errato rifiutati.
- Originale `continue_review.py` e primo helper restano con SHA-256
  `2a033fed8123522a5802de6502da86c50f126b72585b5ace4128dfbd1749ff4c`.

Nessun build/merge v2→v3 è stato eseguito durante questi controlli perché il
nuovo snapshot non era ancora disponibile. L'helper verifica integrità e
schema dei giudizi; non certifica la loro correttezza semantica. Conservare
esternamente l'hash del freeze del build: i sigilli locali non sono firme.

Percorsi del codice adattati al pacchetto pubblicabile; implementazione originale invariata.
