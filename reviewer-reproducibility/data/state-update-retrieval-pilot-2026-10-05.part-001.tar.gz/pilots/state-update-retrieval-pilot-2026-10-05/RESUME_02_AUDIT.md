# Audit indipendente della seconda ripresa — 6 ottobre 2026

## Esito e perimetro

**PASS nel perimetro tecnico verificato.** La seconda ripresa manuale ha aggiunto **4 risposte accettate** in **5 nuovi tentativi**, fermandosi al terzo HTTP 402 della raccolta. Stato corrente: **255/270 job accettati, 258 tentativi, 145/160 risposte disponibili e 15 mancanti**. Estrazioni e riassunti restano 55+55.

Controllo locale in sola lettura, senza rete o chiamate a modelli. Non sono stati aperti file dei grader, schede o voti; nessuna risposta è stata valutata semanticamente. Nessuna modifica App/LaTeX: questa nota è l'unico file scritto. Il ricalcolo di recupero usa esclusivamente vettori già archiviati, con socket di connessione disabilitato nel processo di verifica.

## Snapshot a 141 risposte

Archivio: `continuations/resume-2026-10-06-02/partial-141-answers.tar.gz`.

- SHA-256 verificato: `a247dc65524679599ecd1c65dc3fb86eb85d886aeebf077d34c14931eb6c7c32`, uguale alla dichiarazione in `RESUME_AUTHORIZATION.json`.
- 2.011 file, 32.910.584 byte non compressi, corrispondenti all'autorizzazione. Il `run-state.json` archiviato coincide esattamente con `prior_state`: 251 accepted, 253 tentativi, 141 risposte.
- Tutti i **1.261 file precedenti sotto requests/** sono identici byte per byte: 253 ricevute con richieste/risposte archiviate, 251 accepted e rispettivi answer, comprese le 141 risposte precedenti. Nessun output accettato è stato rigenerato o sostituito.
- Tutti i **252 prompt precedenti** e tutti i **251 file runtime** sono identici byte per byte. Questi ultimi comprendono 5 store nativi, 5 copie complete compresse, 5 source map, 15 checkpoint, 55 consolidamenti, 55 riassunti completi, 55 riassunti bounded, 55 registrazioni del budget e cache con 1.292 embedding. Nessun nuovo tentativo di estrazione o riassunto.
- I 5 file inputs e i 10 file source sono identici allo snapshot. Configurazione, schedule, protocollo, rubric, codice collector/retrieval/review, helper originale e documentazione della tolleranza numerica controllati sono invariati.
- `FREEZE.json` e `ANALYSIS_FREEZE.json` invariati, SHA rispettivamente `19e4ad104d368f236966fce0e5c2bf0ccbd8cc7abe679917c085dea4ed66e929` e `2ca3329db08c9050fa36e0a9149e2134c6a3d80c5f2f88807dab00997bef614a`. Verificati 30 hash della prima freeze e tutti i 5 della seconda; esclusi dalla lettura i 10 percorsi della prima sotto review/, rispettando il mandato.

## Recupero e prompt

Confronto fra snapshot e file correnti: dei **142 retrieval precedenti**, 115 sono identici byte per byte. Gli altri **27** differiscono soltanto in **29 valori BM25**, differenza assoluta massima **3,552713678800501e-15**. Confronto ricorsivo rigoroso: item selezionati, ordine, tutti gli altri campi, contenuto e hash di memoria/prompt identici. Gli originali restano nello snapshot.

Eseguito inoltre un ricalcolo indipendente, senza encoder o modello, su **tutti i 146 contesti correnti** usando codice nativo e RAG congelati e i 1.292 vettori salvati. Esito: selezione, ordine, campi non numerici, memoria renderizzata e prompt identici; hash esatti. In questo processo 48 contesti/61 valori BM25 differiscono soltanto negli ultimi bit, massimo 3,552713678800501e-15, entro la tolleranza documentata 1e-12. Nessuna differenza di score nativo, cosine o RRF. Tetto massimo effettivamente osservato: **1.800 token stimati di memoria**.

**146 contesti = 145 risposte + contesto dell'ultimo 402; 14 contesti non costruiti.** I 15 esiti mancanti comprendono quindi il fallimento operativo corrente.

## Nuovi tentativi e impostazioni

Sequenza esatta dei primi cinque job mancanti nello schedule e nell'autorizzazione:

La Tabella 1 riporta i cinque nuovi tentativi nell’ordine eseguito.

**Tabella 1. Nuovi tentativi della seconda ripresa.**

| Job | Tentativo | HTTP/esito | Costo registrato USD |
|---|---:|---|---:|
| plum_lantern_04-q3-native | 02 | 200, accepted | 0,01023125 |
| plum_lantern_04-q3-summary-rag | 01 | 200, accepted | 0,01070375 |
| plum_lantern_04-q3-currency-ablated | 01 | 200, accepted | 0,01028875 |
| cobalt_fern_02-q6-native | 01 | 200, accepted | 0,01044500 |
| cobalt_fern_02-q6-summary-rag | 01 | 402, stop | non riportato |

Il vecchio tentativo 01 di plum_lantern_04-q3-native è conservato; il corpo decompresso della richiesta 02 è identico byte per byte a quello della richiesta 01, SHA-256 `afe5fe158eca8cf60b37ad8ca122324baa49a6dad7a7c141ccae17653729f479`. Nessun job ha più di due tentativi: 254 job con un tentativo e due job con due tentativi.

Verificati tutti i 258 archivi di richiesta/risposta contro gli hash delle ricevute; tutte le richieste contro i prompt costruiti e le impostazioni congelate; tutti i 255 accepted contro answer/hash, generation ID, usage e contenuto della risposta originale. Cap locali e nativi rispettati. I quattro nuovi esiti, come tutti i 255 accepted, riportano `google/gemini-2.5-pro` e provider `Google`.

Impostazioni delle nuove richieste: temperatura 0,7, top_p 0,95, output massimo 2.048, reasoning massimo 1.024, require_parameters=true, allow_fallbacks=false, context-compression disabilitata. Nessuna modifica di modello richiesto, parametri, endpoint, rubrica o metodi.

Tutti i 258 tentativi sono seriali senza sovrapposizione. Intervallo minimo fra inizi nella seconda ripresa **10,006664 s**; nell'intera raccolta **10,003756 s**. Le nuove richieste iniziano fra 6 ottobre 09:01:34,689364 e 09:02:15,334282 UTC, cioè 11:01–11:02 ora italiana. Durata del processo corrente: 189,151305 s, circa 3,15 minuti; non è la durata cumulativa delle tre finestre.

## Terzo 402 e contabilità

Payload dell'ultimo errore controllato direttamente:

- Job cobalt_fern_02-q6-summary-rag, tentativo 01, HTTP/code 402.
- `metadata.reason`: `in_flight_budget_exhausted`; `metadata.limit_source`: `openrouter_in_flight_budget`; Retry-After 120 secondi.
- Il messaggio riguarda il budget disponibile considerando richieste in corso; non attesta un saldo complessivo nullo.
- Risposta conclusa 09:02:15,576293 UTC; stato STOPPED salvato 09:02:15,577300 UTC. Nessun tentativo successivo nel pacchetto e nessun tentativo 02 per questo job. Il codice esclude 402 dal retry automatico.

Tutti i costi delle ricevute coincidono con usage.cost dei payload originali. Ricalcolo decimale:

La Tabella 2 riporta il ricalcolo dei costi e la riserva separata per gli errori.

**Tabella 2. Contabilità cumulativa dopo la seconda ripresa.**

| Voce | USD |
|---|---:|
| Registrato prima della seconda ripresa | 4,309380625 |
| Quattro nuovi esiti accettati | 0,041668750 |
| Registrato cumulativo | **4,351049375** |
| Riserva per costo non riportato dei tre 402 | **0,092160000** |
| Totale conservativo | **4,443209375** |
| Cap cumulativo congelato | 15,000000000 |

La riserva di 0,03072 per ciascun 402 non è un addebito osservato. Stato e ricevute concordano entro 1e-12; le ultime cifre differenti derivano dalla rappresentazione floating point.

## Denominatori per l'analisi successiva

- Native **37/40** risposte disponibili; currency-ablated, raw-rag e summary-rag **36/40** ciascuno.
- Primarie: **17/20 per ciascun braccio**. Secondarie: native **20/20**, gli altri **19/20**.
- Primaria completa nei quattro bracci per **3/5 casi**: cobalt_fern_02, plum_lantern_04 e saffron_echo_03. Plum è il nuovo caso primario completo. Media primaria sull'intero inventario di cinque casi ancora indisponibile.
- Questi sono conteggi di disponibilità, non punteggi di correttezza. I quattro nuovi esiti richiedono la valutazione prevista; non si possono estendere automaticamente i precedenti punteggi alle nuove risposte.
- La precedente analisi a 141 risposte resta storica. Il futuro inventario deve documentare il riuso dei 141 giudizi per serie A/B e la sola valutazione delle quattro aggiunte, senza presentarla come rivalutazione integrale.

Nessun blocco tecnico riscontrato per aggiornare offline gli artefatti derivati. Il collector resta fermo; questa nota non autorizza altre chiamate o riavvii.
