"""Frozen, serial OpenRouter transport with bounded retries and complete receipts."""
from datetime import datetime, timezone
import gzip
import hashlib
import http.client
import json
import math
from pathlib import Path
import shutil
import socket
import ssl
import time

from transport_reference import visible_response, retry_seconds, save_gzip, write_json, sha

def utc():
    return datetime.now(timezone.utc).isoformat()

class ServiceStopped(RuntimeError):
    pass

class Client:
    def __init__(self, root, key_file, tokenizer, config, state, resume=False):
        self.root, self.tokenizer, self.config, self.state = root, tokenizer, config, state
        self.secret = Path(key_file).read_text().strip()
        assert len(self.secret)>20
        self.started, self.last = time.monotonic(), 0.0
        self.resume=resume

    def persist(self):
        write_json(self.root/'run-state.json', self.state)

    def generate(self, prompt, job_id, phase):
        directory=self.root/'requests'/job_id
        accepted=directory/'accepted.json'
        if self.resume and not accepted.exists():
            # Recover a durable successful response without collecting a new
            # stochastic variant after an interrupted local file write.
            for receipt_path in sorted(directory.glob('attempt-*-receipt.json')):
                info=json.loads(receipt_path.read_text())
                if info.get('status') not in {'ACCEPTED','REQUESTED'}:continue
                response_path=directory/(receipt_path.name.replace('-receipt.json','-response.json.gz'))
                if not response_path.exists():continue
                payload=json.loads(gzip.decompress(response_path.read_bytes()))
                recovered,error,_=visible_response(payload,self.config['model'])
                if not recovered:
                    if info['status']=='REQUESTED':raise ServiceStopped('Unresolved archived response; explicit accounting required before resume')
                    raise ServiceStopped('Invalid previously accepted response')
                assert info['prompt_sha256']==sha(prompt.encode())
                assert payload['usage']['prompt_tokens']<=self.config['phases'][phase]['prompt_cap']
                recovered=recovered.rstrip()+'\n';(directory/'answer.txt').write_text(recovered)
                write_json(accepted,{'job_id':job_id,'phase':phase,'attempt':info['attempt'],
                    'prompt_sha256':sha(prompt.encode()),'answer_sha256':sha(recovered.encode()),
                    'model':payload['model'],'provider':payload.get('provider'),'generation_id':payload['id'],
                    'usage':payload['usage'],'finish_reason':payload['choices'][0]['finish_reason'],
                    'recovered_from_durable_response':True})
                break
        if accepted.exists():
            if not self.resume:raise ServiceStopped('Refuse automatic re-use of existing output')
            info=json.loads(accepted.read_text());text=(directory/'answer.txt').read_text()
            assert info['prompt_sha256']==sha(prompt.encode()) and info['answer_sha256']==sha(text.encode())
            accepted_files=list((self.root/'requests').glob('*/accepted.json'))
            self.state['completed_jobs']=len(accepted_files)
            self.state['by_phase']={p:sum(json.loads(f.read_text())['phase']==p for f in accepted_files)
                                    for p in self.config['phases']}
            self.persist();return text
        limits=self.config['phases'][phase]
        count=len(self.tokenizer.encode(prompt,out_type=int))
        if count>limits['prompt_cap']:
            raise ServiceStopped(f'Local prompt cap exceeded in {job_id}: {count}>{limits["prompt_cap"]}')
        if time.monotonic()-self.started>self.config['run_timeout_seconds']:
            raise ServiceStopped('Declared run timeout reached')
        if shutil.disk_usage(self.root).free<104857600:
            raise ServiceStopped('Less than100MiB free disk')
        body={k:self.config[k] for k in ['model','top_p','provider','plugins','reasoning']}
        body.update(temperature=limits['temperature'],max_tokens=limits['max_tokens'],
                    messages=[{'role':'user','content':prompt}])
        raw=json.dumps(body,ensure_ascii=False).encode()
        assert self.secret.encode() not in raw
        prior=sorted(directory.glob('attempt-*-receipt.json')) if directory.exists() else []
        first=len(prior)+1
        if first>3:raise ServiceStopped('Three previous failed attempts; explicit new protocol required')
        reserve=limits['prompt_cap']*self.config['pricing']['prompt']+limits['max_tokens']*self.config['pricing']['completion']
        for attempt in range(first,4):
            if time.monotonic()-self.started>self.config['run_timeout_seconds']:
                raise ServiceStopped('Declared run timeout reached')
            # Reserve a full uncached call before sending. Missing cost metadata
            # consumes this upper bound, retained separately from recorded cost.
            if self.state['recorded_cost_usd']+self.state['unknown_cost_upper_usd']+reserve>self.config['budget_usd']:
                raise ServiceStopped('Conservative budget reserve exhausted')
            wait=max(0,self.config['minimum_interval_seconds']-(time.monotonic()-self.last))
            if wait:time.sleep(wait)
            directory.mkdir(parents=True,exist_ok=True)
            prefix=f'attempt-{attempt:02d}'
            save_gzip(directory/(prefix+'-request.json.gz'),raw)
            receipt={'job_id':job_id,'phase':phase,'attempt':attempt,'started_at':utc(),
                     'local_prompt_tokens':count,'prompt_sha256':sha(prompt.encode()),
                     'request_sha256':sha(raw),'http_status':None,'status':'REQUESTED'}
            write_json(directory/(prefix+'-receipt.json'),receipt)
            # Reserve durably before POST: a interrupted request may be charged.
            self.state['unknown_cost_upper_usd']+=reserve
            receipt['pending_cost_upper_usd']=reserve
            write_json(directory/(prefix+'-receipt.json'),receipt)
            self.state['attempts']+=1;self.state['current_job']=job_id;self.state['phase']=phase;self.persist()
            print(f'REQUEST {self.state["completed_jobs"]+1}/{self.config["planned_jobs"]} {job_id} attempt={attempt}',flush=True)
            self.last=time.monotonic()
            conn=http.client.HTTPSConnection('openrouter.ai',timeout=self.config['request_timeout_seconds'],
                 context=ssl.create_default_context(cafile=str(self.root/'source/cacert.pem')))
            status,upstream,after,text,payload=None,None,None,None,None
            got_cost=False
            try:
                conn.request('POST','/api/v1/chat/completions',body=raw,
                             headers={'Authorization':'Bearer '+self.secret,'Content-Type':'application/json',
                                      'X-Title':'LLMPatients state-update-retrieval pilot'})
                response=conn.getresponse();status=response.status
                after=response.getheader('Retry-After')
                if after:after=after.replace(self.secret,'[REDACTED]')
                rb=response.read().replace(self.secret.encode(),b'[REDACTED]')
                save_gzip(directory/(prefix+'-response.json.gz'),rb)
                receipt.update(http_status=status,ended_at=utc(),response_sha256=sha(rb),retry_after=after)
                try:payload=json.loads(rb)
                except (ValueError,UnicodeDecodeError):payload=None
                cost=payload.get('usage',{}).get('cost') if isinstance(payload,dict) else None
                if isinstance(cost,(float,int)) and not isinstance(cost,bool) and math.isfinite(cost) and cost>=0:
                    got_cost=True;self.state['recorded_cost_usd']+=cost
                    self.state['unknown_cost_upper_usd']=max(0,self.state['unknown_cost_upper_usd']-reserve)
                    receipt['recorded_cost_usd']=cost
                if status==200 and isinstance(payload,dict):
                    text,error,upstream=visible_response(payload,self.config['model'])
                    try:upstream=int(upstream) if upstream is not None else None
                    except (ValueError,TypeError):pass
                    receipt.update(status='ACCEPTED' if text else 'FAILED',error=error,upstream_error_code=upstream)
                    if text and payload['usage']['prompt_tokens']>limits['prompt_cap']:
                        text=None;receipt.update(status='FAILED',error='native_prompt_cap_exceeded')
                else:receipt.update(status='FAILED',error='http_error' if status!=200 else 'invalid_json')
            except (socket.timeout,TimeoutError) as exc:
                receipt.update(status='FAILED',ended_at=utc(),error='transport_timeout',
                               exception=str(exc).replace(self.secret,'[REDACTED]'))
            except Exception as exc:
                receipt.update(status='FAILED',ended_at=utc(),error='transport_failure',
                               exception=(type(exc).__name__+': '+str(exc)).replace(self.secret,'[REDACTED]'))
            finally:conn.close()
            if not got_cost:
                receipt['unknown_cost_upper_usd']=reserve
            receipt.pop('pending_cost_upper_usd',None)
            if self.state['recorded_cost_usd']+self.state['unknown_cost_upper_usd']>self.config['budget_usd']:
                text=None;receipt.update(status='FAILED',error='budget_exceeded')
            write_json(directory/(prefix+'-receipt.json'),receipt);self.persist()
            if text:
                text=text.rstrip()+'\n';(directory/'answer.txt').write_text(text)
                write_json(accepted,{'job_id':job_id,'phase':phase,'attempt':attempt,
                    'prompt_sha256':sha(prompt.encode()),'answer_sha256':sha(text.encode()),
                    'model':payload['model'],'provider':payload.get('provider'),'generation_id':payload['id'],
                    'usage':payload['usage'],'finish_reason':payload['choices'][0]['finish_reason']})
                self.state['completed_jobs']+=1;self.state['by_phase'][phase]+=1;self.persist()
                print(f'ACCEPTED {self.state["completed_jobs"]}/{self.config["planned_jobs"]} cost_usd={self.state["recorded_cost_usd"]:.6f}',flush=True)
                return text
            retry=(status in {429,502,503,504} or upstream in {429,502,503,504} or receipt.get('error')=='transport_timeout')
            if not retry or attempt==3:
                raise ServiceStopped('Unresolved request failure: '+json.dumps({k:receipt.get(k) for k in ['job_id','attempt','http_status','upstream_error_code','error']}))
            delay=retry_seconds(after,attempt,status if status!=200 else upstream)
            if delay>600 or time.monotonic()-self.started+delay>self.config['run_timeout_seconds']:
                raise ServiceStopped('Retry wait exceeds declared window')
            receipt['retry_wait_seconds']=delay;write_json(directory/(prefix+'-receipt.json'),receipt)
            print(f'RETRY wait={delay:.0f}s http={status} upstream={upstream}',flush=True);time.sleep(delay)
