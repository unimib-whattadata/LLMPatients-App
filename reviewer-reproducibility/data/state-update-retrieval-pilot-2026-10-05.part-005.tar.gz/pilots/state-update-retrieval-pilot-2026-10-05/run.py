"""Replay frozen scripted sources; no automatic restart and no gold in calls."""
import argparse
import fcntl
import gzip
import json
from pathlib import Path
import sys
import time

from client import Client, ServiceStopped, utc
from engine import Encoder, answer_prompt, bound_summary, load_memory, rag, sha, summary_prompt
from transport_reference import write_json

def verify(root):
    freeze=json.loads((root/'FREEZE.json').read_text())
    for path,digest in freeze['files'].items():
        assert sha((root/path).read_bytes())==digest,'Frozen file changed: '+path
    return freeze

def save_prompt(root,job,prompt):
    path=root/'constructed-prompts'/f'{job}.txt'
    path.parent.mkdir(exist_ok=True)
    if path.exists():assert path.read_text()==prompt,'Changed persisted prompt: '+job
    else:path.write_text(prompt)

def run(root,key_file,resume=False):
    freeze=verify(root);config=json.loads((root/'config.json').read_text())
    schedule=json.loads((root/'schedule.json').read_text())
    lock=(root/'.runner.lock').open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    statefile=root/'run-state.json'
    if statefile.exists():
        if not resume:raise SystemExit('Existing run: refuse automatic restart or overwrite')
        state=json.loads(statefile.read_text())
        if state['status']=='COMPLETED':raise SystemExit('Completed run; no restart')
        assert state['freeze_sha256']==sha((root/'FREEZE.json').read_bytes())
        state.setdefault('explicit_resumptions',[]).append(utc())
    else:
        if resume:raise SystemExit('No prior run to resume')
        state={'status':'RUNNING','started_at':utc(),'completed_jobs':0,'attempts':0,
               'recorded_cost_usd':0.0,'unknown_cost_upper_usd':0.0,
               'by_phase':{'extraction':0,'summary':0,'answer':0},
               'planned_jobs':config['planned_jobs'],'freeze_sha256':sha((root/'FREEZE.json').read_bytes())}
    # Only this import/runtime calibration runs before the client reads a key.
    sys.path.append(config['agent_site_packages'])
    import sentencepiece
    tokenizer=sentencepiece.SentencePieceProcessor(model_file=str(root/'source/tokenizer.model'))
    encoder=Encoder(root,config)
    native=load_memory(root);ablated=load_memory(root,True)
    client=Client(root,key_file,tokenizer,config,state,resume=resume)
    state.update(status='RUNNING',process_started_at=utc());client.persist()
    started=time.monotonic()
    cases={cid:json.loads((root/'inputs'/cid/'case.json').read_text()) for cid in schedule['case_order']}
    try:
        for cid in schedule['case_order']:
            case=cases[cid];pid=cid;tid='scripted-therapist'
            store=native['JsonlMemoryStore'](root/'runtime/native')
            memory=native['EvidenceMemory'](store)
            mapping=[];previous=''
            for session in case['sessions']:
                si=session['session_index'];sid=f's{si:02d}'
                records=[]
                for turn in session['turns']:
                    record=memory.record_turn(patient_id=pid,therapist_id=tid,session_id=sid,
                        turn_index=turn['turn_index'],therapist_text=turn['therapist'],patient_text=turn['patient'])
                    records.append(record);mapping.append({'script_source_id':turn['turn_id'],'native_source_id':record['id'],
                                                           'session_index':si,'turn_index':turn['turn_index']})
                write_json(root/'runtime'/cid/'source-map.json',mapping)
                for phase in schedule['memory_order'][cid][str(si)]:
                    job=f'{cid}-s{si:02d}-{phase}'
                    if phase=='extraction':
                        def generate(prompt):
                            verify(root);save_prompt(root,job,prompt)
                            return client.generate(prompt,job,'extraction')
                        memory.consolidate_session(patient_id=pid,therapist_id=tid,session_id=sid,
                                                   generate=generate,invalid_policy='quarantine')
                        status=memory.consolidation_status(pid,tid,sid)
                        write_json(root/'runtime'/cid/f'{sid}-consolidation.json',status)
                        # On resume an already persisted batch bypasses its call.
                        assert (root/'requests'/job/'accepted.json').exists()
                    else:
                        prompt=summary_prompt(previous,records);verify(root);save_prompt(root,job,prompt)
                        full=client.generate(prompt,job,'summary')
                        previous=bound_summary(full,config['summary_memory_cap'],native['estimated_tokens'])
                        directory=root/'runtime'/cid;directory.mkdir(parents=True,exist_ok=True)
                        (directory/f'{sid}-summary-full.txt').write_text(full)
                        (directory/f'{sid}-summary-bounded.txt').write_text(previous)
                        write_json(directory/f'{sid}-summary-budget.json',{
                            'full_estimated_tokens':native['estimated_tokens'](full),
                            'bounded_estimated_tokens':native['estimated_tokens'](previous),
                            'full_local_tokens':len(tokenizer.encode(full,out_type=int)),
                            'bounded_local_tokens':len(tokenizer.encode(previous,out_type=int)),
                            'was_truncated':full.split()!=previous.split()})
                if si in {3,7,11} and not (root/'runtime'/cid/f'{sid}-checkpoint.json').exists():
                    write_json(root/'runtime'/cid/f'{sid}-checkpoint.json',{
                        'raw_turns':len([r for r in memory._records(pid,tid) if r['type']=='conversation_turn']),
                        'all_validated_facts':memory.current_facts(pid,tid,include_history=True),
                        'current_facts':memory.current_facts(pid,tid)})
            archive=store.file_path(pid,tid).read_bytes()
            (root/'runtime'/cid/'complete-native-store.jsonl.gz').write_bytes(gzip.compress(archive,mtime=0))
            encoder.save()
            print('MEMORY_READY '+cid,flush=True)
        for item in schedule['recall']:
            cid,qid,arm=item['case_id'],item['question_id'],item['arm'];job=item['job_id']
            case=cases[cid];question=next(q for q in case['questions'] if q['question_id']==qid)
            pid,tid=cid,'scripted-therapist'
            store=native['JsonlMemoryStore'](root/'runtime/native')
            memory=native['EvidenceMemory'](store);records=memory._records(pid,tid)
            if arm in {'native','currency-ablated'}:
                scope=native if arm=='native' else ablated
                engine=scope['EvidenceMemory'](store)
                allowance=config['memory_cap']
                while True:
                    selected=engine.retrieve(patient_id=pid,therapist_id=tid,query=question['text'],
                        limit=8,token_budget=allowance,embed=encoder.embed)
                    rendered=scope['render_evidence'](selected,token_budget=allowance)
                    excess=native['estimated_tokens'](rendered)-config['memory_cap']
                    if excess<=0:break
                    allowance-=max(1,excess)
                audit={'selected':selected,'policy':arm,'limit':8,'effective_packing_cap':allowance}
            elif arm=='raw-rag':
                rendered,selected=rag(records,question['text'],config['memory_cap'],native,encoder)
                audit={'selected':selected,'policy':arm}
            else:
                summary=(root/'runtime'/cid/'s11-summary-bounded.txt').read_text()
                remaining=config['memory_cap']-native['estimated_tokens'](summary)
                retrieved,selected=rag(records,question['text'],remaining,native,encoder)
                rendered=summary+'\n'+retrieved
                audit={'summary':summary,'selected':selected,'rag_allowance':remaining,'policy':arm}
            # Independently budget the body; reserve fixed separator overhead
            # by rerunning the same whole-chunk packing with one less token.
            while native['estimated_tokens'](rendered)>config['memory_cap']:
                if arm!='summary-rag':raise ServiceStopped('Unexpected renderer memory cap excess')
                remaining-=max(1,native['estimated_tokens'](rendered)-config['memory_cap'])
                retrieved,selected=rag(records,question['text'],remaining,native,encoder)
                rendered=summary+'\n'+retrieved;audit.update(selected=selected,rag_allowance=remaining)
            assert native['estimated_tokens'](rendered)<=config['memory_cap']
            prompt=answer_prompt(case['profile'],rendered,question['text'])
            audit.update(memory_estimated_tokens=native['estimated_tokens'](rendered),
                         memory_local_tokens=len(tokenizer.encode(rendered,out_type=int)),
                         full_prompt_local_tokens=len(tokenizer.encode(prompt,out_type=int)),
                         memory_sha256=sha(rendered.encode()),prompt_sha256=sha(prompt.encode()),
                         case_id=cid,question_id=qid)
            write_json(root/'retrieval'/f'{job}.json',audit)
            save_prompt(root,job,prompt);verify(root);encoder.save()
            client.generate(prompt,job,'answer')
        assert state['completed_jobs']==config['planned_jobs']
        state.update(status='COMPLETED',finished_at=utc(),elapsed_process_seconds=time.monotonic()-started)
        client.persist();encoder.save();return 0
    except BaseException as exc:
        state.update(status='STOPPED',stopped_at=utc(),stop_reason=str(exc).replace(client.secret,'[REDACTED]'),
                     elapsed_process_seconds=time.monotonic()-started)
        client.persist();encoder.save()
        print('STOPPED '+state['stop_reason'],flush=True)
        if isinstance(exc,(KeyboardInterrupt,ServiceStopped)):return 2
        raise

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--key-file',type=Path,required=True)
    parser.add_argument('--resume',action='store_true',help='Only after explicit human authorization')
    args=parser.parse_args();raise SystemExit(run(args.root,args.key_file,args.resume))
