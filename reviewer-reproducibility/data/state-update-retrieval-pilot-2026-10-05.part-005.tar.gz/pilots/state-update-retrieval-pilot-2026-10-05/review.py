#!/usr/bin/env python3
"""Offline masked review and deterministic reanalysis of the frozen memory pilot.

No network, model client, embeddings, credential access or memory writes.
Usage:
  python3 state_pilot_review.py prepare --root STUDY --out REVIEW
  python3 state_pilot_review.py aggregate --root STUDY --review-dir REVIEW --a A.json --b B.json
  python3 state_pilot_review.py aggregate --root STUDY --review-dir REVIEW --a A.json --b B.json --adjudication C.json
  python3 state_pilot_review.py self-test

prepare refuses an incomplete recall inventory unless --allow-partial is explicit.
An incomplete preparation is sealed; use a fresh output directory if more calls
subsequently finish. aggregate exits 3 when independent adjudication is needed.
"""
from __future__ import annotations

import argparse
import ast
from collections import Counter
from datetime import datetime
from decimal import Decimal
import gzip
import hashlib
import json
import math
from pathlib import Path
import random
import re
import shutil
import statistics
import sys
import tempfile

SCHEMA = 1
ARMS = ("native", "currency-ablated", "raw-rag", "summary-rag")
ARM_NAMES = {"native": "A: native EvidenceMemory", "currency-ablated": "B: currency ablation",
             "raw-rag": "C: raw-dialogue RAG", "summary-rag": "D: rolling summary + raw RAG"}
PRIMARY = {"q1", "q2", "q3", "q4"}
REVIEW_SEED = 202610051901


class ReviewError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ReviewError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_pairs(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "Duplicate JSON key: " + key)
        value[key] = item
    return value


def read_json(path):
    def nonfinite(value):
        raise ReviewError("Non-finite JSON number: " + value)
    return json.loads(Path(path).read_text(encoding="utf-8"), object_pairs_hook=unique_pairs,
                      parse_constant=nonfinite)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    text = json.dumps(value, indent=2, ensure_ascii=False, sort_keys=True, allow_nan=False) + "\n"
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8")
    temporary.replace(path)


def strict_keys(value, keys, label):
    require(type(value) is dict, label + " must be an object")
    require(set(value) == set(keys), label + " keys differ: " + str(sorted(set(value) ^ set(keys))))


def numeric(value, label, integer=False):
    require(type(value) in ((int,) if integer else (int, float)), label + " must be numeric, not Boolean")
    require(math.isfinite(value) and value >= 0, label + " must be finite and nonnegative")
    return value


def fraction(passes, graded, planned=None):
    result = {"pass": passes, "graded": graded, "percentage": 100 * passes / graded if graded else None}
    if planned is not None:
        result.update(planned=planned, missing=planned - graded, complete=planned == graded)
    return result


def frozen(root):
    root = Path(root).resolve()
    freeze = read_json(root / "FREEZE.json")
    for relative, digest in freeze["files"].items():
        target = (root / relative).resolve()
        require(target.is_relative_to(root), "Frozen path outside study")
        require(target.exists() and sha(target.read_bytes()) == digest, "Frozen file changed: " + relative)
    return freeze


def inventory(root):
    freeze = frozen(root)
    schedule = read_json(root / "schedule.json")
    config = read_json(root / "config.json")
    case_ids = schedule["case_order"]
    require(len(case_ids) == 5 and len(set(case_ids)) == 5, "Expected five unique fixed cases")
    cases, gold, questions, utterances = {}, {}, {}, {}
    for case_id in case_ids:
        case = read_json(root / "inputs" / case_id / "case.json")
        require(case["case_id"] == case_id, "Case ID mismatch")
        require(len(case["sessions"]) == 11, "Expected eleven sessions per case")
        cases[case_id] = case
        private = read_json(root / "review" / "private" / (case_id + "-gold.json"))
        require(private["case_id"] == case_id, "Gold case ID mismatch")
        qmap = {q["question_id"]: q for q in case["questions"]}
        gmap = {g["question_id"]: g for g in private["gold"]}
        require(len(qmap) == len(case["questions"]) == len(gmap) == len(private["gold"]) == 8 and set(qmap) == set(gmap), "Question/gold inventory mismatch")
        require(sum(len(q["requested_fields"]) for q in qmap.values()) == 14, "Expected fourteen fields per case")
        for qid, question in qmap.items():
            require(type(question["primary"]) is bool and question["primary"] == (qid in PRIMARY), "Primary flags mismatch")
            require(set(question["requested_fields"]) == set(gmap[qid]["expected"]), "Gold field keys differ")
            require(set(question["requested_fields"]) == set(gmap[qid]["field_sources"]), "Source field keys differ")
            questions[(case_id, qid)] = question
            gold[(case_id, qid)] = gmap[qid]
        source_ids = set()
        for session in case["sessions"]:
            require(len(session["turns"]) == 5, "Expected five exchanges per session")
            for turn in session["turns"]:
                require(turn["turn_id"] not in source_ids, "Duplicate scripted source")
                source_ids.add(turn["turn_id"])
                utterances[(case_id, turn["turn_id"])] = {
                    "source_id": turn["turn_id"], "session_index": session["session_index"],
                    "turn_index": turn["turn_index"], "speaker": "therapist", "text": turn["therapist"]}
        for item in gmap.values():
            for sources in item["field_sources"].values():
                for source in sources:
                    require(source["speaker"] == "therapist", "Gold source must be therapist")
                    observed = utterances[(case_id, source["source_id"])]
                    require(all(source[k] == observed[k] for k in ("session_index", "turn_index", "speaker")), "Source coordinates mismatch")
    planned = schedule["recall"]
    expected = {(cid, qid, arm) for cid in case_ids for qid in ["q" + str(i) for i in range(1, 9)] for arm in ARMS}
    triples = [(row["case_id"], row["question_id"], row["arm"]) for row in planned]
    require(len(planned) == 160 and set(triples) == expected and len(set(triples)) == 160, "Recall schedule is not the complete factorial inventory")
    require(len({row["job_id"] for row in planned}) == 160, "Duplicate recall job ID")
    jobs = {}
    for cid in case_ids:
        for i in range(1, 12):
            for phase in ("extraction", "summary"):
                jobs[f"{cid}-s{i:02d}-{phase}"] = {"case_id": cid, "phase": phase}
    for row in planned:
        jobs[row["job_id"]] = dict(row, phase="answer")
    require(len(jobs) == config["planned_jobs"] == 270, "Expected 270 planned jobs")
    return {"freeze": freeze, "schedule": schedule, "config": config, "cases": cases,
            "gold": gold, "questions": questions, "utterances": utterances, "jobs": jobs}


def accepted_answer(root, job, phase, config):
    directory = root / "requests" / job
    accepted_path = directory / "accepted.json"
    if not accepted_path.exists():
        return None
    accepted = read_json(accepted_path)
    require(accepted["job_id"] == job and accepted["phase"] == phase, "Accepted job or phase mismatch")
    require(accepted["model"] == config["model"] and accepted["finish_reason"] == "stop", "Unacceptable model or finish reason")
    numeric(accepted["attempt"], "attempt", integer=True)
    require(1 <= accepted["attempt"] <= config["max_attempts_per_job"], "Invalid accepted attempt")
    answer_path = directory / "answer.txt"
    require(answer_path.exists(), "Accepted answer text is missing: " + job)
    answer_bytes = answer_path.read_bytes()
    answer = answer_bytes.decode("utf-8")
    require(bool(answer.strip()) and sha(answer_bytes) == accepted["answer_sha256"], "Accepted answer hash mismatch: " + job)
    prompt_path = root / "constructed-prompts" / (job + ".txt")
    require(prompt_path.exists() and sha(prompt_path.read_bytes()) == accepted["prompt_sha256"], "Accepted prompt hash mismatch: " + job)
    usage = accepted["usage"]
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        numeric(usage[key], "usage." + key, integer=True)
    numeric(usage["cost"], "usage.cost")
    require(usage["prompt_tokens"] <= config["phases"][phase]["prompt_cap"], "Native prompt cap exceeded")
    receipt_path = directory / f'attempt-{accepted["attempt"]:02d}-receipt.json'
    require(receipt_path.exists(), "Accepted receipt missing")
    receipt = read_json(receipt_path)
    require(receipt["job_id"] == job and receipt["attempt"] == accepted["attempt"], "Accepted receipt mismatch")
    require(receipt["status"] in {"ACCEPTED", "REQUESTED"}, "Accepted output has failed receipt")
    require(receipt["prompt_sha256"] == accepted["prompt_sha256"], "Receipt prompt hash mismatch")
    for suffix, hash_key in (("request", "request_sha256"), ("response", "response_sha256")):
        path = directory / f'attempt-{accepted["attempt"]:02d}-{suffix}.json.gz'
        require(path.exists(), "Accepted request/response archive missing")
        payload = gzip.decompress(path.read_bytes())
        if hash_key in receipt:
            require(sha(payload) == receipt[hash_key], "Archived " + suffix + " hash mismatch")
    response = json.loads(gzip.decompress((directory / f'attempt-{accepted["attempt"]:02d}-response.json.gz').read_bytes()))
    require(not response.get("error") and response.get("model") == accepted["model"], "Archived response error/model mismatch")
    require(type(response.get("choices")) is list and len(response["choices"]) == 1, "Archived choices inventory mismatch")
    require(response.get("usage") == usage and usage["prompt_tokens"] > 0, "Accepted usage differs from archived response")
    choice = response["choices"][0]
    require(not choice.get("error") and choice["finish_reason"] == "stop" and response["id"] == accepted["generation_id"], "Archived accepted response mismatch")
    content = choice["message"].get("content")
    if isinstance(content, list):
        content = "\n".join(block.get("text", "") for block in content if isinstance(block, dict) and block.get("type") == "text")
    require(isinstance(content, str) and content.rstrip() + "\n" == answer, "Visible answer differs from archived response")
    return {"metadata": accepted, "answer": answer, "accepted_file_sha256": sha(accepted_path.read_bytes())}


def card_for(row, answer, inv, opaque_id):
    pair = (row["case_id"], row["question_id"])
    question, gold = inv["questions"][pair], inv["gold"][pair]
    source_ids = set(source["source_id"] for sources in gold["field_sources"].values() for source in sources)
    evidence = [inv["utterances"][(row["case_id"], sid)] for sid in sorted(source_ids)]
    return {"card_id": opaque_id, "question": question["text"],
            "requested_fields": question["requested_fields"], "expected": gold["expected"],
            "criterion": gold.get("criterion", ""), "field_sources": gold["field_sources"],
            "source_evidence": evidence, "answer": answer}


def opaque(label, job, seed):
    return "card-" + sha((str(seed) + "\x00" + label + "\x00" + job).encode())[:24]


def protect_output(root, out):
    require(out != root, "Review output must use its own directory")
    for prefix in (root / "source", root / "inputs", root / "runtime", root / "requests", root / "constructed-prompts", root / "retrieval"):
        require(not out.is_relative_to(prefix), "Review output overlaps collection artifacts")


def prepare(root, out, seed=REVIEW_SEED, allow_partial=False):
    root, out = Path(root).resolve(), Path(out).resolve()
    protect_output(root, out)
    require(not out.exists(), "Refuse to replace an existing review directory; choose a fresh one")
    inv = inventory(root)
    known_jobs = set(inv["jobs"])
    require(all(path.parent.name in known_jobs for path in (root / "requests").glob("*/accepted.json")), "Unexpected accepted job")
    accepted, missing = {}, []
    for row in inv["schedule"]["recall"]:
        answer = accepted_answer(root, row["job_id"], "answer", inv["config"])
        if answer is None:
            missing.append(row)
        else:
            accepted[row["job_id"]] = answer
    require(allow_partial or not missing, f"Recall inventory incomplete ({len(accepted)}/160); --allow-partial is required")
    out.mkdir(parents=True)
    manifest = {}
    maps = {}
    for label in ("A", "B"):
        cards, mapping = [], {}
        for row in inv["schedule"]["recall"]:
            job = row["job_id"]
            if job not in accepted:
                continue
            card_id = opaque(label, job, seed)
            require(card_id not in mapping, "Opaque ID collision")
            cards.append(card_for(row, accepted[job]["answer"], inv, card_id))
            mapping[card_id] = {**row, "answer_sha256": accepted[job]["metadata"]["answer_sha256"],
                                "accepted_file_sha256": accepted[job]["accepted_file_sha256"]}
        random.Random(str(seed) + "-" + label).shuffle(cards)
        payload = {"schema_version": SCHEMA,
                   "instructions": "Read only these cards and the supplied frozen RUBRIC.md. Grade every card independently. Do not inspect collection files, mappings, prompts or other grader outputs. No generation conditions are identified.",
                   "cards": cards}
        card_path = out / "cards" / ("grader-" + label + ".json")
        map_path = out / "private" / ("grader-" + label + "-map.json")
        write_json(card_path, payload)
        write_json(map_path, {"schema_version": SCHEMA, "reviewer": label, "cards": mapping})
        for path in (card_path, map_path):
            manifest[str(path.relative_to(out))] = sha(path.read_bytes())
        maps[label] = mapping
    if len(accepted) > 1:
        ordered_jobs = {label: [maps[label][card["card_id"]]["job_id"] for card in read_json(out / "cards" / ("grader-" + label + ".json"))["cards"]] for label in ("A", "B")}
        require(ordered_jobs["A"] != ordered_jobs["B"], "Independent card orders unexpectedly identical")
    rubric = out / "RUBRIC.md"
    rubric.write_bytes((root / "RUBRIC.md").read_bytes())
    manifest["RUBRIC.md"] = sha(rubric.read_bytes())
    snapshot = {"schema_version": SCHEMA, "study_freeze_sha256": sha((root / "FREEZE.json").read_bytes()),
                "script_sha256": sha(Path(__file__).read_bytes()), "masking_seed": seed,
                "complete_recall_inventory": not missing, "accepted_recall_jobs": sorted(accepted),
                "missing_planned_cells": missing, "files": manifest,
                "masking_scope": "Different opaque IDs and order per grader; common gold therapist evidence. No arm, generation prompt, token/cost metadata or actual source-availability diagnostics in cards. Visible answers remain verbatim."}
    write_json(out / "private/review-snapshot.json", snapshot)
    (out / "README.md").write_text(
        "# Offline review package\n\n"
        f"Accepted recall cells: {len(accepted)}/160. This snapshot is {'complete' if not missing else 'partial'}; missing calls are not factual failures.\n\n"
        "Provide each fresh isolated grader only its own `cards/grader-A.json` or `cards/grader-B.json` and `RUBRIC.md`. Request `gpt-6-astra` with `xhigh`; observed runtime identity must be recorded separately when available. Keep `private/` and all collection artifacts out of grader access. Preserve visible answers, including any incidental condition disclosure.\n\n"
        "Save strict JSON as an array of objects using the frozen rubric schema (or an object with only a `grades` array). Do not add question-pass scores or stringify Booleans. Run `aggregate` with both files. Exit 3 means the generated adjudicator package needs a fresh isolated third grader. Supply only `cards/adjudicator.json` and `RUBRIC.md`, without peer judgments. Re-run `aggregate --adjudication FILE` after saving its JSON.\n\n"
        "The program makes no model calls. Grading does not establish clinical validation. Source diagnostics are literal/provenance checks, not semantic accuracy. The main contrast uses five fixed histories, with no p-values or equivalence claim.\n", encoding="utf-8")
    print(json.dumps({"prepared": str(out), "accepted_recall": len(accepted), "missing": len(missing)}))
    return 0


def sealed_review(root, review, inv):
    snapshot = read_json(review / "private/review-snapshot.json")
    require(snapshot["study_freeze_sha256"] == sha((root / "FREEZE.json").read_bytes()), "Study freeze changed since masking")
    require(snapshot["script_sha256"] == sha(Path(__file__).read_bytes()), "Analysis script changed since masking")
    for relative, digest in snapshot["files"].items():
        path = (review / relative).resolve()
        require(path.is_relative_to(review) and path.exists() and sha(path.read_bytes()) == digest, "Review artifact changed: " + relative)
    currently_accepted = sorted(row["job_id"] for row in inv["schedule"]["recall"] if (root / "requests" / row["job_id"] / "accepted.json").exists())
    require(currently_accepted == snapshot["accepted_recall_jobs"], "Accepted recall inventory changed; prepare a fresh review snapshot")
    packages, mappings = {}, {}
    for label in ("A", "B"):
        packages[label] = read_json(review / "cards" / ("grader-" + label + ".json"))
        mappings[label] = read_json(review / "private" / ("grader-" + label + "-map.json"))["cards"]
        require(set(mappings[label]) == {card["card_id"] for card in packages[label]["cards"]}, "Card/map IDs differ")
        for card in packages[label]["cards"]:
            row = mappings[label][card["card_id"]]
            observed = accepted_answer(root, row["job_id"], "answer", inv["config"])
            require(observed is not None and card["answer"] == observed["answer"], "Masked answer differs from accepted answer")
            require(row["accepted_file_sha256"] == observed["accepted_file_sha256"], "Accepted metadata changed since masking")
            require(card == card_for(row, observed["answer"], inv, card["card_id"]), "Masked card contains altered gold or evidence")
    return snapshot, packages, mappings


def load_grades(path, cards):
    raw = read_json(path)
    if type(raw) is dict:
        strict_keys(raw, ["grades"], "Grade wrapper")
        raw = raw["grades"]
    require(type(raw) is list, "Grades must be an array")
    card_map = {card["card_id"]: card for card in cards}
    require(len(card_map) == len(cards), "Duplicate card ID in package")
    result = {}
    for row in raw:
        strict_keys(row, ["card_id", "fields", "additional_contradiction", "contradiction_reason"], "Grade row")
        card_id = row["card_id"]
        require(type(card_id) is str and card_id in card_map and card_id not in result, "Unknown or duplicate graded card")
        require(type(row["additional_contradiction"]) is bool, "additional_contradiction must be a JSON Boolean")
        require(type(row["contradiction_reason"]) is str, "contradiction_reason must be a string")
        require(not row["additional_contradiction"] or bool(row["contradiction_reason"].strip()), "Contradiction needs a reason")
        card = card_map[card_id]
        strict_keys(row["fields"], card["requested_fields"], "Field judgments")
        for field, judgment in row["fields"].items():
            strict_keys(judgment, ["pass", "reason", "answer_excerpt"], "Field judgment")
            require(type(judgment["pass"]) is bool, "Field pass must be a JSON Boolean; strings and integers are forbidden")
            require(type(judgment["reason"]) is str and bool(judgment["reason"].strip()), "Field reason must be nonempty")
            excerpt = judgment["answer_excerpt"]
            require(type(excerpt) is str and (not excerpt or excerpt in card["answer"]), "Answer excerpt must be empty or a verbatim visible-answer substring")
        result[card_id] = row
    require(set(result) == set(card_map), "Missing graded cards")
    return result


def question_pass(grade):
    return all(field["pass"] for field in grade["fields"].values()) and not grade["additional_contradiction"]


def disagreement_data(packages, mappings, grades):
    by_job = {}
    for label in ("A", "B"):
        for card in packages[label]["cards"]:
            job = mappings[label][card["card_id"]]["job_id"]
            by_job.setdefault(job, {})[label] = {"card": card, "grade": grades[label][card["card_id"]]}
    differences, totals = [], {"fields_same": 0, "fields_total": 0, "contradictions_same": 0,
                              "questions_same": 0, "questions_total": len(by_job)}
    for job in sorted(by_job):
        a, b = by_job[job]["A"]["grade"], by_job[job]["B"]["grade"]
        fields = [field for field in a["fields"] if a["fields"][field]["pass"] != b["fields"][field]["pass"]]
        contradiction = a["additional_contradiction"] != b["additional_contradiction"]
        totals["fields_total"] += len(a["fields"])
        totals["fields_same"] += len(a["fields"]) - len(fields)
        totals["contradictions_same"] += not contradiction
        totals["questions_same"] += question_pass(a) == question_pass(b)
        if fields or contradiction:
            differences.append({"job_id": job, "fields": fields, "contradiction_disputed": contradiction})
    agreement = {
        "fields": fraction(totals["fields_same"], totals["fields_total"]),
        "contradiction_flags": fraction(totals["contradictions_same"], totals["questions_total"]),
        "derived_question_pass": fraction(totals["questions_same"], totals["questions_total"]),
        "cards_needing_adjudication": len(differences),
        "scope": "Agreement between two masked AI assessors; not a clinical validation or independent patient count."}
    return by_job, differences, agreement


def adjudicator_package(review, snapshot, by_job, differences):
    cards, mapping = [], {}
    for difference in differences:
        job = difference["job_id"]
        card_id = opaque("C", job, snapshot["masking_seed"])
        card = dict(by_job[job]["A"]["card"], card_id=card_id)
        cards.append(card)
        mapping[card_id] = difference
    random.Random(str(snapshot["masking_seed"]) + "-C").shuffle(cards)
    payload = {"schema_version": SCHEMA,
               "instructions": "Independently grade these cards using only the supplied RUBRIC.md. No condition or peer judgments are supplied. Return every requested field and contradiction flag; the offline aggregator resolves only the disputed decisions.",
               "cards": cards}
    write_json(review / "cards/adjudicator.json", payload)
    write_json(review / "private/adjudicator-map.json", {"schema_version": SCHEMA, "cards": mapping})
    return cards, mapping


def final_rows(inv, mappings, by_job, differences, adjudication, cmap):
    lookup = {row["job_id"]: row for row in inv["schedule"]["recall"]}
    disputed = {row["job_id"]: row for row in differences}
    c_by_job = {entry["job_id"]: adjudication[card_id] for card_id, entry in cmap.items()}
    output = []
    for job in sorted(by_job):
        a = by_job[job]["A"]["grade"]
        grade = json.loads(json.dumps(a))
        origins = {field: "A/B agreement" for field in grade["fields"]}
        contradiction_origin = "A/B agreement"
        if job in disputed:
            c = c_by_job[job]
            for field in disputed[job]["fields"]:
                grade["fields"][field] = c["fields"][field]
                origins[field] = "masked adjudicator"
            if disputed[job]["contradiction_disputed"]:
                grade["additional_contradiction"] = c["additional_contradiction"]
                grade["contradiction_reason"] = c["contradiction_reason"]
                contradiction_origin = "masked adjudicator"
        row = lookup[job]
        question = inv["questions"][(row["case_id"], row["question_id"])]
        output.append({**row, "primary": question["primary"], "category": question["category"],
                       "fields": grade["fields"], "field_decision_origins": origins,
                       "additional_contradiction": grade["additional_contradiction"],
                       "contradiction_reason": grade["contradiction_reason"],
                       "contradiction_decision_origin": contradiction_origin,
                       "question_pass": question_pass(grade)})
    return output


def endpoint_scores(rows, planned):
    graded_fields = sum(len(row["fields"]) for row in rows)
    all_score = fraction(sum(row["question_pass"] for row in rows), len(rows), len(planned))
    primary_rows = [row for row in rows if row["primary"]]
    secondary_rows = [row for row in rows if not row["primary"]]
    planned_primary = sum(row["question_id"] in PRIMARY for row in planned)
    planned_fields = sum(1 if row["question_id"] in {"q1", "q5", "q6", "q8"} else 4 if row["question_id"] == "q2" else 2 for row in planned)
    return {"primary": fraction(sum(row["question_pass"] for row in primary_rows), len(primary_rows), planned_primary),
            "secondary": fraction(sum(row["question_pass"] for row in secondary_rows), len(secondary_rows), len(planned) - planned_primary),
            "all_questions": all_score,
            "fields": fraction(sum(value["pass"] for row in rows for value in row["fields"].values()), graded_fields, planned_fields)}


def scoring_summary(inv, rows):
    planned = inv["schedule"]["recall"]
    by_arm, by_case, categories = {}, {}, {}
    for arm in ARMS:
        by_arm[arm] = endpoint_scores([row for row in rows if row["arm"] == arm], [row for row in planned if row["arm"] == arm])
        categories[arm] = {}
        for qid in ["q" + str(i) for i in range(1, 9)]:
            observed = [row for row in rows if row["arm"] == arm and row["question_id"] == qid]
            categories[arm][qid] = fraction(sum(row["question_pass"] for row in observed), len(observed), 5)
    for cid in inv["schedule"]["case_order"]:
        by_case[cid] = {}
        for arm in ARMS:
            by_case[cid][arm] = endpoint_scores([row for row in rows if row["case_id"] == cid and row["arm"] == arm],
                                               [row for row in planned if row["case_id"] == cid and row["arm"] == arm])
    contrasts = {}
    for other in ARMS[1:]:
        cells = []
        for cid, case in by_case.items():
            a, b = case["native"]["primary"], case[other]["primary"]
            complete = a["complete"] and b["complete"]
            cells.append({"case_id": cid, "native_pass": a["pass"], "other_pass": b["pass"],
                          "native_graded": a["graded"], "other_graded": b["graded"],
                          "complete": complete,
                          "difference_pp": a["percentage"] - b["percentage"] if complete else None})
        available = [cell["difference_pp"] for cell in cells if cell["complete"]]
        contrasts["native_minus_" + other] = {
            "prespecified_primary": other == "currency-ablated", "case_differences": cells,
            "complete_histories": len(available), "planned_histories": 5,
            "complete_fixed_case_mean_difference_pp": statistics.mean(available) if len(available) == 5 else None,
            "partial_available_case_mean_difference_pp": statistics.mean(available) if 0 < len(available) < 5 else None,
            "native_higher_cases": sum(value > 0 for value in available),
            "ties": sum(value == 0 for value in available), "native_lower_cases": sum(value < 0 for value in available),
            "interpretation": "Five fixed histories sharing an event template; partial means, if any, describe only the listed available histories. No population inference, p-value, confidence interval or equivalence claim."}
    return {"by_arm": by_arm, "by_case": by_case, "by_question": categories, "primary_contrasts": contrasts}


def missing_cells(root, inv, graded_jobs):
    result = []
    for row in inv["schedule"]["recall"]:
        if row["job_id"] in graded_jobs:
            continue
        receipts = sorted((root / "requests" / row["job_id"]).glob("attempt-*-receipt.json"))
        last = read_json(receipts[-1]) if receipts else None
        result.append({**row, "operational_reason": "not requested" if last is None else last.get("error") or last["status"],
                       "attempts_archived": len(receipts),
                       "last_http_status": last.get("http_status") if last else None})
    return result


def sum_usage(items):
    return {"calls": len(items),
            "prompt_tokens": sum(item["usage"]["prompt_tokens"] for item in items),
            "completion_tokens": sum(item["usage"]["completion_tokens"] for item in items),
            "total_tokens": sum(item["usage"]["total_tokens"] for item in items),
            "reasoning_tokens_recorded": sum(item["usage"].get("completion_tokens_details", {}).get("reasoning_tokens", 0) or 0 for item in items),
            "cached_prompt_tokens_recorded": sum(item["usage"].get("prompt_tokens_details", {}).get("cached_tokens", 0) or 0 for item in items),
            "recorded_cost_usd": float(sum((Decimal(str(item["usage"]["cost"])) for item in items), Decimal(0)))}


def operations(root, inv):
    receipts, accepted = [], []
    for path in sorted((root / "requests").glob("*/attempt-*-receipt.json")):
        receipt = read_json(path)
        require(path.parent.name in inv["jobs"] and receipt["job_id"] == path.parent.name, "Unexpected receipt job")
        require(receipt["phase"] == inv["jobs"][receipt["job_id"]]["phase"], "Receipt phase mismatch")
        for key in ("recorded_cost_usd", "unknown_cost_upper_usd", "pending_cost_upper_usd"):
            if key in receipt:
                numeric(receipt[key], key)
        receipts.append(receipt)
    for job, data in sorted(inv["jobs"].items()):
        answer = accepted_answer(root, job, data["phase"], inv["config"])
        if answer:
            accepted.append(dict(answer["metadata"], arm=data.get("arm")))
    state = read_json(root / "run-state.json") if (root / "run-state.json").exists() else {}
    recorded = float(sum((Decimal(str(r.get("recorded_cost_usd", 0))) for r in receipts), Decimal(0)))
    unknown = float(sum((Decimal(str(r.get("unknown_cost_upper_usd", r.get("pending_cost_upper_usd", 0)))) for r in receipts if "recorded_cost_usd" not in r), Decimal(0)))
    by_phase = {phase: sum_usage([item for item in accepted if item["phase"] == phase]) for phase in inv["config"]["phases"]}
    by_arm = {arm: sum_usage([item for item in accepted if item["phase"] == "answer" and item["arm"] == arm]) for arm in ARMS}
    return {"run_state": state, "planned_jobs": 270, "accepted_jobs": len(accepted), "attempts_archived": len(receipts),
            "attempt_status_counts": dict(sorted(Counter(r["status"] for r in receipts).items())),
            "failed_attempts": [{k: r.get(k) for k in ("job_id", "phase", "attempt", "http_status", "upstream_error_code", "error", "retry_wait_seconds")} for r in receipts if r["status"] == "FAILED"],
            "recorded_attempt_cost_usd": recorded, "unknown_or_pending_attempt_upper_usd": unknown,
            "conservative_attempt_total_usd": recorded + unknown, "declared_budget_usd": inv["config"]["budget_usd"],
            "state_accounting_matches_receipts": bool(state) and math.isclose(recorded, state.get("recorded_cost_usd", -1), abs_tol=1e-8) and math.isclose(unknown, state.get("unknown_cost_upper_usd", -1), abs_tol=1e-8),
            "successful_call_usage": sum_usage(accepted), "successful_usage_by_phase": by_phase,
            "successful_recall_usage_by_arm": by_arm,
            "cost_scope": "Arm costs above are successful recall calls only. Extraction is one shared build for A/B; summary updates belong to D. All-attempt costs include failed attempts when reported. Do not allocate the shared extraction twice.",
            "observed_model_identifiers": dict(sorted(Counter(item["model"] for item in accepted).items())),
            "observed_provider_identifiers": dict(sorted(Counter(str(item.get("provider")) for item in accepted).items()))}


class ReadOnlyStore:
    def __init__(self, records):
        self.records = records

    def iter_records(self, patient_id, therapist_id):
        return iter(self.records)

    def append(self, record):
        raise ReviewError("Offline analysis cannot write memory")


def native_scope(root):
    tree = ast.parse((root / "source/factual_memory.py").read_text())
    tree.body = [node for node in tree.body if not (isinstance(node, ast.ImportFrom) and node.module == "agent.core.memory_store")]
    scope = {"JsonlMemoryStore": ReadOnlyStore, "__name__": "offline_frozen_native_memory"}
    exec(compile(tree, "frozen_native_memory_read_only", "exec"), scope)
    return scope


def archived_records(root, case_id):
    snapshot = root / "runtime" / case_id / "complete-native-store.jsonl.gz"
    live = root / "runtime/native" / ("scripted-therapist__" + case_id + ".jsonl")
    if snapshot.exists():
        raw = gzip.decompress(snapshot.read_bytes())
        require(not live.exists() or raw == live.read_bytes(), "Native complete snapshot differs from current store")
    else:
        raw = live.read_bytes() if live.exists() else b""
    require(not raw or raw.endswith(b"\n"), "Incomplete JSONL record; analyze a stable collection state")
    return [json.loads(line) for line in raw.decode().splitlines() if line.strip()]


def native_diagnostics(root, inv):
    scope, cases = native_scope(root), {}
    for case_id in inv["schedule"]["case_order"]:
        records = archived_records(root, case_id)
        engine = scope["EvidenceMemory"](ReadOnlyStore(records))
        unique = engine._records(case_id, "scripted-therapist")
        facts = engine.current_facts(case_id, "scripted-therapist", include_history=True)
        current = engine.current_facts(case_id, "scripted-therapist")
        batches = [r for r in unique if r["type"] == "fact_batch"]
        raw = [r for r in unique if r["type"] == "conversation_turn"]
        reject = [item for batch in batches for item in batch.get("rejected_facts", [])]
        states = {}
        for i in range(1, 12):
            sid = f"s{i:02d}"
            states[sid] = engine.consolidation_status(case_id, "scripted-therapist", sid)
            states[sid]["expected_source_turns"] = 5
            states[sid]["expected_source_coverage_complete"] = states[sid]["source_turns"] == states[sid]["processed_sources"] == 5
        summary_budgets = {path.stem: read_json(path) for path in sorted((root / "runtime" / case_id).glob("s*-summary-budget.json"))}
        mapping_path = root / "runtime" / case_id / "source-map.json"
        source_mapping = read_json(mapping_path) if mapping_path.exists() else []
        cases[case_id] = {"archived_records_including_duplicates": len(records), "unique_records": len(unique),
                          "raw_turns": len(raw), "planned_raw_turns": 55, "fact_batches": len(batches), "planned_batches": 11,
                          "accepted_facts_all_versions": len(facts), "derived_current_facts": len(current),
                          "historical_facts": len(facts) - len(current),
                          "accepted_fact_status_counts": dict(sorted(Counter(f["status"] for f in facts).items())),
                          "derived_current_status_counts": dict(sorted(Counter(f["status"] for f in current).items())),
                          "facts_with_previous_value_link": sum("supersedes" in f or "supersedes_ids" in f for f in facts),
                          "rejected_fact_proposals": len(reject), "rejection_reasons": dict(sorted(Counter(item["reason"] for item in reject).items())),
                          "invalid_batches": sum(bool(batch.get("validation_error")) for batch in batches),
                          "session_states": states, "summary_budget_records": summary_budgets,
                          "summary_updates_archived": len(summary_budgets),
                          "summary_truncations": sum(item["was_truncated"] is True for item in summary_budgets.values()),
                          "source_map_entries": len(source_mapping)}
    return {"cases": cases, "totals": {
        key: sum(case[key] for case in cases.values()) for key in (
            "raw_turns", "fact_batches", "accepted_facts_all_versions", "derived_current_facts", "historical_facts",
            "rejected_fact_proposals", "invalid_batches", "summary_updates_archived", "summary_truncations")},
        "interpretation": "Native operational states and validated/rejected counts are not accuracy scores. Current is within entity/attribute/speaker/status groups, not a gold current-arrangement label."}


def normalized_literal(text):
    return " ".join(str(text).casefold().replace("’", "'").split())


def literal_contains(text, value):
    return bool(re.search(r"(?<!\w)" + re.escape(normalized_literal(value)) + r"(?!\w)", normalized_literal(text)))


def retrieval_diagnostics(root, inv, rows):
    records_by_case, facts_by_case, maps, raw_ids = {}, {}, {}, {}
    scope = native_scope(root)
    for cid in inv["schedule"]["case_order"]:
        records_by_case[cid] = archived_records(root, cid)
        raw_ids[cid] = {record["id"] for record in records_by_case[cid] if record.get("type") == "conversation_turn" and record.get("usable") is True}
        facts_by_case[cid] = scope["EvidenceMemory"](ReadOnlyStore(records_by_case[cid])).current_facts(cid, "scripted-therapist", include_history=True)
        mp = root / "runtime" / cid / "source-map.json"
        mapping = read_json(mp) if mp.exists() else []
        maps[cid] = {entry["script_source_id"]: entry["native_source_id"] for entry in mapping}
    entries = []
    for row in rows:
        job, cid, qid = row["job_id"], row["case_id"], row["question_id"]
        audit_path = root / "retrieval" / (job + ".json")
        require(audit_path.exists(), "Accepted recall retrieval audit missing")
        audit = read_json(audit_path)
        require(audit["case_id"] == cid and audit["question_id"] == qid and audit["policy"] == row["arm"], "Retrieval audit identity mismatch")
        prompt = (root / "constructed-prompts" / (job + ".txt")).read_text()
        start, end = "\n<MEMORY>\n", "\n</MEMORY>\n<REQUEST>\n"
        require(prompt.count(start) == prompt.count(end) == 1, "Memory delimiter ambiguity")
        memory = prompt.split(start, 1)[1].split(end, 1)[0]
        require(sha(memory.encode()) == audit["memory_sha256"] and sha(prompt.encode()) == audit["prompt_sha256"], "Retrieval audit prompt/body hash mismatch")
        require(scope["estimated_tokens"](memory) == audit["memory_estimated_tokens"] <= inv["config"]["memory_cap"], "Memory packing audit differs")
        gold = inv["gold"][(cid, qid)]
        fields = {}
        for field, value in gold["expected"].items():
            script_sources = {source["source_id"] for source in gold["field_sources"][field]}
            native_sources = {maps[cid][sid] for sid in script_sources if sid in maps[cid]} & raw_ids[cid]
            eligible = [f for f in facts_by_case[cid] if f["speaker"] == "therapist" and f["source_id"] in native_sources]
            returned = [item for item in audit["selected"] if item.get("source_id") in native_sources and item.get("speaker") in {"therapist", "therapist/patient"}]
            fields[field] = {
                "target_type": "unknown sentinel" if value is None else "literal value",
                "annotated_therapist_source_in_raw_archive": bool(native_sources),
                "annotated_source_returned_as_fact_or_raw_chunk": bool(returned),
                "literal_value_in_accepted_fact_value": None if value is None else any(literal_contains(f["value"], value) for f in eligible),
                "literal_value_visible_in_memory": None if value is None else literal_contains(memory, value)}
        entries.append({**{key: row[key] for key in ("job_id", "case_id", "question_id", "arm")},
                        "memory_estimated_tokens": audit["memory_estimated_tokens"], "memory_local_tokens": audit["memory_local_tokens"],
                        "full_prompt_local_tokens": audit["full_prompt_local_tokens"],
                        "selected_items": len(audit["selected"]), "fields": fields})
    aggregates = {}
    for arm in ARMS:
        entries_arm = [entry for entry in entries if entry["arm"] == arm]
        aggregates[arm] = {"calls": len(entries_arm)}
        for key in ("memory_estimated_tokens", "memory_local_tokens", "full_prompt_local_tokens", "selected_items"):
            values = [entry[key] for entry in entries_arm]
            aggregates[arm][key] = {"mean": statistics.mean(values) if values else None,
                                    "min": min(values) if values else None, "max": max(values) if values else None}
    return {"accepted_recall_cells": entries, "resource_summary_by_arm": aggregates,
            "interpretation": "Literal target presence and gold-source overlap are diagnostics, not semantic entailment or correct current/former/status relations. Unknown targets have no literal-value test. Summary support may exist without returned raw-source overlap; identity also appears in the common CASE profile."}


def markdown_summary(analysis):
    lines = ["## Material Passport", "", "- Origin Skill: ars-codex:academic-research-suite / experiment-agent",
             "- Origin Mode: validate — deterministic offline reanalysis", "- Origin Date: " + analysis["origin_date"], "- Verification Status: ANALYZED",
             "- Version Label: state_update_retrieval_analysis_v1", "", "# Memory pilot: adjudicated results", "",
             f"Collection: **{'complete' if analysis['complete_recall_inventory'] else 'partial'}**; graded recall cells {len(analysis['resolved_rows'])}/160.", "",
             "| Condition | Primary complete-question pass | Secondary pass | All questions | Fields |", "|---|---:|---:|---:|---:|"]
    def cell(score):
        percent = "N/A" if score["percentage"] is None else f"{score['percentage']:.2f}%"
        missing = f"; {score['missing']} missing" if score["missing"] else ""
        return f"{score['pass']}/{score['graded']} ({percent}; planned {score['planned']}{missing})"
    for arm in ARMS:
        scores = analysis["scores"]["by_arm"][arm]
        lines.append("| " + ARM_NAMES[arm] + " | " + " | ".join(cell(scores[key]) for key in ("primary", "secondary", "all_questions", "fields")) + " |")
    lines.extend(["", "## Paired primary contrasts", "", "The prespecified contrast is A minus B; every complete history supplies four positive-recall questions. C and D are competent controls.", "",
                  "| Contrast | Complete histories | Mean A minus comparator (percentage points) | A higher / tied / lower |", "|---|---:|---:|---:|"])
    for key, value in analysis["scores"]["primary_contrasts"].items():
        mean = value["complete_fixed_case_mean_difference_pp"]
        display = f"{mean:+.2f}" if mean is not None else "Not available for the full five-case inventory"
        lines.append(f"| {key} | {value['complete_histories']}/5 | {display} | {value['native_higher_cases']} / {value['ties']} / {value['native_lower_cases']} |")
    agreement = analysis["agreement"]
    lines.extend(["", "## Grading and operations", "",
                  f"Initial field agreement: {agreement['fields']['pass']}/{agreement['fields']['graded']}; derived-question agreement: {agreement['derived_question_pass']['pass']}/{agreement['derived_question_pass']['graded']}. Cards requiring independent adjudication: {agreement['cards_needing_adjudication']}.", "",
                  f"Recorded all-attempt costs: USD {analysis['operations']['recorded_attempt_cost_usd']:.6f}; unknown/pending upper allowance: USD {analysis['operations']['unknown_or_pending_attempt_upper_usd']:.6f}. Accepted jobs: {analysis['operations']['accepted_jobs']}/270; archived attempts: {analysis['operations']['attempts_archived']}.", "",
                  "See `analysis.json` for per-case/category scores, missing cells, exact paired differences, adjudicated decisions, usage, extraction/quarantine states and literal/provenance diagnostics.", "",
                  "## Limits", "", "These are five fixed developer-designed histories with a shared chronology, one memory build and one answer per condition/question. Fields and questions are dependent; no population inference, p-values, confidence intervals or equivalence conclusion are made. A–B removes only currency rendering and a ranking tie-break. This component replay does not establish the necessity of the complete structured application. Native operational status and literal source coverage are not answer accuracy.", ""])
    return "\n".join(lines)


def aggregate(root, review, a_path, b_path, c_path=None):
    root, review = Path(root).resolve(), Path(review).resolve()
    protect_output(root, review)
    inv = inventory(root)
    snapshot, packages, mappings = sealed_review(root, review, inv)
    grades = {"A": load_grades(a_path, packages["A"]["cards"]), "B": load_grades(b_path, packages["B"]["cards"])}
    by_job, differences, agreement = disagreement_data(packages, mappings, grades)
    c_cards, cmap = adjudicator_package(review, snapshot, by_job, differences)
    input_hashes = {"grader_A_sha256": sha(Path(a_path).read_bytes()), "grader_B_sha256": sha(Path(b_path).read_bytes()),
                    "study_freeze_sha256": snapshot["study_freeze_sha256"], "review_snapshot_sha256": sha((review / "private/review-snapshot.json").read_bytes()),
                    "analysis_script_sha256": sha(Path(__file__).read_bytes())}
    if differences and c_path is None:
        write_json(review / "analysis.pending.json", {"schema_version": SCHEMA, "status": "NEEDS_MASKED_ADJUDICATION", "agreement": agreement,
                                                       "disagreements": differences, "input_hashes": input_hashes})
        print(json.dumps({"status": "NEEDS_MASKED_ADJUDICATION", "cards": len(differences), "cards_file": str(review / "cards/adjudicator.json")}))
        return 3
    c_grades = load_grades(c_path, c_cards) if c_path else {}
    if c_path:
        input_hashes["adjudicator_sha256"] = sha(Path(c_path).read_bytes())
    rows = final_rows(inv, mappings, by_job, differences, c_grades, cmap)
    analysis = {"schema_version": SCHEMA, "status": "ADJUDICATED", "verification_status": "ANALYZED",
                "origin_date": inv["freeze"]["frozen_at"],
                "complete_recall_inventory": snapshot["complete_recall_inventory"],
                "input_hashes": input_hashes, "agreement": agreement,
                "missing_planned_cells": missing_cells(root, inv, {row["job_id"] for row in rows}),
                "scores": scoring_summary(inv, rows), "resolved_rows": rows,
                "operations": operations(root, inv), "native_memory_diagnostics": native_diagnostics(root, inv),
                "retrieval_diagnostics": retrieval_diagnostics(root, inv, rows),
                "inferential_scope": "Descriptive only. Five fixed shared-template histories; one build and one answer per cell. No p-values, population CIs, equivalence or universal-necessity claim. Deterministic offline scoring is reproducible; stochastic collection was not rerun."}
    write_json(review / "analysis.json", analysis)
    (review / "ANALYSIS.md").write_text(markdown_summary(analysis), encoding="utf-8")
    print(json.dumps({"status": "ADJUDICATED", "graded_recall": len(rows), "analysis": str(review / "analysis.json")}))
    return 0


def fixture_test(source_root, temporary_root):
    """Synthetic 270-job archives test orchestration, never answer semantics."""
    source_root = Path(source_root).resolve()
    source_inventory = inventory(source_root)
    study = temporary_root / "synthetic-study"
    study.mkdir()
    for relative in source_inventory["freeze"]["files"]:
        destination = study / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((source_root / relative).read_bytes())
    (study / "FREEZE.json").write_bytes((source_root / "FREEZE.json").read_bytes())
    inv = inventory(study)
    scope = native_scope(study)
    fixed_time = "2026-10-05T00:00:00+00:00"
    for cid, case in inv["cases"].items():
        records, mapping = [], []
        for session in case["sessions"]:
            si = session["session_index"]
            sid = f"s{si:02d}"
            session_records = []
            for turn in session["turns"]:
                source_id = "turn-" + scope["_digest"]([cid, "scripted-therapist", sid, turn["turn_index"]])
                record = {"id": source_id, "type": "conversation_turn", "patient_id": cid,
                          "therapist_id": "scripted-therapist", "session_id": sid,
                          "session_order": si - 1, "turn_index": turn["turn_index"],
                          "therapist_text": turn["therapist"], "patient_text": turn["patient"],
                          "usable": True, "created_at": fixed_time}
                records.append(record); session_records.append(record)
                mapping.append({"script_source_id": turn["turn_id"], "native_source_id": source_id,
                                "session_index": si, "turn_index": turn["turn_index"]})
            facts, rejected = [], []
            if cid == inv["schedule"]["case_order"][0] and si == 1:
                first = next(record for record in session_records if inv["gold"][(cid, "q1")]["expected"]["title"] in record["therapist_text"])
                facts = [{"id": "fact-synthetic", "type": "fact", "source_id": first["id"],
                          "speaker": "therapist", "quote": first["therapist_text"], "entity": "notebook",
                          "attribute": "title", "value": inv["gold"][(cid, "q1")]["expected"]["title"],
                          "status": "reported", "session_id": sid, "session_order": si - 1,
                          "turn_index": first["turn_index"], "source_created_at": fixed_time}]
                rejected = [{"reason": "synthetic fixture rejection", "proposal": {"synthetic": True}}]
            records.append({"id": "batch-synthetic-" + cid + "-" + sid, "type": "fact_batch", "patient_id": cid,
                            "therapist_id": "scripted-therapist", "session_id": sid,
                            "source_ids": [record["id"] for record in session_records],
                            "facts": facts, "rejected_facts": rejected, "validation_error": None})
            write_json(study / "runtime" / cid / (sid + "-summary-budget.json"), {
                "full_estimated_tokens": 1, "bounded_estimated_tokens": 1,
                "full_local_tokens": 1, "bounded_local_tokens": 1, "was_truncated": False})
        write_json(study / "runtime" / cid / "source-map.json", mapping)
        raw = ("\n".join(json.dumps(record) for record in records) + "\n").encode()
        store = study / "runtime/native" / ("scripted-therapist__" + cid + ".jsonl")
        store.parent.mkdir(parents=True, exist_ok=True); store.write_bytes(raw)
        (study / "runtime" / cid / "complete-native-store.jsonl.gz").write_bytes(gzip.compress(raw, mtime=0))
    memory = "Synthetic fixture memory."
    answer = "Synthetic fixture answer.\n"
    for job, item in inv["jobs"].items():
        prompt = "Synthetic preprocessing fixture."
        if item["phase"] == "answer":
            prompt = "Synthetic recall fixture.\n<MEMORY>\n" + memory + "\n</MEMORY>\n<REQUEST>\nFixture question."
            write_json(study / "retrieval" / (job + ".json"), {
                "case_id": item["case_id"], "question_id": item["question_id"], "policy": item["arm"],
                "selected": [], "memory_estimated_tokens": scope["estimated_tokens"](memory),
                "memory_local_tokens": 1, "full_prompt_local_tokens": 1,
                "memory_sha256": sha(memory.encode()), "prompt_sha256": sha(prompt.encode())})
        prompt_path = study / "constructed-prompts" / (job + ".txt")
        prompt_path.parent.mkdir(parents=True, exist_ok=True); prompt_path.write_text(prompt)
        usage = {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2, "cost": 0.0}
        response = {"id": "synthetic-" + job, "model": inv["config"]["model"], "provider": "synthetic fixture",
                    "choices": [{"message": {"role": "assistant", "content": answer}, "finish_reason": "stop"}], "usage": usage}
        request_bytes = json.dumps({"model": inv["config"]["model"], "messages": [{"role": "user", "content": prompt}]}).encode()
        response_bytes = json.dumps(response).encode()
        directory = study / "requests" / job; directory.mkdir(parents=True)
        (directory / "answer.txt").write_text(answer)
        (directory / "attempt-01-request.json.gz").write_bytes(gzip.compress(request_bytes, mtime=0))
        (directory / "attempt-01-response.json.gz").write_bytes(gzip.compress(response_bytes, mtime=0))
        write_json(directory / "attempt-01-receipt.json", {"job_id": job, "phase": item["phase"], "attempt": 1,
            "status": "ACCEPTED", "http_status": 200, "recorded_cost_usd": 0.0,
            "prompt_sha256": sha(prompt.encode()), "request_sha256": sha(request_bytes), "response_sha256": sha(response_bytes)})
        write_json(directory / "accepted.json", {"job_id": job, "phase": item["phase"], "attempt": 1,
            "model": inv["config"]["model"], "provider": "synthetic fixture", "generation_id": response["id"],
            "finish_reason": "stop", "usage": usage, "answer_sha256": sha(answer.encode()), "prompt_sha256": sha(prompt.encode())})
    write_json(study / "run-state.json", {"status": "COMPLETED", "planned_jobs": 270, "completed_jobs": 270,
        "attempts": 270, "recorded_cost_usd": 0.0, "unknown_cost_upper_usd": 0.0})
    review = temporary_root / "synthetic-review"
    prepare(study, review)
    packages = {label: read_json(review / "cards" / ("grader-" + label + ".json")) for label in ("A", "B")}
    mappings = {label: read_json(review / "private" / ("grader-" + label + "-map.json"))["cards"] for label in ("A", "B")}
    first_case = inv["schedule"]["case_order"][0]
    disputed_field_job = f"{first_case}-q2-native"
    disputed_contradiction_job = f"{first_case}-q8-native"
    def synthetic_grades(cards, mapping, label):
        result = []
        for card in cards:
            row = {"card_id": card["card_id"], "fields": {field: {"pass": True, "reason": "Synthetic schema fixture only", "answer_excerpt": "Synthetic"} for field in card["requested_fields"]},
                   "additional_contradiction": False, "contradiction_reason": ""}
            job = mapping[card["card_id"]]["job_id"]
            if label in {"B", "C"} and job == disputed_field_job:
                row["fields"]["current_slot"]["pass"] = False
            if label == "B" and job == disputed_contradiction_job:
                row["additional_contradiction"] = True; row["contradiction_reason"] = "Synthetic disputed contradiction"
            result.append(row)
        return result
    a, b, c = [temporary_root / ("synthetic-" + label + "-grades.json") for label in ("A", "B", "C")]
    for label, destination in (("A", a), ("B", b)):
        write_json(destination, synthetic_grades(packages[label]["cards"], mappings[label], label))
    require(aggregate(study, review, a, b) == 3, "Disagreement failed to require adjudication")
    ccards = read_json(review / "cards/adjudicator.json")["cards"]
    cmap = read_json(review / "private/adjudicator-map.json")["cards"]
    require(len(ccards) == 2, "Adjudication included agreed cards or omitted disagreement")
    write_json(c, synthetic_grades(ccards, cmap, "C"))
    require(aggregate(study, review, a, b, c) == 0, "Adjudicated fixture failed")
    analysis_bytes = (review / "analysis.json").read_bytes()
    markdown_bytes = (review / "ANALYSIS.md").read_bytes()
    result = read_json(review / "analysis.json")
    require(result["scores"]["by_arm"]["native"]["primary"]["pass"] == 19, "Adjudicated field did not alter complete-question endpoint")
    require(result["scores"]["by_arm"]["native"]["fields"]["pass"] == 69, "Field denominator or dispute resolution wrong")
    require(result["scores"]["primary_contrasts"]["native_minus_currency-ablated"]["complete_fixed_case_mean_difference_pp"] == -5, "Paired five-history contrast wrong")
    require(result["native_memory_diagnostics"]["totals"]["raw_turns"] == 275 and result["native_memory_diagnostics"]["totals"]["rejected_fact_proposals"] == 1, "Native replay/quarantine diagnostics wrong")
    require(result["operations"]["accepted_jobs"] == 270 and result["operations"]["state_accounting_matches_receipts"], "Call accounting wrong")
    require(aggregate(study, review, a, b, c) == 0, "Offline rerun failed")
    require(analysis_bytes == (review / "analysis.json").read_bytes() and markdown_bytes == (review / "ANALYSIS.md").read_bytes(), "Offline rerun output is not byte-stable")
    print(json.dumps({"synthetic_end_to_end": "PASSED", "calls_generated": 0, "planned_archive_fixture_jobs": 270,
                      "checks": "160 independently masked cards, two disputes only, adjudicated 19/20 and 69/70, paired -5pp, quarantine count, budget accounting, byte-identical reanalysis. These are synthetic code checks, not model outcomes."}))


def self_test(root=None):
    """Meaningful schema, masking and paired-denominator checks; no study output."""
    card = {"card_id": "opaque", "answer": "The current slot is Thursday at 16:40.", "requested_fields": ["current_slot"]}
    good = {"card_id": "opaque", "fields": {"current_slot": {"pass": True, "reason": "Correct explicit slot", "answer_excerpt": "Thursday at 16:40"}},
            "additional_contradiction": False, "contradiction_reason": ""}
    with tempfile.TemporaryDirectory(prefix="state-pilot-review-self-test-") as tmp:
        path = Path(tmp) / "grades.json"
        write_json(path, [good])
        require(question_pass(load_grades(path, [card])["opaque"]), "Positive valid grade failed")
        negative = json.loads(json.dumps(good)); negative["fields"]["current_slot"]["pass"] = False
        write_json(path, [negative])
        require(load_grades(path, [card])["opaque"]["fields"]["current_slot"]["pass"] is False and not question_pass(negative), "Valid Boolean false was coerced")
        for invalid in ("false", 0, 1, None):
            changed = json.loads(json.dumps(good)); changed["fields"]["current_slot"]["pass"] = invalid
            write_json(path, [changed])
            try:
                load_grades(path, [card])
            except ReviewError:
                pass
            else:
                raise ReviewError("Non-Boolean field grade accepted")
        changed = json.loads(json.dumps(good)); changed["additional_contradiction"] = "false"
        write_json(path, [changed])
        try:
            load_grades(path, [card])
        except ReviewError:
            pass
        else:
            raise ReviewError("String contradiction flag accepted")
        write_json(path, [good, good])
        try:
            load_grades(path, [card])
        except ReviewError:
            pass
        else:
            raise ReviewError("Duplicate card accepted")
        changed = json.loads(json.dumps(good)); changed["additional_contradiction"] = True; changed["contradiction_reason"] = "Competing assertion"
        require(not question_pass(changed), "Contradiction did not invalidate complete question")
        require(opaque("A", "same-job", REVIEW_SEED) != opaque("B", "same-job", REVIEW_SEED), "Masked IDs expose cross-grader linkage")
        rows = [dict(job_id="one", case_id="c", question_id="q2", arm="native", primary=True,
                     fields={"a": {"pass": True}, "b": {"pass": False}}, question_pass=False)]
        score = endpoint_scores(rows, [{"question_id": "q2"}, {"question_id": "q3"}])
        require(score["primary"]["pass"] == 0 and score["primary"]["graded"] == 1 and score["primary"]["missing"] == 1, "Partial question/missing denominator conflated")
        require(fraction(0, 0, 20)["percentage"] is None, "No-output score fabricated")
        require(not literal_contains("139 is mentioned", 39) and literal_contains("I am 39.", 39), "Literal boundary diagnostic error")
        path.write_text('{"grades":[],"grades":[]}')
        try:
            read_json(path)
        except ReviewError:
            pass
        else:
            raise ReviewError("Duplicate JSON key accepted")
        if root is not None:
            fixture_test(root, Path(tmp))
    print(json.dumps({"status": "PASSED", "checks": "Strict Booleans, duplicate/missing cards and JSON keys, contradiction gate, independent opaque IDs, partial denominators, no-output null, diagnostic literal boundaries"}))
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    prep = commands.add_parser("prepare")
    prep.add_argument("--root", type=Path, required=True)
    prep.add_argument("--out", type=Path, required=True)
    prep.add_argument("--seed", type=int, default=REVIEW_SEED)
    prep.add_argument("--allow-partial", action="store_true")
    agg = commands.add_parser("aggregate")
    agg.add_argument("--root", type=Path, required=True)
    agg.add_argument("--review-dir", type=Path, required=True)
    agg.add_argument("--a", type=Path, required=True)
    agg.add_argument("--b", type=Path, required=True)
    agg.add_argument("--adjudication", type=Path)
    test = commands.add_parser("self-test")
    test.add_argument("--root", type=Path, help="Optional read-only frozen input inventory for a synthetic end-to-end fixture")
    args = parser.parse_args()
    try:
        if args.command == "prepare":
            return prepare(args.root, args.out, args.seed, args.allow_partial)
        if args.command == "aggregate":
            return aggregate(args.root, args.review_dir, args.a, args.b, args.adjudication)
        return self_test(args.root)
    except (ReviewError, OSError, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        print("OFFLINE REVIEW ERROR: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
