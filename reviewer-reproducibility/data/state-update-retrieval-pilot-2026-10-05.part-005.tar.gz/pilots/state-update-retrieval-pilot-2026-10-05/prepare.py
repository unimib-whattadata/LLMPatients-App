"""Prepare immutable inputs and exact source snapshots before model collection."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import random
import shutil
import ssl
import subprocess
import urllib.request

def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')

def prepare(root):
    if root.exists():raise SystemExit('Preparation refuses to overwrite an existing study')
    root.mkdir(parents=True)
    app=Path('/Users/marco/Sites/LLMPatients-App')
    agent=Path('/Users/marco/Sites/LLMPatients-Agent')
    prior=app/'evaluation/reviewer-comment-1/outputs/structure-ablation-pilot-2026-10-05/continuations/tls-ca-01'
    source=root/'source';source.mkdir()
    copies={'factual_memory.py':agent/'agent/core/factual_memory.py',
            'memory_store.py':agent/'agent/core/memory_store.py',
            'langgraph_builder.py':agent/'agent/core/langgraph_builder.py',
            'cacert.pem':prior/'source/cacert.pem',
            'certifi-LICENSE':prior/'source/certifi-LICENSE',
            'tokenizer.model':Path('/private/var/folders/g9/gc59ymlj35x7gnlv_qxrqn500000gn/T/vertexai_tokenizer_model/df5c78e8def68e67515aeca297169a4f6c7f5920')}
    for name,path in copies.items():shutil.copyfile(path,source/name)
    scripts={'client.py':'state_pilot_client.py','engine.py':'state_pilot_engine.py',
             'run.py':'state_pilot_run.py','prepare.py':'state_pilot_prepare.py',
             'preflight.py':'state_pilot_preflight.py'}
    for name,origin in scripts.items():shutil.copyfile(Path('/private/tmp')/origin,root/name)
    shutil.copyfile(prior/'run.py',root/'transport_reference.py')
    for name in ['PROTOCOL.md','RUBRIC.md']:shutil.copyfile(Path('/private/tmp/state-update-pilot-docs')/name,root/name)
    shutil.copyfile('/private/tmp/state_pilot_scenario_notes_20261005.md',root/'SCENARIO_NOTES.md')
    data=json.loads(Path('/private/tmp/state_pilot_scenarios_20261005.json').read_text())
    write(source/'scenario-inventory.json',{k:v for k,v in data.items() if k!='cases'})
    for case in data['cases']:
        cid=case['case_id']
        assert len(case['sessions'])==11 and all(len(s['turns'])==5 for s in case['sessions'])
        assert len(case['questions'])==8
        write(root/'inputs'/cid/'case.json',{k:case[k] for k in ['case_id','profile','sessions','questions']})
        write(root/'review/private'/f'{cid}-gold.json',{'case_id':cid,'gold':case['gold']})
        write(root/'review/private'/f'{cid}-checkpoints.json',case['checkpoints'])
    ca=ssl.create_default_context(cafile=str(source/'cacert.pem'))
    with urllib.request.urlopen('https://openrouter.ai/api/v1/models',context=ca,timeout=30) as response:
        payload=json.loads(response.read())
    model=next(m for m in payload['data'] if m['id']=='google/gemini-2.5-pro')
    write(source/'openrouter-model-metadata.json',{'observed_at':datetime.now(timezone.utc).isoformat(),
        'url':'https://openrouter.ai/api/v1/models','model':model})
    pricing={k:float(model['pricing'][k]) for k in ['prompt','completion']}
    assert pricing=={'prompt':0.00000125,'completion':0.00001},'Pricing changed; amend protocol before calls'
    snapshot=Path('/Users/marco/.cache/huggingface/hub/models--sentence-transformers--all-MiniLM-L6-v2/snapshots/1110a243fdf4706b3f48f1d95db1a4f5529b4d41')
    write(source/'embedding-source-manifest.json',{'model':'sentence-transformers/all-MiniLM-L6-v2',
          'revision':snapshot.name,'files':{str(p.relative_to(snapshot)):sha(p.read_bytes()) for p in snapshot.rglob('*') if p.is_file()}})
    config={'model':'google/gemini-2.5-pro','endpoint':'https://openrouter.ai/api/v1/chat/completions',
            'top_p':0.95,'reasoning':{'max_tokens':1024},
            'provider':{'require_parameters':True,'allow_fallbacks':False},
            'plugins':[{'id':'context-compression','enabled':False}],
            'api_seed':None,'top_k':None,'memory_cap':1800,'summary_memory_cap':900,
            'phases':{'extraction':{'temperature':0.2,'max_tokens':8192,'prompt_cap':16384},
                      'summary':{'temperature':0.2,'max_tokens':2048,'prompt_cap':16384},
                      'answer':{'temperature':0.7,'max_tokens':2048,'prompt_cap':8192}},
            'planned_jobs':270,'planned_phase_jobs':{'extraction':55,'summary':55,'answer':160},
            'budget_usd':15,'pricing':pricing,'first_attempt_upper_usd':12.8,
            'run_timeout_seconds':21600,'request_timeout_seconds':300,'minimum_interval_seconds':10,
            'max_attempts_per_job':3,'no_accuracy_regeneration':True,'length_retry':False,
            'embedding_snapshot':str(snapshot),'scipy_overlay':'/private/tmp/state-memory-runtime-2026-10-05',
            'agent_site_packages':str(agent/'.venv/lib/python3.12/site-packages'),
            'python':'/Users/marco/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3',
            'schedule_seed':2026100519}
    write(root/'config.json',config)
    rng=random.Random(config['schedule_seed']);order=[c['case_id'] for c in data['cases']];rng.shuffle(order)
    memory_order={cid:{} for cid in order}
    for cid in order:
        for si in range(1,12):
            phases=['extraction','summary'];rng.shuffle(phases);memory_order[cid][str(si)]=phases
    blocks=[(cid,q['question_id']) for cid in order for q in next(c for c in data['cases'] if c['case_id']==cid)['questions']]
    rng.shuffle(blocks);recall=[]
    arms=['native','currency-ablated','raw-rag','summary-rag']
    # Rotate a shuffled Latin block over question/case blocks: each arm occupies
    # every within-question order position equally, with no outcome adaptation.
    rng.shuffle(arms)
    for i,(cid,qid) in enumerate(blocks):
        row=arms[i%4:]+arms[:i%4]
        for arm in row:recall.append({'case_id':cid,'question_id':qid,'arm':arm,'job_id':f'{cid}-{qid}-{arm}'})
    write(root/'schedule.json',{'case_order':order,'memory_order':memory_order,'recall':recall})
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=agent,text=True).strip()
    write(root/'SOURCE_PROVENANCE.json',{'agent_commit':head,
        'copied_sources':{name:{'origin':str(path),'sha256':sha(path.read_bytes())} for name,path in copies.items()},
        'scenario_origin_sha256':sha(Path('/private/tmp/state_pilot_scenarios_20261005.json').read_bytes()),
        'transport_reference_origin':str(prior/'run.py'),
        'transport_reference_sha256':sha((prior/'run.py').read_bytes()),
        'runtime_dependency_repair':'Only scipy1.16.2 installed in isolated temporary overlay; original environments untouched',
        'external_model_weights':'Pinned hash manifest; all used vectors are saved in runtime/embedding-cache.json.gz'})
    print(root)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True)
    prepare(parser.parse_args().root)
