## Material Passport

- Origin Skill: ars-codex:academic-research-suite / experiment-agent
- Origin Mode: validate — deterministic offline reanalysis
- Origin Date: 2026-10-05T17:10:19.859551+00:00
- Verification Status: ANALYZED
- Version Label: state_update_retrieval_analysis_v1

# Memory pilot: adjudicated results

Collection: **partial**; graded recall cells 133/160.

| Condition | Primary complete-question pass | Secondary pass | All questions | Fields |
|---|---:|---:|---:|---:|
| A: native EvidenceMemory | 14/14 (100.00%; planned 20; 6 missing) | 19/19 (100.00%; planned 20; 1 missing) | 33/33 (100.00%; planned 40; 7 missing) | 59/59 (100.00%; planned 70; 11 missing) |
| B: currency ablation | 14/14 (100.00%; planned 20; 6 missing) | 19/19 (100.00%; planned 20; 1 missing) | 33/33 (100.00%; planned 40; 7 missing) | 59/59 (100.00%; planned 70; 11 missing) |
| C: raw-dialogue RAG | 14/14 (100.00%; planned 20; 6 missing) | 19/19 (100.00%; planned 20; 1 missing) | 33/33 (100.00%; planned 40; 7 missing) | 59/59 (100.00%; planned 70; 11 missing) |
| D: rolling summary + raw RAG | 15/15 (100.00%; planned 20; 5 missing) | 19/19 (100.00%; planned 20; 1 missing) | 34/34 (100.00%; planned 40; 6 missing) | 60/60 (100.00%; planned 70; 10 missing) |

## Paired primary contrasts

The prespecified contrast is A minus B; every complete history supplies four positive-recall questions. C and D are competent controls.

| Contrast | Complete histories | Mean A minus comparator (percentage points) | A higher / tied / lower |
|---|---:|---:|---:|
| native_minus_currency-ablated | 2/5 | Not available for the full five-case inventory | 0 / 2 / 0 |
| native_minus_raw-rag | 2/5 | Not available for the full five-case inventory | 0 / 2 / 0 |
| native_minus_summary-rag | 2/5 | Not available for the full five-case inventory | 0 / 2 / 0 |

## Grading and operations

Initial field agreement: 237/237; derived-question agreement: 133/133. Cards requiring independent adjudication: 0.

Recorded all-attempt costs: USD 4.230317; unknown/pending upper allowance: USD 0.030720. Accepted jobs: 243/270; archived attempts: 244.

See `analysis.json` for per-case/category scores, missing cells, exact paired differences, adjudicated decisions, usage, extraction/quarantine states and literal/provenance diagnostics.

## Limits

These are five fixed developer-designed histories with a shared chronology, one memory build and one answer per condition/question. Fields and questions are dependent; no population inference, p-values, confidence intervals or equivalence conclusion are made. A–B removes only currency rendering and a ranking tie-break. This component replay does not establish the necessity of the complete structured application. Native operational status and literal source coverage are not answer accuracy.
