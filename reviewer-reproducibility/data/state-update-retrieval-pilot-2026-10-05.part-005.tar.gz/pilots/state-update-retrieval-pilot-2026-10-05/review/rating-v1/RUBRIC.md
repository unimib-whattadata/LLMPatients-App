## Material Passport

- Origin Skill: ars-codex:academic-research-suite / experiment-agent
- Origin Mode: run — prospective grading specification
- Origin Date: 2026-10-05
- Verification Status: UNVERIFIED
- Version Label: state_update_retrieval_rubric_v1
- Upstream Dependencies: PROTOCOL.md; frozen scenario gold and therapist-source annotations

# Masked answer grading

## Unit and decision rule

Grade the **visible answer to one question**, using its requested fields, gold values, criterion and permitted source evidence. Do not grade hidden reasoning, presentation, verbosity, first-person style or source-citation formatting. Answers may use natural language, lists or JSON. Evaluate asserted meaning, not exact output format.

For every requested field, record a Boolean pass, a brief reason and the relevant visible-answer excerpt. A field passes only if the answer provides its correct value **in its correct role/state** and does not also assert a conflicting value or state. Omissions, guesses and unresolved alternatives fail. The question passes only when all its fields pass and there is no additional contradiction of the requested arrangement. A correct statement does not cancel a contradictory one elsewhere in the same answer.

Do not infer an unspoken value from an adjacent field or award partial question credit. Diagnostic field credit is retained separately. Extraneous commentary does not fail a question unless it introduces a contradiction, unsupported competing answer or invented value relevant to that question. A refusal or “unknown” for a known requested value fails that field.

## Matching

- **Names, titles and venues:** require the complete distinctive name/title or an unambiguous equivalent. Ignore letter case, surrounding quotation marks, punctuation, whitespace and typographic apostrophes. Do not accept a different proper noun, missing distinctive word, abbreviation that creates ambiguity, or a broad description in place of the title. The appointment partner's full name and the identity question's full name are required.
- **Appointment slots:** weekday **and** clock time are required for each slot. Accept equivalent 12-hour/24-hour notation (`16:40` = `4:40 pm`), leading-zero differences and equivalent natural phrasing. A bare `4:40` with no context establishing afternoon is insufficient when the intended time is `16:40`. No rounding tolerance applies. A slot is one scored field, although both components must be correct.
- **Age:** accept digits or a spelled-out integer with the same value. A range, approximation or different integer fails.
- **Methods and statuses:** accept faithful paraphrases. An article such as “a” is optional. Preserve substantive distinctions such as printed card versus text message, and planned versus completed.
- **Certainty:** ordinary conversational wording is acceptable if the meaning is definite. “Perhaps X, or Y” fails; a merely hedged guess does not establish correct recall. “The record confirms X” need not reproduce the gold's exact wording.
- **Order and labels:** explicit labels are unnecessary when sentence structure makes the relation unambiguous. Listing all correct values without identifying which is current, former or proposed fails the affected relation fields.

## Question-specific requirements

| Question | Required fields | Pass meaning |
|---|---|---|
| q1 — stable notebook title | `title` | The unchanged agreed notebook title is correctly identified. |
| q2 — appointment | `current_slot`, `former_slot`, `unconfirmed_proposal`, `partner` | The current **agreed** weekday/time is distinguished from the agreed weekday/time it **replaced**, and from the alternative that was **only proposed and remains unconfirmed**; the confirmed partner is named. All four roles must remain distinct. |
| q3 — venue | `current_venue`, `former_venue` | The agreed current venue and the superseded former venue are both named without reversal. |
| q4 — activities | `completed_title`, `planned_title` | The completed exercise and the still-planned exercise are both named with their correct status. Discussion, intention, agreement or anticipation does not establish completion. |
| q5 — optional follow-up call | `current_status` | Use the latest explicit therapist status after cancellation/reconfirmation. Three cases end confirmed to go ahead; two end cancelled. Earlier cancellation/reconfirmation may be described if clearly historical. “Possibly happening” or presenting both statuses as current fails. |
| q6 — reminder method | `agreed_reminder_method` | Identify the therapist-confirmed method; a patient-proposed alternative does not change the agreement. Mentioning the alternative is acceptable only if clearly unadopted. |
| q7 — identity | `name`, `age` | Provide the complete correct name and exact age. These also occur in the common profile; success is secondary and does not demonstrate a memory contribution by itself. |
| q8 — never-established extension | `office_extension` | Explicitly state unknown/not provided/not established, or return null as an unknown sentinel. Do not invent a number, infer one, claim zero/no extension exists, or present a suggested number as the answer. A recommendation to ask later is acceptable alongside explicit abstention. |

For q2, merely naming a correct old slot as the current appointment fails both roles implicated by the reversal. A current slot described as a proposal is incorrect. For q4, naming both exercises but saying both were done fails the planned field and question. For q8, “not provided, perhaps 214” fails because the answer invents a competing value despite the abstention phrase.

## Source authority and temporal interpretation

The therapist's explicit exercise/appointment arrangements are authoritative in this controlled dataset. A patient's suggestion, imagined future, uncertainty or unsupported assertion does not supersede them. Use the latest therapist-confirmed state for current questions; retain old values when the question explicitly asks what was replaced. Do not apply a blanket “latest utterance wins” rule. A historical value is not an error when accurately marked historical.

Gold source annotations establish the scoring target; they do not indicate what memory a condition actually received. Graders must not excuse an inaccurate answer because its source was absent from the selected prompt, or reward it for apparent access to a native current flag. Retrieval and extraction failures are audited separately from answer accuracy.

## Masked outputs and adjudication

Each card has an opaque `card_id`. Return one object per card with:

```json
{
  "card_id": "opaque_identifier",
  "fields": {
    "requested_field_name": {
      "pass": true,
      "reason": "Brief semantic justification",
      "answer_excerpt": "Relevant visible words"
    }
  },
  "additional_contradiction": false,
  "contradiction_reason": ""
}
```

Use actual JSON Booleans, exactly the requested field keys, and every card exactly once. Do not return condition guesses. `additional_contradiction` captures a relevant competing assertion beyond the field findings; it is not a penalty for style. The aggregator computes `question_pass = all(field.pass) and not additional_contradiction`.

Graders A and B work independently without peer outputs or arm/prompt/cost metadata. Adjudicate every field or contradiction disagreement with a third masked grader; retain the two original records and adjudication. If a grading file is malformed, repair its schema without changing unaffected judgments; document any repeated grading. Publish field/question agreement as agreement between these assessors, not as validation of clinical expertise or proof of objective correctness.

## Missing outputs and denominators

Only accepted visible model answers receive content grades. A model-call failure is a missing planned cell with its operational reason. Blank, incomplete or inaccurate **accepted** answers fail relevant fields. Do not replace missing calls with semantic failures or silently remove them from denominators. A complete run supplies, per condition, 20 primary questions, 20 secondary questions, 40 total questions and 70 fields. Any partial report must show both the planned denominator and the actually graded denominator, with the missing cells listed.

The primary pairing is within each of the five histories on q1–q4. Slot subcomponents, fields and repeated questions are not additional independent experimental units. Grading or retrieval diagnostics cannot be used to select cases, repair memories, rerun weak answers or redefine the primary endpoint after outcomes are known.
