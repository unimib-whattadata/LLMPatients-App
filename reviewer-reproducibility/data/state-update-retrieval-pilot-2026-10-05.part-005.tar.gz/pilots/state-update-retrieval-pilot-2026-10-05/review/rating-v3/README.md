# Offline review package

Accepted recall cells: 145/160. This snapshot is partial; missing calls are not factual failures.

Provide each fresh isolated grader only its own `cards/grader-A.json` or `cards/grader-B.json` and `RUBRIC.md`. Request `gpt-6-astra` with `xhigh`; observed runtime identity must be recorded separately when available. Keep `private/` and all collection artifacts out of grader access. Preserve visible answers, including any incidental condition disclosure.

Save strict JSON as an array of objects using the frozen rubric schema (or an object with only a `grades` array). Do not add question-pass scores or stringify Booleans. Run `aggregate` with both files. Exit 3 means the generated adjudicator package needs a fresh isolated third grader. Supply only `cards/adjudicator.json` and `RUBRIC.md`, without peer judgments. Re-run `aggregate --adjudication FILE` after saving its JSON.

The program makes no model calls. Grading does not establish clinical validation. Source diagnostics are literal/provenance checks, not semantic accuracy. The main contrast uses five fixed histories, with no p-values or equivalence claim.
