# Continuation of masked grading

Reuse 133 previous answers; independently grade only 8 added answers per grader. Expanded snapshot: 141/160 accepted recall cells.

Each fresh isolated grader receives ONLY its own `cards/grader-A-new.json` or `cards/grader-B-new.json`, plus `RUBRIC.md`. Do not supply `private/`, old votes, mappings, collection artifacts or the other grader's output. The subset retains the expanded snapshot order.

Merge accepts exactly all new cards under the frozen grading schema. It copies old judgments without regrading and changes only card_id when translating snapshots. Outputs are separate; rating-v1 and rating-v2 are never overwritten. The usual frozen aggregator must still resolve any A/B disagreements and calculate scientific results. This helper makes no model calls.
