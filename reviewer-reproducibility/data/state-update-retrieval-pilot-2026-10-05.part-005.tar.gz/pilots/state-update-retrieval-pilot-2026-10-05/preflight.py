"""Offline guards for native chronology, narrow ablation, packing and inputs."""
import argparse
from collections import Counter
import gzip
import json
from pathlib import Path
import sys
import tempfile
from engine import bound_summary, load_memory, rag, sha
from transport_reference import write_json

class TinyEncoder:
    def embed(self,texts):
        return [[float('apple' in t),float('berry' in t),1.0] for t in texts]

def check(root,freeze=False):
    config=json.loads((root/'config.json').read_text());schedule=json.loads((root/'schedule.json').read_text())
    native=load_memory(root);ablated=load_memory(root,True)
    temp=Path(tempfile.mkdtemp(prefix='state-memory-check-',dir='/private/tmp'))
    try:
        memory=native['EvidenceMemory'](native['JsonlMemoryStore'](temp))
        for i,(value,proposal) in enumerate([('Tuesday at 10:10',False),('Friday at 16:40',False),('Sunday at 08:20',True)],1):
            statement=('I proposed '+value+'.') if proposal else ('We agreed '+value+'.')
            memory.record_turn(patient_id='p',therapist_id='t',session_id=f's{i:02d}',turn_index=1,
                therapist_text=statement,patient_text='I understand the recorded statement.')
            def generate(prompt):
                record=memory._records('p','t')[-1]
                return json.dumps({'facts':[{'source_id':record['id'],'speaker':'therapist','quote':statement,
                    'entity':'appointment','attribute':'slot','value':value,'status':'proposed' if proposal else 'agreed'}]})
            memory.consolidate_session(patient_id='p',therapist_id='t',session_id=f's{i:02d}',generate=generate)
        facts=memory.current_facts('p','t',include_history=True)
        assert len(facts)==3 and facts[0]['current'] is False and facts[1]['current'] is True and facts[2]['current'] is True
        assert facts[1]['previous_value']=='Tuesday at 10:10'
        assert len(ablated['EvidenceMemory'](memory.store).current_facts('p','t',True))==3
        rendered=native['render_evidence'](facts,9999);neutral=ablated['render_evidence'](facts,9999)
        assert '; superseded]' in rendered and '; current]' in rendered
        assert '; superseded]' not in neutral and '; current]' not in neutral
        assert all(f['value'] in neutral for f in facts)
        assert bound_summary('An earlier sentence. A longer correction must remain intact.',16,native['estimated_tokens'])=='An earlier sentence.'
        rows=memory._records('p','t')
        text,selected=rag(rows,'berry',1800,native,TinyEncoder())
        assert selected and all(c['bm25']==0 and c['rrf']<1/60 for c in selected)
        assert all('Therapist: ' in c['rendered'] and 'Patient: ' in c['rendered'] for c in selected)
        assert native['estimated_tokens'](text)<=1800
        assert selected==sorted(selected,key=lambda c:(c['session_order'],c['turn_index']))
    finally:
        import shutil;shutil.rmtree(temp)
    assert len(schedule['case_order'])==5 and len(set(schedule['case_order']))==5
    assert len(schedule['recall'])==160 and len({j['job_id'] for j in schedule['recall']})==160
    positions=Counter((j['arm'],i%4) for i,j in enumerate(schedule['recall']))
    assert all(n==10 for n in positions.values()) and len(positions)==16
    counts=Counter();fields=0
    for cid in schedule['case_order']:
        case=json.loads((root/'inputs'/cid/'case.json').read_text())
        assert set(case)=={'case_id','profile','sessions','questions'}
        assert len(case['sessions'])==11 and len(case['questions'])==8
        assert sum(q['primary'] for q in case['questions'])==4
        gold=json.loads((root/'review/private'/f'{cid}-gold.json').read_text())['gold']
        for q,g in zip(case['questions'],gold):
            assert q['question_id']==g['question_id'] and set(q['requested_fields'])==set(g['expected'])
            fields+=len(g['expected'])
        ids=[]
        for si,s in enumerate(case['sessions'],1):
            assert s['session_index']==si and len(s['turns'])==5
            for ti,t in enumerate(s['turns'],1):
                assert t['turn_index']==ti and t['turn_id']==f's{si:02d}t{ti:02d}'
                ids.append(t['turn_id']);counts['exchanges']+=1
        assert len(set(ids))==55
        assert len(schedule['memory_order'][cid])==11
        assert all(sorted(p)==['extraction','summary'] for p in schedule['memory_order'][cid].values())
    assert fields==70 and counts['exchanges']==275
    maximum=sum(config['planned_phase_jobs'][phase]*(v['prompt_cap']*config['pricing']['prompt']+
                v['max_tokens']*config['pricing']['completion']) for phase,v in config['phases'].items())
    assert abs(maximum-12.8)<1e-9 and maximum<config['budget_usd']
    # Credential-free immutable package. Never read the private key for a scan.
    import re
    for path in root.rglob('*'):
        if path.is_file() and path.suffix!='.model':
            raw=path.read_bytes();assert not re.search(rb'sk-or-v1-[A-Za-z0-9]{32,}',raw),str(path)
    report={'status':'PASS','checks':['exact native historical/version preservation','narrow rendering ablation',
            'complete-sentence summary packing','no lexical RRF for zero matches','whole attributed chronological RAG',
            'gold isolated from generation input','five11x5histories/eightquestions/70fields','balanced160recall jobs',
            'first-attempt budget12.8USD','credential pattern scan'],
            'first_attempt_upper_usd':maximum}
    write_json(root/'PREFLIGHT.json',report)
    if freeze:
        paths=[p for p in root.rglob('*') if p.is_file() and p.name!='FREEZE.json']
        write_json(root/'FREEZE.json',{'schema_version':1,'frozen_at':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),
            'files':{str(p.relative_to(root)):sha(p.read_bytes()) for p in paths},
            'scope':'Precollection scripts, protocol, schedule, source, inputs and private gold; no mutable runtime/output'})
    print(json.dumps(report))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--freeze',action='store_true')
    args=parser.parse_args();check(args.root,args.freeze)
