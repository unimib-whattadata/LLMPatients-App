#!/usr/bin/env python3
"""Reuse sealed A/B ratings across an expanded masked snapshot; stdlib only.

Never prepares a review snapshot or starts/resumes collection. Supply rating-v2
only after the frozen review.py prepare command has run on an inactive study.
Each new grader receives only cards/grader-X-new.json and RUBRIC.md.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import fcntl
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
LABELS = ("A", "B")
SCHEMA = 1


class ReuseError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ReuseError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def read_json(path):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "Duplicate JSON key: " + key)
            result[key] = value
        return result

    def nonfinite(value):
        raise ReuseError("Nonfinite JSON number: " + value)

    return json.loads(Path(path).read_text(encoding="utf-8"),
                      object_pairs_hook=pairs, parse_constant=nonfinite)


def write_json_exclusive(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8") as file:
        file.write(json.dumps(value, indent=2, ensure_ascii=False,
                              sort_keys=True, allow_nan=False) + "\n")


def checked_relative(root, relative):
    target = (root / relative).resolve()
    require(target.is_relative_to(root), "Path escapes its sealed directory: " + str(relative))
    return target


def frozen_review(root):
    path = root / "review.py"
    freeze = read_json(root / "ANALYSIS_FREEZE.json")
    require(freeze["study_freeze_sha256"] == sha((root / "FREEZE.json").read_bytes()),
            "Analysis freeze refers to a different study freeze")
    require("review.py" in freeze["files"], "review.py is not in the analysis freeze")
    for relative, digest in freeze["files"].items():
        file = checked_relative(root, relative)
        require(file.is_file() and sha(file.read_bytes()) == digest,
                "Frozen analysis artifact changed: " + relative)
    spec = importlib.util.spec_from_file_location("state_pilot_frozen_review_reuse", path)
    require(spec is not None and spec.loader is not None, "Cannot import frozen review.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@contextmanager
def inactive_collection(root):
    """Shared lock prevents an exclusive collector from starting during checks."""
    lock_path = root / ".runner.lock"
    require(lock_path.is_file(), "Collector lock file is missing; cannot establish inactivity")
    with lock_path.open("rb") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise ReuseError("Collector is active; do not prepare or reuse rating-v2 yet") from exc
        try:
            state = read_json(root / "run-state.json")
            require(state.get("status") in {"STOPPED", "COMPLETED"},
                    "Collector state is not STOPPED/COMPLETED")
            yield state
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def snapshot(root, review, module, sources):
    """Validate seal without requiring old accepted inventory to equal current."""
    path = review / "private/review-snapshot.json"
    data = module.read_json(path)
    require(data["study_freeze_sha256"] == sha((root / "FREEZE.json").read_bytes()),
            "Study freeze differs from review snapshot")
    require(data["script_sha256"] == sha((root / "review.py").read_bytes()),
            "Review script differs from snapshot")
    remember(sources, path)
    for relative, digest in data["files"].items():
        file = checked_relative(review, relative)
        require(file.is_file() and sha(file.read_bytes()) == digest,
                "Sealed review file changed: " + str(file))
        remember(sources, file)
    accepted = data["accepted_recall_jobs"]
    require(type(accepted) is list and len(accepted) == len(set(accepted)),
            "Invalid or duplicate accepted inventory in snapshot")
    return data


def remember(sources, path):
    path = Path(path).resolve()
    require(path.is_file(), "Missing provenance source: " + str(path))
    digest = sha(path.read_bytes())
    if str(path) in sources:
        require(sources[str(path)] == digest, "Source changed during reuse checks: " + str(path))
    sources[str(path)] = digest


def index_package(package, mapping):
    require(type(package) is dict and type(package.get("cards")) is list,
            "Card package must contain a cards array")
    require(type(mapping) is dict, "Mapping must be an object")
    cards = package["cards"]
    require(all(type(c) is dict and type(c.get("card_id")) is str for c in cards),
            "Invalid card identifiers")
    ids = [c["card_id"] for c in cards]
    require(len(ids) == len(set(ids)) and set(ids) == set(mapping), "Card/map IDs differ or repeat")
    jobs, by_job = [], {}
    for card in cards:
        row = mapping[card["card_id"]]
        job = row.get("job_id")
        require(type(job) is str and bool(job) and job not in by_job, "Unknown or duplicate job ID")
        jobs.append(job)
        by_job[job] = {"card": card, "mapping": row}
    return by_job, jobs


def plan_reuse(old_package, old_map, new_package, new_map, old_grades):
    """Pure comparison/translation; copies grade rows changing only card_id."""
    old, old_order = index_package(old_package, old_map)
    new, new_order = index_package(new_package, new_map)
    require(set(old) <= set(new), "New snapshot removed a previously graded job")
    require(set(old_grades) == {x["card"]["card_id"] for x in old.values()},
            "Original grades do not cover old cards exactly")
    reused, fresh, translation = [], [], []
    for job in new_order:
        card = new[job]["card"]
        if job not in old:
            fresh.append(copy.deepcopy(card))
            continue
        prior = old[job]
        old_card = prior["card"]
        require(canonical({k: v for k, v in old_card.items() if k != "card_id"}) ==
                canonical({k: v for k, v in card.items() if k != "card_id"}),
                "Reused card changed beyond card_id: " + job)
        require(canonical(prior["mapping"]) == canonical(new[job]["mapping"]),
                "Reused job metadata or source hashes changed: " + job)
        old_grade = old_grades[old_card["card_id"]]
        grade = copy.deepcopy(old_grade)
        grade["card_id"] = card["card_id"]
        require(canonical({k: v for k, v in grade.items() if k != "card_id"}) ==
                canonical({k: v for k, v in old_grade.items() if k != "card_id"}),
                "Reused judgement changed beyond card_id")
        reused.append(grade)
        translation.append({"job_id": job, "old_card_id": old_card["card_id"],
                            "new_card_id": card["card_id"],
                            "accepted_file_sha256": new[job]["mapping"]["accepted_file_sha256"],
                            "answer_sha256": new[job]["mapping"]["answer_sha256"]})
    require(len(reused) == len(old) and len(reused) + len(fresh) == len(new),
            "Reuse/fresh cardinality mismatch")
    return reused, fresh, translation


def validate_files_unchanged(sources):
    for source, digest in sources.items():
        path = Path(source)
        require(path.is_file() and sha(path.read_bytes()) == digest,
                "Provenance source changed: " + source)


def protect_output(root, old_review, new_review, out):
    require(old_review != new_review, "Old/new review snapshots must differ")
    require(not old_review.is_relative_to(new_review) and not new_review.is_relative_to(old_review),
            "Old/new sealed review snapshots overlap")
    require(not out.is_relative_to(old_review) and not old_review.is_relative_to(out),
            "Output overlaps the immutable old review snapshot")
    require(out != new_review and not new_review.is_relative_to(out),
            "Output would replace or contain the new review snapshot")
    for relative in ("cards", "private"):
        require(not out.is_relative_to(new_review / relative),
                "Continuation output overlaps sealed/masked review inputs")
    require(out != root and not root.is_relative_to(out), "Output overlaps study root")
    for relative in ("source", "inputs", "runtime", "requests", "constructed-prompts", "retrieval"):
        require(not out.is_relative_to(root / relative), "Output overlaps collection artifacts")


def build(root, old_review, new_review, out):
    root, old_review, new_review, out = [Path(p).resolve() for p in (root, old_review, new_review, out)]
    protect_output(root, old_review, new_review, out)
    require(not out.exists(), "Refuse to replace an existing continuation helper output")
    with inactive_collection(root) as state:
        module = frozen_review(root)
        sources = {}
        for path in (Path(__file__), root / "review.py", root / "FREEZE.json",
                     root / "ANALYSIS_FREEZE.json", root / "RUBRIC.md"):
            remember(sources, path)
        old_snapshot = snapshot(root, old_review, module, sources)
        new_snapshot = snapshot(root, new_review, module, sources)
        inv = module.inventory(root)
        # The old seal intentionally cannot pass current-inventory equality.
        # The new snapshot must pass the full native seal and archived-answer checks.
        _, new_packages, new_maps = module.sealed_review(root, new_review, inv)
        require(set(old_snapshot["accepted_recall_jobs"]) <= set(new_snapshot["accepted_recall_jobs"]),
                "New accepted inventory is not a superset")
        require((old_review / "RUBRIC.md").read_bytes() == (new_review / "RUBRIC.md").read_bytes() ==
                (root / "RUBRIC.md").read_bytes(), "Frozen rubrics differ")
        plans, job_sets = {}, {}
        for label in LABELS:
            old_package = module.read_json(old_review / "cards" / ("grader-" + label + ".json"))
            old_map = module.read_json(old_review / "private" / ("grader-" + label + "-map.json"))["cards"]
            grade_path = old_review / ("grader-" + label + ".json")
            remember(sources, grade_path)
            grades = module.load_grades(grade_path, old_package["cards"])
            old_index, old_jobs = index_package(old_package, old_map)
            new_index, new_jobs = index_package(new_packages[label], new_maps[label])
            require(set(old_jobs) == set(old_snapshot["accepted_recall_jobs"]), "Old cards/snapshot jobs differ")
            require(set(new_jobs) == set(new_snapshot["accepted_recall_jobs"]), "New cards/snapshot jobs differ")
            for job in old_jobs:
                accepted = root / "requests" / job / "accepted.json"
                answer = root / "requests" / job / "answer.txt"
                remember(sources, accepted)
                remember(sources, answer)
                row = old_index[job]["mapping"]
                require(sha(accepted.read_bytes()) == row["accepted_file_sha256"],
                        "Old accepted metadata bytes changed: " + job)
                require(sha(answer.read_bytes()) == row["answer_sha256"],
                        "Old accepted answer bytes changed: " + job)
            reused, fresh, translation = plan_reuse(old_package, old_map,
                                                     new_packages[label], new_maps[label], grades)
            plans[label] = (reused, fresh, translation)
            job_sets[label] = (set(old_jobs), set(new_jobs))
        require(job_sets["A"] == job_sets["B"], "A/B accepted inventories differ")
        for job in new_snapshot["accepted_recall_jobs"]:
            remember(sources, root / "requests" / job / "accepted.json")
            remember(sources, root / "requests" / job / "answer.txt")
        validate_files_unchanged(sources)
        out.mkdir(parents=True)
        outputs = []
        def output(path, value):
            write_json_exclusive(out / path, value)
            outputs.append(path)
        translations = {}
        for label in LABELS:
            reused, fresh, translations[label] = plans[label]
            payload = {k: copy.deepcopy(v) for k, v in new_packages[label].items() if k != "cards"}
            payload["cards"] = fresh  # Existing v2 order; no reused votes or condition mapping.
            output("cards/grader-" + label + "-new.json", payload)
            output("private/grader-" + label + "-reused.json", {"grades": reused})
        output("private/reuse-map.json", {"schema_version": SCHEMA, "graders": translations})
        rubric_path = out / "RUBRIC.md"
        with rubric_path.open("xb") as file:
            file.write((root / "RUBRIC.md").read_bytes())
        outputs.append("RUBRIC.md")
        readme = out / "README.md"
        old_count = len(old_snapshot["accepted_recall_jobs"])
        new_count = len(new_snapshot["accepted_recall_jobs"])
        with readme.open("x", encoding="utf-8") as file:
            file.write(
                "# Continuation of masked grading\n\n"
                f"Reuse {old_count} previous answers; independently grade only {new_count-old_count} added answers per grader. "
                f"Expanded snapshot: {new_count}/160 accepted recall cells.\n\n"
                "Each fresh isolated grader receives ONLY its own `cards/grader-A-new.json` or "
                "`cards/grader-B-new.json`, plus `RUBRIC.md`. Do not supply `private/`, old votes, mappings, "
                "collection artifacts or the other grader's output. The subset retains the expanded snapshot order.\n\n"
                "Merge accepts exactly all new cards under the frozen grading schema. It copies old judgments "
                "without regrading and changes only card_id when translating snapshots. Outputs are separate; "
                "rating-v1 and rating-v2 are never overwritten. The usual frozen aggregator must still resolve "
                "any A/B disagreements and calculate scientific results. This helper makes no model calls.\n")
        outputs.append("README.md")
        provenance = {"schema_version": SCHEMA, "created_at": datetime.now(timezone.utc).isoformat(),
                      "root": str(root), "old_review": str(old_review), "new_review": str(new_review),
                      "old_count": old_count, "new_count": new_count, "added_count": new_count-old_count,
                      "collector_status_at_build": state["status"], "sources": sources,
                      "files": {p: sha((out / p).read_bytes()) for p in outputs},
                      "source_identity_scope": "Old accepted metadata/answers retain the byte SHA-256 sealed in each old map; new native seal also verifies current archived responses.",
                      "grading_scope": "Reuse original A/B judgement rows changing only card_id; fresh contexts grade only added cards."}
        output("private/BUILD_PROVENANCE.json", provenance)
        write_json_exclusive(out / "private/BUILD_FREEZE.json", {
            "schema_version": SCHEMA,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "root": str(root), "old_review": str(old_review), "new_review": str(new_review),
            "files": {p: sha((out / p).read_bytes()) for p in outputs},
            "sources": sources,
            "note": "Locally sealed provenance; preserve this freeze digest externally when publishing. Not a signature or adversarial tamper-proof attestation."})
        print(json.dumps({"status": "BUILT", "out": str(out), "reused_per_grader": old_count,
                          "fresh_per_grader": new_count-old_count, "expanded_cards": new_count}))


def merge(out, a_new, b_new):
    out = Path(out).resolve()
    provenance_path = out / "private/BUILD_PROVENANCE.json"
    build_freeze_path = out / "private/BUILD_FREEZE.json"
    build_freeze = read_json(build_freeze_path)
    for relative, digest in build_freeze["files"].items():
        file = checked_relative(out, relative)
        require(file.is_file() and sha(file.read_bytes()) == digest, "Build freeze changed: " + relative)
    provenance = read_json(provenance_path)
    require(all(provenance[k] == build_freeze[k] for k in ("root", "old_review", "new_review", "sources")),
            "Build provenance differs from its freeze")
    root, old_review, new_review = [Path(provenance[k]).resolve() for k in ("root", "old_review", "new_review")]
    protect_output(root, old_review, new_review, out)
    destination = out / "merged"
    require(not destination.exists(), "Refuse to overwrite a merged grading package")
    with inactive_collection(root):
        validate_files_unchanged(provenance["sources"])
        for relative, digest in provenance["files"].items():
            file = checked_relative(out, relative)
            require(file.is_file() and sha(file.read_bytes()) == digest, "Built reuse artifact changed: " + relative)
        module = frozen_review(root)
        inv = module.inventory(root)
        _, packages, mappings = module.sealed_review(root, new_review, inv)
        merged, inputs = {}, {}
        for label, new_path in zip(LABELS, (a_new, b_new)):
            new_path = Path(new_path).resolve()
            require(new_path.is_file(), "Missing fresh grading output: " + str(new_path))
            package_path = out / "cards" / ("grader-" + label + "-new.json")
            reused_path = out / "private" / ("grader-" + label + "-reused.json")
            fresh_cards = module.read_json(package_path)["cards"]
            full_cards = packages[label]["cards"]
            old_package = module.read_json(old_review / "cards" / ("grader-" + label + ".json"))
            old_map = module.read_json(old_review / "private" / ("grader-" + label + "-map.json"))["cards"]
            original_grades = module.load_grades(old_review / ("grader-" + label + ".json"),
                                                old_package["cards"])
            expected_reused, expected_fresh, _ = plan_reuse(old_package, old_map,
                                                           packages[label], mappings[label], original_grades)
            require(canonical(fresh_cards) == canonical(expected_fresh),
                    "Fresh subset differs from the original expanded snapshot order/content")
            fresh_ids = {c["card_id"] for c in fresh_cards}
            reused_cards = [c for c in full_cards if c["card_id"] not in fresh_ids]
            old_grades = module.load_grades(reused_path, reused_cards)
            require(canonical(old_grades) == canonical({g["card_id"]: g for g in expected_reused}),
                    "Reused judgments differ from immutable original grader rows")
            new_grades = module.load_grades(new_path, fresh_cards)
            require(not set(old_grades) & set(new_grades), "Reused/fresh graded IDs overlap")
            require(set(old_grades) | set(new_grades) == {c["card_id"] for c in full_cards},
                    "Merged grading has missing/unknown cards")
            combined = {**old_grades, **new_grades}
            merged[label] = {"grades": [combined[c["card_id"]] for c in full_cards]}
            # Final full-schema validation before writing; no updates to source files.
            require(len(merged[label]["grades"]) == provenance["new_count"], "Merged cardinality differs")
            inputs[label] = {"path": str(new_path), "sha256": sha(new_path.read_bytes()),
                             "fresh_cards": len(new_grades), "reused_cards": len(old_grades)}
        require(Path(a_new).resolve() != Path(b_new).resolve(), "A/B fresh grades must use separate files")
        validate_files_unchanged(provenance["sources"])
        for item in inputs.values():
            require(sha(Path(item["path"]).read_bytes()) == item["sha256"], "Fresh grades changed during merge")
        destination.mkdir()
        outputs = {}
        for label in LABELS:
            path = destination / ("grader-" + label + ".json")
            write_json_exclusive(path, merged[label])
            module.load_grades(path, packages[label]["cards"])
            outputs[path.name] = sha(path.read_bytes())
        write_json_exclusive(destination / "MERGE_PROVENANCE.json", {
            "schema_version": SCHEMA, "created_at": datetime.now(timezone.utc).isoformat(),
            "build_provenance_sha256": sha(provenance_path.read_bytes()),
            "build_freeze_sha256": sha(build_freeze_path.read_bytes()),
            "root": str(root), "new_review": str(new_review), "new_grade_sources": inputs,
            "files": outputs, "cards_per_grader": provenance["new_count"],
            "old_source_hashes_rechecked": True, "original_judgements_immutable": True,
            "analysis_next_step": "Use frozen review.py aggregate with expanded review snapshot and these merged A/B grade files; adjudicate disagreements as usual."})
        print(json.dumps({"status": "MERGED", "out": str(destination),
                          "cards_per_grader": provenance["new_count"], "fresh_per_grader": provenance["added_count"]}))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    build_parser = commands.add_parser("build")
    for flag in ("root", "old-review", "new-review", "out"):
        build_parser.add_argument("--" + flag, type=Path, required=True)
    merge_parser = commands.add_parser("merge")
    for flag in ("out", "a-new", "b-new"):
        merge_parser.add_argument("--" + flag, type=Path, required=True)
    args = parser.parse_args(argv)
    if args.command == "build":
        build(args.root, args.old_review, args.new_review, args.out)
    else:
        merge(args.out, args.a_new, args.b_new)


if __name__ == "__main__":
    try:
        main()
    except (ReuseError, ValueError, KeyError, OSError) as exc:
        print("REFUSED: " + str(exc), file=sys.stderr)
        raise SystemExit(2)
