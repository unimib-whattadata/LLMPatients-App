"""Verify final retrieval and prompt construction offline using saved vectors."""
import argparse
import gzip
import json
from pathlib import Path
from engine import answer_prompt, load_memory, rag, sha
from run import verify

class SavedEncoder:
    def __init__(self,root):
        self.cache=json.loads(gzip.decompress((root/'runtime/embedding-cache.json.gz').read_bytes()))
    def embed(self,texts):
        values=[]
        for text in texts:
            entry=self.cache[sha(text.encode())]
            assert entry['text']==text
            values.append(entry['vector'])
        return values

def recompute(root):
    verify(root)
    config=json.loads((root/'config.json').read_text());schedule=json.loads((root/'schedule.json').read_text())
    native=load_memory(root);ablated=load_memory(root,True);encoder=SavedEncoder(root)
    checked=[];missing=[]
    for job in schedule['recall']:
        cid,qid,arm=job['case_id'],job['question_id'],job['arm'];jid=job['job_id']
        file=root/'retrieval'/f'{jid}.json'
        if not file.exists():missing.append(jid);continue
        audit=json.loads(file.read_text());case=json.loads((root/'inputs'/cid/'case.json').read_text())
        question=next(q for q in case['questions'] if q['question_id']==qid)
        store=native['JsonlMemoryStore'](root/'runtime/native')
        if arm in {'native','currency-ablated'}:
            scope=native if arm=='native' else ablated
            memory=scope['EvidenceMemory'](store)
            selected=memory.retrieve(patient_id=cid,therapist_id='scripted-therapist',query=question['text'],
                        limit=8,token_budget=audit['effective_packing_cap'],embed=encoder.embed)
            rendered=scope['render_evidence'](selected,token_budget=audit['effective_packing_cap'])
        else:
            records=native['EvidenceMemory'](store)._records(cid,'scripted-therapist')
            cap=config['memory_cap'] if arm=='raw-rag' else audit['rag_allowance']
            retrieved,selected=rag(records,question['text'],cap,native,encoder)
            rendered=retrieved if arm=='raw-rag' else audit['summary']+'\n'+retrieved
            if arm=='summary-rag':assert audit['summary']==(root/'runtime'/cid/'s11-summary-bounded.txt').read_text()
        assert selected==audit['selected'],'Selected evidence mismatch: '+jid
        assert sha(rendered.encode())==audit['memory_sha256']
        assert native['estimated_tokens'](rendered)==audit['memory_estimated_tokens']<=config['memory_cap']
        prompt=answer_prompt(case['profile'],rendered,question['text'])
        assert sha(prompt.encode())==audit['prompt_sha256']
        assert (root/'constructed-prompts'/f'{jid}.txt').read_text()==prompt
        checked.append(jid)
    return {'status':'PASS' if not missing else 'PARTIAL','checked':len(checked),'planned':160,
            'missing':missing,'method':'Exact saved vectors; native code, RAG and prompt rebuild; no models, keys or API calls'}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True)
    args=parser.parse_args();print(json.dumps(recompute(args.root),indent=2))
