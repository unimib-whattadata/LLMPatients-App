"""Create masked review cards and recalculate descriptive scores offline."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import random

def load(p):
    return json.loads(p.read_text())

def save(p, x):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(x, ensure_ascii=False, indent=2) + '\n')

def validate_categories(graded, gold):
    assert isinstance(graded,list) and len(graded)==6
    assert len({x['category'] for x in graded})==6
    bycat={x['category']:x for x in gold}
    assert set(bycat)=={x['category'] for x in graded}
    for x in graded:
        assert set(x['fields'])==set(bycat[x['category']]['requested_fields'])
        assert all(type(v) is bool for v in x['fields'].values())
        assert type(x['pass']) is bool and x['pass']==all(x['fields'].values())

def cards(root):
    schedule = load(root / 'schedule.json')
    accepted = []
    for job in schedule:
        path = root / 'requests' / job['id'] / 'accepted.json'
        if path.exists():
            receipt = load(path)
            text = (path.parent / 'answer.txt').read_text()
            assert hashlib.sha256(text.encode()).hexdigest() == receipt['answer_sha256']
            accepted.append((job, text))
    for name, seed in [('a', 31062026), ('b', 51062026)]:
        rng = random.Random(seed)
        order = list(accepted)
        rng.shuffle(order)
        output, mapping = [], {}
        for i, (job, text) in enumerate(order, 1):
            ident = f'{name.upper()}{i:03d}'
            gold = load(root / 'review/private' / job['patient'] / 'gold.json')
            output.append({'id': ident,
                           'questions': (root / 'inputs' / job['patient'] / 'question.txt').read_text(),
                           'gold': [{k: p[k] for k in ['category', 'expected', 'requested_fields', 'criterion'] if k in p}
                                    for p in gold['probes']], 'answer': text})
            mapping[ident] = job
        save(root / 'review' / name / 'cards.json', output)
        save(root / 'review/private' / (name + '-mapping.json'), mapping)
    print('Masked cards:', len(accepted), 'accepted responses')

def validate_rating(root, reviewer):
    cards = load(root / 'review' / reviewer / 'cards.json')
    path = root / 'review/ratings' / (reviewer + '.json')
    rating = load(path)
    assert len(rating['cards']) == len(cards)
    by_id = {x['id']: x for x in rating['cards']}
    assert len(by_id) == len(cards) and set(by_id) == {x['id'] for x in cards}
    result = {}
    mapping = load(root / 'review/private' / (reviewer + '-mapping.json'))
    for card in cards:
        graded = by_id[card['id']]['categories']
        validate_categories(graded,card['gold'])
        assert len(graded) == 6
        assert len({x['category'] for x in graded}) == 6
        gold = {g['category']: g for g in card['gold']}
        assert set(gold) == {g['category'] for g in graded}
        for judgement in graded:
            expected = set(gold[judgement['category']]['requested_fields'])
            assert set(judgement['fields']) == expected, (card['id'], judgement['category'])
            assert all(type(v) is bool for v in judgement['fields'].values())
            assert type(judgement['pass']) is bool
            assert judgement['pass'] == all(judgement['fields'].values())
        result[mapping[card['id']]['id']] = graded
    return result

def analyze(root):
    freeze=load(root/'FREEZE.json')
    for rel,expected in freeze['files'].items():
        assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==expected,rel
    parity=load(root/'analysis/input-parity.json')
    assert len(parity)==5 and all(all(x[k] is True for k in [
        'structured_roundtrip_exact','linear_roundtrip_exact','validated_against_raw_prefix']) for x in parity.values())
    a, b = validate_rating(root, 'a'), validate_rating(root, 'b')
    disagreements = []
    adjudicated = {}
    path = root / 'review/ratings/adjudicated.json'
    if path.exists():
        data=load(path)
        assert isinstance(data,list)
        adjudicated = {x['job_id']: x['categories'] for x in data}
        assert len(data)==len(adjudicated) and set(adjudicated)<=set(a)&set(b)
    schedule = load(root / 'schedule.json')
    byjob={j['id']:j for j in schedule}
    for ident,graded in adjudicated.items():
        gold=load(root/'review/private'/byjob[ident]['patient']/'gold.json')['probes']
        validate_categories(graded,gold)
    metrics = {}
    rows = []
    for job in schedule:
        ident = job['id']
        if ident not in a or ident not in b:
            continue
        ac = {x['category']: x for x in a[ident]}
        bc = {x['category']: x for x in b[ident]}
        diff = [k for k in ac if ac[k]['fields'] != bc[k]['fields']]
        if diff:
            disagreements.append({'job_id': ident, 'categories': diff})
            if ident not in adjudicated:
                continue
            judges = {x['category']: x for x in adjudicated[ident]}
            final = {k:judges[k] if k in diff else ac[k] for k in ac}
            for cat in final:
                assert final[cat]['pass'] == all(final[cat]['fields'].values())
            assert set(final) == set(ac)
        else:
            final = ac
        metrics[ident] = final
        for cat, judgement in final.items():
            rows.append({**{k:job[k] for k in ['id','patient','repetition','arm']},
                         'category':cat, 'passed':int(judgement['pass']),
                         'fields_correct':sum(judgement['fields'].values()),
                         'fields_total':len(judgement['fields'])})
    save(root / 'analysis/disagreements.json', disagreements)
    if any(x['job_id'] not in adjudicated for x in disagreements):
        print('PENDING adjudication:', len(disagreements))
        return
    complete_pairs = [(p, r) for p in sorted({j['patient'] for j in schedule}) for r in range(1,4)
                      if all(f'{p}__r{r:02d}__{arm}' in metrics for arm in ['structured','linear'])]
    pair_ids = {f'{p}__r{r:02d}__{arm}' for p,r in complete_pairs for arm in ['structured','linear']}
    included = [x for x in rows if x['id'] in pair_ids]
    profiles = {}
    for p in sorted({j['patient'] for j in schedule}):
        profiles[p] = {}
        for arm in ['structured', 'linear']:
            xs=[x for x in included if x['patient']==p and x['arm']==arm]
            profiles[p][arm]={'passed':sum(x['passed'] for x in xs),'total':len(xs)}
        d=profiles[p]
        if d['structured']['total']:
            d['difference_pp']=100*(d['structured']['passed']/d['structured']['total']-
                                    d['linear']['passed']/d['linear']['total'])
    aggregate = {}
    subsets = {'primary_all_six':None,
               'positive_recall': {'distant_stable_fact','correction_and_proposal','explicit_replacement','completed_versus_planned'},
               'temporal': {'correction_and_proposal','explicit_replacement','completed_versus_planned'},
               'identity_absence_controls': {'persistent_identity','absent_fact_abstention'}}
    for subset, cats in subsets.items():
        aggregate[subset]={}
        for arm in ['structured','linear']:
            xs=[x for x in included if x['arm']==arm and (cats is None or x['category'] in cats)]
            n=len(xs); successes=sum(x['passed'] for x in xs)
            aggregate[subset][arm]={'passed':successes,'total':n,'percent':100*successes/n if n else None,
                                  'fields_correct':sum(x['fields_correct'] for x in xs),
                                  'fields_total':sum(x['fields_total'] for x in xs)}
    differences=[v['difference_pp'] for v in profiles.values() if 'difference_pp' in v]
    control=aggregate['identity_absence_controls']
    diff=sum(differences)/len(differences) if differences else None
    primary=aggregate['primary_all_six']
    gate=(len(complete_pairs)==15 and primary['structured']['passed']-primary['linear']['passed']>=9 and
          sum(v['structured']['passed']>v['linear']['passed'] for v in profiles.values())>=4 and
          control['structured']['passed']>=control['linear']['passed'])
    receipt_count=len(list((root/'requests').glob('*/accepted.json')))
    result={'complete_pairs':len(complete_pairs),'accepted_answers':receipt_count,'rated_answers':len(a),
            'adjudicated_answers':len(disagreements),'frozen_integrity_and_input_parity_verified':True,
            'by_profile':profiles,'aggregate':aggregate,'mean_within_profile_difference_pp':diff,
            'extension_gate_met':gate,'all_six_per_answer':{arm:sum(all(x['pass'] for x in metrics[i].values())
                  for i in pair_ids if i.endswith('__'+arm)) for arm in ['structured','linear']},
            'note':'Descriptive exploratory pilot; repeated answers/shared cases are not independent patients.'}
    save(root / 'analysis/results.json', result)
    with (root / 'analysis/scores.csv').open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0]) if rows else ['id']);w.writeheader();w.writerows(included)
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['cards','analyze']);p.add_argument('--root',type=Path,required=True)
    args=p.parse_args();(cards if args.mode=='cards' else analyze)(args.root)
