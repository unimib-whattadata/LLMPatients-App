# TLS certificate correction before any model outcome

The original first request failed during the verified TLS handshake with `CERTIFICATE_VERIFY_FAILED: unable to get local issuer certificate`. No HTTP response or model output was received. The original request, receipt and STOPPED state remain in the parent directory.

This explicit local transport correction uses the installed public certifi CA bundle; TLS certificate verification stays enabled. Scientific inputs, schedule, model and generation settings remain byte-identical. A separate continuation namespace retains all original evidence; no automatic process restart or service fallback was used. The copied CA bundle and corrected runner are hashed in this continuation freeze. The model run belongs to this directory; parent contains only the failed transport attempt. All paths referenced by schedule resolve to the identical copied inputs.

Authorized scope: implement and execute the requested pilot, correcting the local transport configuration. Stop policy for unresolved provider failure remains unchanged.
