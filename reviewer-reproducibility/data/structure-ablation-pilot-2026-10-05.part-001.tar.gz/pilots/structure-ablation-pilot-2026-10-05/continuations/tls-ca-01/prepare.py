"""Prepare a lossless representation pilot from the frozen reviewer archive.

No provider calls. Gold is copied only after every generation prompt is built.
"""
from __future__ import annotations
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import random
import sys
import tarfile
from datetime import datetime, timezone

PACKAGE = Path('/Users/marco/Sites/LLMPatients-App/evaluation/reviewer-comment-1')
DEST = PACKAGE / 'outputs/structure-ablation-pilot-2026-10-05'
C = 'outputs/memory-length-stress-2026-09-30/'
B = 'outputs/memory-comparison-run-2026-09-29/'
FIELDS = {
    'id': 'The record identifier is ',
    'type': 'The record type is ',
    'source_id': 'The source turn identifier is ',
    'speaker': 'The person who stated it is ',
    'quote': 'The exact source quotation is ',
    'entity': 'The subject of the assertion is ',
    'attribute': 'The property described is ',
    'value': 'The recorded value is ',
    'status': 'The recorded assertion status is ',
    'session_id': 'The session identifier is ',
    'session_order': 'The zero-based session order is ',
    'turn_index': 'The archived turn index is ',
    'source_created_at': 'The source timestamp is ',
    'current': 'Whether this is the most recent source version within its native group is ',
    'previous_value': 'The preceding version had the value ',
    'previous_values': 'The simultaneous values in the preceding version were ',
    'supersedes': 'The preceding record identifier is ',
    'supersedes_ids': 'The simultaneous preceding record identifiers are ',
    'extracted_attribute': 'The originally extracted property label was ',
}
MEMORY_HEADER = '''Complete accepted fact inventory, including historical versions, in chronological order.
These records come from extraction of the first nine archived sessions. The current flag means most recent within a native group defined by entity, attribute, speaker and assertion status; it does not mean agreed, completed or clinically verified. Previous values and record links express that native grouping only. Equivalent topics with different extracted labels may remain in different groups. Do not reinterpret a proposal as an agreement. No rejected extraction proposals, later probes, raw conversation transcript, summaries or filler are included.
'''

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')

def prose(records):
    paragraphs = []
    for fact in records:
        assert set(fact) <= set(FIELDS), set(fact) - set(FIELDS)
        paragraphs.append(' '.join(FIELDS[k] + json.dumps(fact[k], ensure_ascii=False) + '.'
                                   for k in FIELDS if k in fact))
    return '\n\n'.join(paragraphs) + '\n'

def parse_prose(text):
    decoder = json.JSONDecoder()
    records = []
    for paragraph in text.strip().split('\n\n'):
        item, rest = {}, paragraph
        while rest:
            matches = [(k, label) for k, label in FIELDS.items() if rest.startswith(label)]
            assert len(matches) == 1
            k, label = matches[0]
            assert k not in item
            value, end = decoder.raw_decode(rest[len(label):])
            suffix = rest[len(label) + end:]
            assert suffix == '.' or suffix.startswith('. ')
            item[k] = value
            rest = suffix[1:].lstrip(' ')
        records.append(item)
    return records

def load_frozen_memory(source):
    # Remove only the import of the storage class. Native functions, including
    # validation and current_facts, execute unmodified from the hash-checked file.
    tree = ast.parse(source)
    tree.body = [n for n in tree.body if not (
        isinstance(n, ast.ImportFrom) and n.module == 'agent.core.memory_store')]
    scope = {'JsonlMemoryStore': object, '__name__': 'frozen_factual_memory'}
    exec(compile(tree, 'frozen_factual_memory.py', 'exec'), scope)
    return scope

def prepare():
    if (DEST / 'FREEZE.json').exists():
        raise SystemExit('Already frozen: refuse to overwrite.')
    DEST.mkdir(parents=True, exist_ok=True)
    manifest = json.loads((PACKAGE / 'MANIFEST.json').read_text())['files']
    provenance = {}
    def read(original):
        item = manifest[original]
        if item.get('member'):
            with tarfile.open(PACKAGE / item['storage'], 'r:gz') as archive:
                raw = archive.extractfile(item['member']).read()
        else:
            raw = (PACKAGE / item['storage']).read_bytes()
        assert sha(raw) == item['sha256'], original
        provenance[original] = item
        return raw

    memory_source = read(B + 'source/agent/core/factual_memory.py')
    scope = load_frozen_memory(memory_source)
    contract_source = read(B + 'prompt_contract.py')
    contract = {}
    exec(compile(contract_source, 'frozen_prompt_contract.py', 'exec'), contract)
    (DEST / 'source').mkdir(exist_ok=True)
    (DEST / 'source/factual_memory_frozen.py').write_bytes(memory_source)
    (DEST / 'source/prompt_contract_frozen.py').write_bytes(contract_source)
    patients = sorted({p.split('/')[3] for p in manifest
                       if p.startswith(C + 'inputs/') and p.endswith('/original-batches.jsonl')})
    assert len(patients) == 5
    import sentencepiece as spm
    # This is the exact cached gemma3 model mapped to gemini-2.5-pro by
    # google-genai 2.25.0. Its string count is len(SentencePiece.encode(text)).
    tokenizer_path = Path('/private/var/folders/g9/gc59ymlj35x7gnlv_qxrqn500000gn/T/vertexai_tokenizer_model/df5c78e8def68e67515aeca297169a4f6c7f5920')
    tokenizer_bytes = tokenizer_path.read_bytes()
    tokenizer_sha = '1299c11d7cf632ef3b4e11937501358ada021bbdf7c47638d13c0ee982f2e79c'
    assert sha(tokenizer_bytes) == tokenizer_sha
    tokenizer = spm.SentencePieceProcessor(model_proto=tokenizer_bytes)
    counts, parity, jobs = {}, {}, []
    for patient in patients:
        d = DEST / 'inputs' / patient
        d.mkdir(parents=True, exist_ok=True)
        for filename in ['case.txt', 'question.txt', 'original-prefix.jsonl', 'original-batches.jsonl']:
            (d / filename).write_bytes(read(C + 'inputs/' + patient + '/' + filename))
        prefix = [json.loads(x) for x in (d / 'original-prefix.jsonl').read_text().splitlines()]
        batches = [json.loads(x) for x in (d / 'original-batches.jsonl').read_text().splitlines()]
        assert len(prefix) == 45 and len(batches) == 9
        assert sorted({x['session_order'] for x in prefix}) == list(range(9))
        by_id = {x['id']: x for x in prefix}
        assert len(by_id) == 45 and all(x['usable'] for x in prefix)
        for batch in batches:
            assert set(batch['source_ids']) <= set(by_id)
            for fact in batch['facts']:
                scope['_validate_fact'](fact, by_id)
        mem = scope['EvidenceMemory'](None)
        mem._records = lambda *args: batches
        records = mem.current_facts(patient, batches[0]['therapist_id'], include_history=True)
        assert len(records) == sum(len(x['facts']) for x in batches)
        text = prose(records)
        decoded = parse_prose(text)
        assert decoded == records
        structured = json.dumps(records, ensure_ascii=False, indent=2) + '\n'
        assert json.loads(structured) == records
        write_json(d / 'fact-inventory.json', records)
        (d / 'structured-memory.txt').write_text(MEMORY_HEADER + structured)
        (d / 'linear-memory.txt').write_text(MEMORY_HEADER + text)
        parity[patient] = {
            'facts': len(records), 'fields': sum(len(x) for x in records),
            'canonical_content_sha256': sha(json.dumps(records, sort_keys=True, ensure_ascii=False).encode()),
            'structured_roundtrip_exact': True, 'linear_roundtrip_exact': True,
            'validated_against_raw_prefix': True, 'raw_prefix_turns': 45,
            'fact_batches': 9, 'statuses': sorted({x['status'] for x in records})}
        counts[patient] = {}
        for arm in ['structured', 'linear']:
            prompt = contract['render_prompt'](
                case_block=(d / 'case.txt').read_text().rstrip() + '\n',
                arm_context=(d / (arm + '-memory.txt')).read_text(),
                latest_question=(d / 'question.txt').read_text())
            path = d / (arm + '-prompt.txt')
            path.write_text(prompt)
            n = len(tokenizer.encode(prompt, out_type=int))
            assert n <= 128000, (patient, arm, n)
            counts[patient][arm] = n
        for repetition in range(1, 4):
            for arm in ['structured', 'linear']:
                p = d / (arm + '-prompt.txt')
                jobs.append({'id': f'{patient}__r{repetition:02d}__{arm}',
                             'patient': patient, 'repetition': repetition, 'arm': arm,
                             'prompt': str(p.relative_to(DEST)), 'prompt_sha256': sha(p.read_bytes()),
                             'local_prompt_tokens': counts[patient][arm]})

    # Randomize profile/repetition pairs; keep paired arms adjacent and balance
    # which arm is first (8 vs 7). This RNG seed is not an inference API seed.
    rng = random.Random(20261005)
    pairs = [(p, r) for p in patients for r in range(1, 4)]
    rng.shuffle(pairs)
    first = ['structured'] * 8 + ['linear'] * 7
    rng.shuffle(first)
    schedule = []
    for (patient, repetition), arm in zip(pairs, first):
        for a in [arm, 'linear' if arm == 'structured' else 'structured']:
            schedule.append(next(j for j in jobs if j['patient'] == patient and
                                 j['repetition'] == repetition and j['arm'] == a))
    write_json(DEST / 'schedule.json', schedule)
    write_json(DEST / 'analysis/input-parity.json', parity)
    write_json(DEST / 'analysis/local-token-counts.json', counts)

    # Gold is evaluator-only and is read after all contexts, prompts and order.
    for patient in patients:
        target = DEST / 'review/private' / patient / 'gold.json'
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(read(C + 'inputs/' + patient + '/gold.json'))
    write_json(DEST / 'source-provenance.json', provenance)
    config = {
        'model': 'google/gemini-2.5-pro', 'endpoint': 'https://openrouter.ai/api/v1/chat/completions',
        'temperature': 0.7, 'top_p': 0.95, 'max_tokens': 4096,
        'reasoning': {'max_tokens': 1024}, 'stop': ['\nTherapist:', 'Therapist:'],
        'provider': {'require_parameters': True, 'allow_fallbacks': False},
        'plugins': [{'id': 'context-compression', 'enabled': False}],
        'api_seed': None, 'top_k': None, 'full_prompt_cap_local_tokens': 128000,
        'schedule_seed': 20261005, 'calls': 30, 'budget_usd': 15,
        'request_timeout_seconds': 300, 'run_timeout_seconds': 14400,
        'minimum_interval_seconds': 5, 'max_attempts_per_job': 3,
        'retryable_http_statuses': [429, 502, 503, 504],
        'retry_backoff_seconds': [30, 60], 'minimum_429_backoff_seconds': 60,
        'no_accuracy_regeneration': True, 'length_retry': False,
        'tokenizer': 'SentencePiece with exact gemma3 model mapped by google-genai 2.25.0 to gemini-2.5-pro',
        'tokenizer_model_sha256': tokenizer_sha, 'sentencepiece_version': spm.__version__,
        'minimum_free_disk_bytes': 104857600,
        'read_only_official_docs': ['https://openrouter.ai/docs/api_reference/parameters',
                                    'https://openrouter.ai/docs/guides/features/message-transforms']}
    write_json(DEST / 'config.json', config)
    # Copy this exact preparer into the experiment; freeze only after final audit.
    (DEST / 'prepare.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({'prepared': str(DEST), 'facts': {p: v['facts'] for p, v in parity.items()},
                      'local_tokens': counts}, indent=2), flush=True)

if __name__ == '__main__':
    prepare()
