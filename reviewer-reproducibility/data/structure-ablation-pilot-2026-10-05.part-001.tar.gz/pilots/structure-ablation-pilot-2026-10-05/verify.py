"""Verify all frozen inputs and lossless conversions without network/tokenizer."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def verify(root):
    frozen=json.loads((root/'FREEZE.json').read_text())
    for rel,expected in frozen['files'].items():
        assert sha((root/rel).read_bytes())==expected,rel
    spec=importlib.util.spec_from_file_location('preparer',root/'prepare.py')
    prep=importlib.util.module_from_spec(spec);spec.loader.exec_module(prep)
    memory=prep.load_frozen_memory((root/'source/factual_memory_frozen.py').read_text())
    contract={};exec(compile((root/'source/prompt_contract_frozen.py').read_text(),'prompt_contract','exec'),contract)
    parity=json.loads((root/'analysis/input-parity.json').read_text())
    for patient,expected in parity.items():
        d=root/'inputs'/patient
        facts=json.loads((d/'fact-inventory.json').read_text())
        ptext=(d/'linear-memory.txt').read_text()
        stext=(d/'structured-memory.txt').read_text()
        assert ptext.startswith(prep.MEMORY_HEADER) and stext.startswith(prep.MEMORY_HEADER)
        assert prep.parse_prose(ptext[len(prep.MEMORY_HEADER):])==facts
        assert json.loads(stext[len(prep.MEMORY_HEADER):])==facts
        assert ptext==prep.MEMORY_HEADER+prep.prose(facts)
        assert sha(json.dumps(facts,sort_keys=True,ensure_ascii=False).encode())==expected['canonical_content_sha256']
        prefix=[json.loads(x) for x in (d/'original-prefix.jsonl').read_text().splitlines()]
        batches=[json.loads(x) for x in (d/'original-batches.jsonl').read_text().splitlines()]
        byid={x['id']:x for x in prefix}
        for batch in batches:
            for fact in batch['facts']:memory['_validate_fact'](fact,byid)
        mem=memory['EvidenceMemory'](None);mem._records=lambda *args:batches
        assert mem.current_facts(patient,batches[0]['therapist_id'],include_history=True)==facts
        for arm in ['structured','linear']:
            prompt=contract['render_prompt'](case_block=(d/'case.txt').read_text().rstrip()+'\n',
                arm_context=(d/(arm+'-memory.txt')).read_text(),latest_question=(d/'question.txt').read_text())
            assert prompt==(d/(arm+'-prompt.txt')).read_text()
    schedule=json.loads((root/'schedule.json').read_text())
    assert len(schedule)==30 and len({x['id'] for x in schedule})==30
    for i in range(0,30,2):
        a,b=schedule[i:i+2]
        assert a['patient']==b['patient'] and a['repetition']==b['repetition']
        assert {a['arm'],b['arm']}=={'linear','structured'}
    for job in schedule:assert sha((root/job['prompt']).read_bytes())==job['prompt_sha256']
    print('PASS: frozen hashes, all five inventories, exact prompts, grounding and 15 pairs.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',required=True,type=Path);a=p.parse_args();verify(a.root)
