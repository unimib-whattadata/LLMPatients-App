# Pilota della rappresentazione della memoria — 5 ottobre 2026

## Material Passport

Esperimento esplorativo autorizzato su pazienti simulati. Cinque inventari precedenti alle domande, tre ripetizioni, due rappresentazioni integrali degli stessi fatti. Modello: Gemini 2.5 Pro tramite OpenRouter. Protocollo e prompt congelati prima delle risposte; nessuna preregistrazione pubblica, casi già noti allo sviluppo. Nessuna modifica al manoscritto durante la raccolta.

## Indice

- `PROTOCOL.md`, `RUBRIC.md`, `config.json`, `schedule.json`: disegno, giudizi, impostazioni e ordine.
- `FREEZE.json`: hash della preparazione originaria.
- `inputs/`: profili, domande, fonti, fatti accettati e prompt esatti di entrambi i bracci.
- `analysis/input-parity.json`: verifica senza perdita di campi e contenuti.
- `source-provenance.json`: collegamenti e hash nel manifest del pacchetto precedente.
- `requests/`, `run-state.json`: tentativo originario fermato durante il controllo del certificato HTTPS locale, senza risposta del modello.
- `continuations/tls-ca-01/`: esecuzione con certificato HTTPS corretto, stesso contenuto scientifico; vedere `AMENDMENT.md`, `run-state.json`, `requests/` e il proprio `FREEZE.json`.
- `REPORT.md`: rapporto finale o stato parziale, da compilare dopo la raccolta e la valutazione.

## Verifica e ricalcolo senza modelli

Dalla radice di questo esperimento:

```sh
python3 -B verify.py --root .
python3 -B verify.py --root continuations/tls-ca-01
python3 -B continuations/tls-ca-01/review-v2.py analyze --root continuations/tls-ca-01
```

I primi due comandi richiedono soltanto Python standard e verificano hash, fonti, identità degli inventari nelle due forme e prompt; non ricalcolano i token. L'ultimo usa i giudizi conservati per ricalcolare i risultati; richiede che la valutazione sia terminata. Nessuna chiave o chiamata API è necessaria. I conteggi locali utilizzano il tokenizer e le calibrazioni descritti nel protocollo; i conteggi nativi sono nei metadati delle risposte. I file `*.json.gz` contengono le richieste e le risposte originali, comprimibili senza perdita ed estraibili con gzip.

Un budget massimo comune non implica un identico numero di token. La versione lineare conserva date, fonti, stati e relazioni: il test confronta la rappresentazione, non l'accesso privilegiato alle informazioni. La struttura JSON è un renderer sperimentale. Le ripetizioni e le categorie non sono pazienti indipendenti. Risultati nulli o sfavorevoli rimangono nel rapporto.
