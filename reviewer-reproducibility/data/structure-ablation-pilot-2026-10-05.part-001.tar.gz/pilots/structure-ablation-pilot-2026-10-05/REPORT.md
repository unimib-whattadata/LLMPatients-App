## Material Passport

- Artefatto: risultato del pilota `structure-ablation-pilot-2026-10-05`.
- Stato: raccolta completata, analisi descrittiva completata; integrità e calcoli verificati offline. Nessuna replica indipendente delle chiamate ai modelli.
- Fonti: pacchetto dell’applicazione al commit `15ad0c637aaeee35c72e47d886836bb00add580b`; percorsi e hash in [source-provenance.json](source-provenance.json).
- Materiale: soli pazienti simulati, utilizzo di OpenRouter già autorizzato.
- Protocollo: fissato e congelato prima delle risposte; casi già noti allo sviluppo, senza preregistrazione pubblica. [Protocollo](PROTOCOL.md), [freeze originario](FREEZE.json), [freeze della raccolta](continuations/tls-ca-01/FREEZE.json).

# Esito

**Entrambe le rappresentazioni ottengono 90/90 categorie corrette (100%) e 180/180 campi corretti.** La differenza strutturato meno lineare è **0 punti percentuali** complessivamente e in ciascuno dei cinque profili. Tutte le sei categorie riescono in 15/15 risposte per braccio.

Il pilota **non rileva un vantaggio della rappresentazione JSON** rispetto agli stessi fatti espressi in testo lineare. Il risultato non dimostra equivalenza generale, inutilità della memoria o necessità della struttura. Entrambi i bracci mantengono tutte le informazioni temporali, e il compito presenta un effetto di soffitto. Non è stata raggiunta la soglia esplorativa fissata per l’estensione (almeno 10 punti di vantaggio, almeno quattro profili favorevoli e controlli conservati).

# Che cosa è stato confrontato

Cinque profili × tre ripetizioni × due rappresentazioni = **30 risposte, 15 coppie**. Per ciascun profilo sono stati usati tutti i 202–237 fatti accettati estratti dalle prime nove sessioni archiviate, comprese le versioni precedenti. Non sono stati inclusi conversazione grezza, riassunti, estrazioni respinte o materiale successivo alle domande. Il [controllo di parità](continuations/tls-ca-01/analysis/input-parity.json) verifica senza perdita ogni campo, valore, citazione, fonte, data, stato e relazione.

- **Strutturato:** inventario integrale dei fatti come array JSON con campi e relazioni esplicite; renderer sperimentale.
- **Lineare:** lo stesso inventario in frasi inglesi, senza eliminare informazioni; conversione reversibile. Questo controllo condivide l’estrazione e il versionamento del sistema. È diverso dalla baseline con cronologia grezza del confronto sulle undici sessioni.

Ogni richiesta contiene lo stesso profilo clinico, le stesse istruzioni e sei domande: identità; titolo distante; accordo attuale/precedente/proposta; sede attuale/precedente; attività completata/pianificata; astensione sul cognome assente. Tutti i valori e gli stati devono essere corretti perché una categoria passi. Una risposta parziale è un insuccesso. Si tratta di **una richiesta di richiamo per ripetizione**, non di una riesecuzione del percorso applicativo sulle undici sessioni.

# Risultati

| Misura | Strutturato JSON | Stessi fatti in testo lineare |
|---|---:|---:|
| Sei categorie (primaria) | 90/90 (100%) | 90/90 (100%) |
| Quattro categorie di richiamo positivo | 60/60 (100%) | 60/60 (100%) |
| Tre categorie temporali | 45/45 (100%) | 45/45 (100%) |
| Identità e dato assente | 30/30 (100%) | 30/30 (100%) |
| Campi corretti, tutte le categorie | 180/180 (100%) | 180/180 (100%) |
| Risposte con tutte le sei categorie corrette | 15/15 | 15/15 |

Le categorie secondarie sono state indicate nel protocollo prima della raccolta e sono sottoinsiemi della misura primaria.

| Profilo | Strutturato | Lineare | Differenza (punti percentuali) |
|---|---:|---:|---:|
| Alex Carter | 18/18 | 18/18 | 0 |
| Crystal Smith | 18/18 | 18/18 | 0 |
| Daniel Isherwood | 18/18 | 18/18 | 0 |
| Jason Smith | 18/18 | 18/18 | 0 |
| Juanita Delgado | 18/18 | 18/18 | 0 |

Due contesti Codex separati, con modello richiesto `gpt-6-astra` e sforzo `xhigh`, hanno valutato schede anonime in ordini diversi, senza prompt, bracci, token, mapping o giudizi del collega. Il modello effettivamente servito non è esposto. **Accordo: 360/360 giudizi sui campi e 180/180 sulle categorie; nessuna adjudication necessaria.** L’accordo è descrittivo e non costituisce validazione clinica né elimina errori correlati. Lo stile visibile può comunque offrire indizi sulla rappresentazione ricevuta; il mascheramento non garantisce una cecità perfetta. Le note preservano i casi in cui “listening card” è un descrittore del titolo o l’assenza del dato viene formulata riferendosi alle conversazioni.

[Risultati JSON](continuations/tls-ca-01/analysis/results.json), [punteggi CSV abbinati](continuations/tls-ca-01/analysis/scores.csv), [giudizi A](continuations/tls-ca-01/review/ratings/a.json), [giudizi B](continuations/tls-ca-01/review/ratings/b.json), [rubrica](RUBRIC.md), [schede A](continuations/tls-ca-01/review/a/cards.json), [schede B](continuations/tls-ca-01/review/b/cards.json).

# Impostazioni ed esecuzione

Modello richiesto e registrato in tutte le risposte: **`google/gemini-2.5-pro`, tramite OpenRouter**. Temperatura 0,7; top_p 0,95; max_tokens 4.096; budget di ragionamento richiesto 1.024; seed API e top_k non impostati. Fallback disabilitato, parametri richiesti obbligatori, plugin di compressione disabilitato. Profili e domande sono identici nei due bracci; [configurazione completa](continuations/tls-ca-01/config.json) e [ordine congelato](continuations/tls-ca-01/schedule.json).

Il massimo comune per l’intero prompt è **128.000 token**, senza selezione, riassunto, tagli o padding. Non sono input di identica lunghezza: media nativa **74.962 token per lo strutturato** e **72.597,8 per il lineare**. Tutti i prompt nativi rispettano il limite. I conteggi locali si basano sul modello SentencePiece esatto documentato nel protocollo; quelli nativi sono conservati nelle ricevute. Una prima verifica offline a 64.000 token era insufficiente e il limite è stato aumentato prima delle generazioni per conservare entrambi gli inventari.

La raccolta delle 30 risposte ha richiesto **17.9 minuti**. Costo registrato delle risposte accettate: **USD 2.343486**; le chiamate includono caching del provider. Questo valore non include la valutazione Codex e non è una riconciliazione della fattura. Non è un confronto causale dei costi fra sistemi applicativi.

Il certificato HTTPS locale ha inizialmente impedito l’invio della prima richiesta: il tentativo rimane nel [registro originario](run-state.json). La [correzione TLS](continuations/tls-ca-01/AMENDMENT.md) conserva la verifica dei certificati e non cambia gli input scientifici. Durante la raccolta sono stati recuperati **tre errori di rate limit** con pause da 60 secondi: due errori 429 dentro HTTP 200 e un HTTP 429. Sono conservati tutti i **33 tentativi HTTP** della raccolta, oltre al tentativo TLS originario. Per i due errori in-band il provider riporta costo zero; il tentativo HTTP 429 e quello TLS non dispongono di metadati di costo. Nessuna risposta è stata rigenerata per migliorarne il punteggio. [Audit runtime](continuations/tls-ca-01/analysis/runtime-audit.json).

Una revisione del codice di calcolo prima della valutazione ha corretto controlli di schema e un limite di arrotondamento della soglia di estensione: [nota](continuations/tls-ca-01/ANALYSIS_IMPLEMENTATION.md), [freeze dell’analisi](continuations/tls-ca-01/ANALYSIS_FREEZE.json). Endpoint e criteri di punteggio restano quelli fissati prima della raccolta.

# Interpretazione e prossimo esperimento

I risultati mostrano che, **quando tutti i fatti già estratti e i loro stati sono disponibili entro il limite di contesto**, Gemini risponde correttamente sia con JSON sia con testo lineare. La conservazione delle informazioni è comune ai due bracci. Il test non isola il contributo dell’estrazione, del versionamento, del consolidamento, del recupero o del grafo di stato, e non sostituisce il confronto applicativo sulle undici sessioni.

Per valutare la necessità operativa occorre fissare un requisito misurabile e confrontare, su casi separati dallo sviluppo, l’aggiornamento strutturato completo con un controllo senza quelle regole, affiancando recupero da archivio grezzo e riassunto progressivo competenti. Servono aggiornamenti e correzioni ripetuti, distinzione fra fonti e impegni, domande ordinarie e un limite di input fissato prima delle risposte. Le stesse informazioni iniziali e le stesse risorse devono essere accessibili a ogni metodo; non si deve costruire il controllo eliminando soltanto i fatti necessari alla risposta. Questo sarebbe uno studio successivo, con protocollo e valutazione propri.

## Limiti e verifica metodologica

Cinque profili fissi e un copione condiviso non rappresentano un campione di pazienti; tre ripetizioni e sei categorie non aumentano il numero di profili indipendenti. Tutti i casi erano noti e il comune inventario deriva dal sistema strutturato. Entrambi i formati preservano già stati e relazioni. Il soffitto del100% limita la capacità di distinguere i metodi. I giudizi sono automatici; casi ambigui meritano verifica umana prima di una pubblicazione. Due risposte lineari di Daniel contengono testo di pianificazione visibile prima della risposta: il punteggio fattuale non valuta integrità del ruolo o qualità del dialogo, e questi casi successivamente osservati non sono una prova di necessità della struttura. I testi completi restano archiviati. Nessun p-value, intervallo inferenziale, equivalenza o superiorità viene dedotto da questi conteggi.

La verifica ARS ha coperto gli11 tipi di fallacie metodologiche: risultati aggregati e per profilo concordano; selezione, unità d’inferenza e percorsi decisionali sono dichiarati; nessuna risposta è esclusa né selezionata per accuratezza; tutte le misure previste sono riportate. Non si fanno affermazioni diagnostiche, correlazionali o causali sui pazienti. Il mancato vantaggio non è interpretato come equivalenza o inutilità generale.

# Dati, prompt e ricalcolo offline

- [Inventari, profili e prompt esatti](continuations/tls-ca-01/inputs/).
- [Richieste e risposte complete, gzip senza perdita](continuations/tls-ca-01/requests/); `answer.txt` è il testo visibile accettato e `accepted.json` conserva usage, identificativo, modello e provider.
- [Codice di preparazione](prepare.py), [runner TLS corretto](continuations/tls-ca-01/run.py), [codice di analisi](continuations/tls-ca-01/review-v2.py), [verificatore portabile](verify.py).
- [Indice e comandi offline](README.md). Il ricalcolo dai giudizi e la verifica delle conversioni non richiedono chiavi o chiamate ai modelli.

I file sono salvati localmente nel repository dell’applicazione. Questo pilota non modifica il manoscritto né la risposta al revisore e non è stato committato o pubblicato con push.
