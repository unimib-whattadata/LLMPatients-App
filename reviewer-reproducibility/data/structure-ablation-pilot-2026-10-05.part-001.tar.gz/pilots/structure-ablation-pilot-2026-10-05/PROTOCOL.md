## Material Passport

- Artifact: protocol for `structure-ablation-pilot-2026-10-05`.
- Workflow: ARS experiment-agent, run; exploratory representation pilot.
- Material: simulated-patient archive, App reviewer package at commit `15ad0c637aaeee35c72e47d886836bb00add580b`; exact source paths and hashes in `source-provenance.json`.
- Human instruction: proceed with the pilot, previously authorized Gemini 2.5 Pro through OpenRouter on simulated patients. No real participant data.
- Protocol status: finalized before any generation; locally frozen, not publicly preregistered. Developer-known cases and old results are acknowledged.

# Question and scope

Does explicit JSON organization improve complete recall relative to faithful linear prose of the SAME saved facts, while both fit one maximum prompt budget? This pilot tests representation/format. The prose preserves state and temporal relations; it is not an ablation that removes temporal knowledge. It does not test the entire application, production retrieval, raw-archive RAG or rolling summaries, and cannot establish universal necessity.

# Inputs and arms

Five fixed profiles, one archived repetition per profile, first nine sessions (45 accepted exchanges and nine extraction batches). Use ALL accepted extracted facts, including native historical versions; 202–237 facts per profile. Rejected proposals, extraction-response text, episode/long-term summaries and later probes are excluded identically. The original preprobe turns are saved for provenance and validation but are not in either generation prompt.

The native `current_facts(..., include_history=True)` code supplies currency and previous-value/source links. Keep native entity labels and flaws. `current` means most recent within entity/attribute/speaker/status, not necessarily a confirmed agreement. No target-specific repair, selection, retrieval, summarization or truncation.

- **Structured:** complete fact records as an indented JSON array. This is an experimental renderer, not the production eight-item renderer.
- **Linear:** the same records as chronological English sentences, retaining every field, value, quotation, source identifier, timestamp, currency flag and previous-value/link. JSON literals safely preserve types/escaping inside sentences. The converter is reversible.

Identical clinical block, common memory interpretation, role instructions, six questions, question order and output instructions. All six questions are batched in one request; this is not an eleven-session trajectory. The inventories themselves come from earlier structured runs; both arms share that extraction lineage. No baseline-generated inventory is introduced.

# Budget, model and schedule

Both full prompts must fit **128,000 local tokens**, and native prompt usage is checked after each response. Equal maximum budget does not mean equal token usage. Report actual counts. No padding to force equality. A preparation check initially attempted 64,000, but the first integral structured prompt was 72,179; the cap was increased before calls to retain all information. This is an input feasibility decision, not an outcome-driven change.

`google/gemini-2.5-pro`, OpenRouter, temperature 0.7, top_p 0.95, max_tokens 4,096 (including reasoning where the provider accounts for it), reasoning.max_tokens 1,024, recorded stop strings. No API seed/top_k. Required-parameter routing with fallback disabled; context-compression explicitly disabled. All request and response bodies are archived losslessly, with native usage/cost, served model and provider when supplied.

Five profiles × three repetitions × two arms = 30 independent generation requests, paired by profile/repetition. Randomize the 15 pair blocks; arm-first ordering is balanced 8/7. Schedule RNG seed 20261005 is not an inference seed. Freeze exact prompts, source, config, rubric and schedule hashes before calls. Repetitions are not independent patients; all profiles share the exercise targets and script.

Local tokenizer: existing SentencePiece 0.2.0, exact cached Gemma3 model mapped to `gemini-2.5-pro` by Google GenAI 2.25.0, SHA-256 `1299c11d7cf632ef3b4e11937501358ada021bbdf7c47638d13c0ee982f2e79c`. Direct string counts were calibrated against three archived SDK counts (64,025; 64,118; 64,120), with exact agreement. No new Google/Vertex API is used.

# Scoring and analysis

Evaluator-only gold is copied AFTER all prompts and schedule are constructed. No gold is passed to the renderer or provider. Six categories: identity, distant notebook title, current/former/proposed appointment, current/former venue, completed/planned activity, abstention on absent surname. Twelve required fields per answer. A category passes only if ALL its values and requested relationships/statuses are correct; partial, missing, contradictory or mixed answers fail. Explicit abstention must avoid inventing/substituting a surname. Twelve-hour equivalents of times and harmless punctuation/case differences are acceptable. No accuracy-based regeneration.

Two fresh native Codex reviewers receive opaque randomized answer cards, the questions, gold and a frozen rubric. They do not receive prompts, arm labels, file paths, token counts, peer ratings or mappings. This is masked automated grading, not clinician validation; answer style may reveal cues. Actual served reviewer model is reported only if exposed. Disagreements receive a separately masked adjudication; human review remains advisable for substantive ambiguities.

**Primary:** category pass rate across all six categories, with paired structured-minus-linear differences aggregated within each profile. Report raw successes/denominators and the five profile differences. Overall descriptive totals are 90 categories per arm only if all 30 calls complete. Secondary: 12-field accuracy; four positive recall categories; three temporal categories; identity/absence controls. These are declared before calls.

No inferential p-values from 90 supposedly independent cases, no equivalence/non-inferiority claim, no universal necessity claim. Five fixed developer-known profiles and a shared script provide an exploratory signal. Null/adverse results and all service failures remain in the report. If incomplete, report availability separately and analyze only complete paired answers without treating missing generation as wrong recall.

**Extension gate:** ≥10 percentage points structured advantage in the primary rate, positive differences in at least four of five profiles, complete parity checks and no decrease in identity/absence controls. This is a practical scheduling criterion, not significance or proof. Failure of this gate does not establish equivalence. Any subsequent confirmatory study needs held-out cases, competent RAG/summary controls and a state-management ablation with an operational requirement fixed in advance.

# Execution and stopping

Serial requests; minimum five seconds between starts, 300-second per-request timeout, four-hour overall limit. USD 15 recorded-cost budget, checked with a conservative next-job reserve. Native cost metadata is not an invoice reconciliation. Credential read at runtime from the previously authorized local key file; never copied to this package or logs.

Bounded transient retries: up to three attempts for actual/in-band 429/502/503/504 or timeout; 30 then 60 seconds, at least 60 seconds on 429, respect longer Retry-After up to the declared run window and a maximum of 600 seconds per wait. Preserve attempts. No fallback, output-length retry, semantic repair or automatic restart. Stop after unresolved failure, authentication/credit/routing/protocol error, budget violation or <100 MiB free disk. User previously requested stop when service remains unavailable.

Preparation encountered a partial dependency installation due to low disk space. Only the new temporary runtime created for this pilot was removed; an existing tokenizer was reused. This is documented before calls, not a change to scientific inputs. Existing unrelated files are preserved.

# Offline reproduction

`prepare.py` reconstructs the inputs from the original package MANIFEST and checks native fact grounding plus exact prose/JSON round-trip parity. `FREEZE.json` hashes the frozen files. `run.py` executes once and refuses automatic restart. `review.py` creates masked cards and recalculates results from retained responses and ratings without provider calls. `REPORT.md` reports completion and limits. All experimental artifacts stay in the App repository. No manuscript change or commit/push is part of this pilot.
