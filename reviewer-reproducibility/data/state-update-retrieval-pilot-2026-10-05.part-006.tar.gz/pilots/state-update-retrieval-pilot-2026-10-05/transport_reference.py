"""Serial, frozen-input OpenRouter pilot. No automatic resume or semantic retry."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import email.utils
import fcntl
import gzip
import hashlib
import http.client
import json
import math
from pathlib import Path
import shutil
import socket
import ssl
import sys
import time

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    tmp.replace(path)

def save_gzip(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as file:
        with gzip.GzipFile(fileobj=file, mode='wb', mtime=0) as gz:
            gz.write(raw)
        file.flush()
        import os
        os.fsync(file.fileno())

def safe_text(text, secret):
    return str(text).replace(secret, '[REDACTED]')

def retry_seconds(value, attempt, status):
    wait = [30, 60][attempt - 1]
    if status == 429:
        wait = max(wait, 60)
    if value:
        try:
            wait = max(wait, float(value))
        except ValueError:
            try:
                target = email.utils.parsedate_to_datetime(value)
                wait = max(wait, (target - datetime.now(timezone.utc)).total_seconds())
            except (ValueError, TypeError):
                pass
    return wait

def visible_response(payload, expected_model):
    if payload.get('error'):
        return None, 'top_level_error', payload['error'].get('code') if isinstance(payload['error'], dict) else None
    if payload.get('model') != expected_model:
        return None, 'served_model_mismatch', None
    if not payload.get('id'):
        return None, 'missing_generation_id', None
    choices = payload.get('choices')
    if not isinstance(choices, list) or len(choices) != 1:
        return None, 'invalid_choices', None
    choice = choices[0]
    if choice.get('error') or choice.get('finish_reason') == 'error':
        error = choice.get('error') or {}
        return None, 'choice_error', error.get('code') if isinstance(error, dict) else None
    if choice.get('finish_reason') != 'stop':
        return None, 'incomplete_finish_' + str(choice.get('finish_reason')), None
    text = choice.get('message', {}).get('content')
    if isinstance(text, list):
        text = '\n'.join(x.get('text', '') for x in text
                         if isinstance(x, dict) and x.get('type') == 'text')
    if not isinstance(text, str) or not text.strip():
        return None, 'empty_visible_text', None
    usage = payload.get('usage', {})
    cost = usage.get('cost')
    if not isinstance(cost, (int, float)) or not math.isfinite(cost) or cost < 0:
        return None, 'missing_or_invalid_recorded_cost', None
    if not isinstance(usage.get('prompt_tokens'), int) or usage['prompt_tokens'] <= 0:
        return None, 'missing_prompt_tokens', None
    return text, None, None

def verify(root):
    freeze = json.loads((root / 'FREEZE.json').read_text())
    for path, expected in freeze['files'].items():
        assert sha((root / path).read_bytes()) == expected, 'Frozen file changed: ' + path
    return freeze

def run(root, key_file):
    freeze = verify(root)
    config = json.loads((root / 'config.json').read_text())
    schedule = json.loads((root / 'schedule.json').read_text())
    assert len(schedule) == config['calls'] == 30
    (root / 'requests').mkdir(exist_ok=True)
    lock = (root / '.runner.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    if (root / 'run-state.json').exists() or list((root / 'requests').glob('*')):
        raise SystemExit('Existing run: refuse automatic restart or overwrite.')
    secret = key_file.read_text().strip()
    assert secret and len(secret) > 20
    state = {'status': 'RUNNING', 'started_at': now(), 'completed': 0,
             'scheduled': 30, 'attempts': 0, 'recorded_cost_usd': 0.0,
             'budget_usd': config['budget_usd'], 'freeze_sha256': sha((root / 'FREEZE.json').read_bytes())}
    write_json(root / 'run-state.json', state)
    start, last_request = time.monotonic(), 0.0
    try:
        for job in schedule:
            if time.monotonic() - start > config['run_timeout_seconds']:
                raise RuntimeError('Declared four-hour run timeout reached')
            if shutil.disk_usage(root).free < config['minimum_free_disk_bytes']:
                raise RuntimeError('Free disk space below the declared 100 MiB reserve')
            verify(root)
            raw_prompt = (root / job['prompt']).read_bytes()
            assert sha(raw_prompt) == job['prompt_sha256']
            # Conservative reserve at rates above standard <=200k published
            # pricing, including a 35% tokenizer margin and three attempts.
            reserve = 1.1 * 3 * (job['local_prompt_tokens'] * 1.35 * 4.5e-6 + 4096 * 27e-6)
            if state['recorded_cost_usd'] + reserve > config['budget_usd']:
                raise RuntimeError('Budget cap would be exceeded by conservative next-job reserve')
            body = {k: config[k] for k in ['model', 'temperature', 'top_p', 'max_tokens',
                    'reasoning', 'stop', 'provider', 'plugins']}
            body['messages'] = [{'role': 'user', 'content': raw_prompt.decode()}]
            request_raw = json.dumps(body, ensure_ascii=False).encode()
            assert secret.encode() not in request_raw
            accepted = False
            for attempt in range(1, config['max_attempts_per_job'] + 1):
                remaining = config['minimum_interval_seconds'] - (time.monotonic() - last_request)
                if remaining > 0:
                    time.sleep(remaining)
                directory = root / 'requests' / job['id']
                prefix = f'attempt-{attempt:02d}'
                save_gzip(directory / (prefix + '-request.json.gz'), request_raw)
                receipt = {'job_id': job['id'], 'attempt': attempt, 'started_at': now(),
                           'request_sha256': sha(request_raw), 'status': 'REQUESTED',
                           'http_status': None, 'upstream_error_code': None}
                write_json(directory / (prefix + '-receipt.json'), receipt)
                state['current_job'] = job['id']
                state['attempts'] += 1
                write_json(root / 'run-state.json', state)
                print(f"REQUEST {state['completed'] + 1}/30 {job['id']} attempt={attempt}", flush=True)
                last_request = time.monotonic()
                conn = http.client.HTTPSConnection('openrouter.ai', timeout=config['request_timeout_seconds'],
                                                   context=ssl.create_default_context(cafile=str(root / config['tls_ca_bundle'])))
                payload, raw_response, status, failure_code, retry_after = None, b'', None, None, None
                try:
                    conn.request('POST', '/api/v1/chat/completions', body=request_raw,
                                 headers={'Authorization': 'Bearer ' + secret, 'Content-Type': 'application/json',
                                          'X-Title': 'LLMPatients lossless representation pilot'})
                    response = conn.getresponse()
                    status = response.status
                    retry_after = response.getheader('Retry-After')
                    if retry_after:
                        retry_after = safe_text(retry_after, secret)
                    raw_response = response.read()
                    # Preserve exact provider bytes unless a credential is echoed.
                    response_safe = raw_response.replace(secret.encode(), b'[REDACTED]')
                    save_gzip(directory / (prefix + '-response.json.gz'), response_safe)
                    receipt.update(http_status=status, ended_at=now(),
                                   response_sha256=sha(response_safe), credential_echo_redacted=response_safe != raw_response,
                                   retry_after=retry_after)
                    try:
                        payload = json.loads(response_safe)
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        payload = None
                    cost = payload.get('usage', {}).get('cost') if isinstance(payload, dict) else None
                    if isinstance(cost, (int, float)) and math.isfinite(cost) and cost >= 0:
                        state['recorded_cost_usd'] += cost
                        receipt['recorded_cost_usd'] = cost
                    if state['recorded_cost_usd'] > config['budget_usd']:
                        receipt.update(status='FAILED', error='recorded_cost_budget_exceeded')
                    elif status == 200 and isinstance(payload, dict):
                        text, error, failure_code = visible_response(payload, config['model'])
                        receipt.update(status='ACCEPTED' if text else 'FAILED', error=error,
                                       upstream_error_code=failure_code)
                        if text:
                            native_tokens = payload['usage']['prompt_tokens']
                            if native_tokens > config['full_prompt_cap_local_tokens']:
                                receipt.update(status='FAILED', error='native_prompt_cap_exceeded')
                            else:
                                (directory / 'answer.txt').write_text(text.rstrip() + '\n')
                                write_json(directory / 'accepted.json', {
                                    'job': job, 'attempt': attempt, 'model': payload['model'],
                                    'provider': payload.get('provider'), 'generation_id': payload['id'],
                                    'usage': payload['usage'], 'finish_reason': payload['choices'][0]['finish_reason'],
                                    'request_sha256': sha(request_raw), 'answer_sha256': sha((text.rstrip() + '\n').encode())})
                                accepted = True
                    else:
                        receipt.update(status='FAILED', error='http_error' if status != 200 else 'invalid_json')
                except (socket.timeout, TimeoutError) as exc:
                    receipt.update(status='FAILED', ended_at=now(), error='transport_timeout',
                                   exception=safe_text(exc, secret))
                except Exception as exc:
                    receipt.update(status='FAILED', ended_at=now(), error='transport_failure',
                                   exception=safe_text(type(exc).__name__ + ': ' + str(exc), secret))
                finally:
                    conn.close()
                write_json(directory / (prefix + '-receipt.json'), receipt)
                write_json(root / 'run-state.json', state)
                if accepted:
                    state['completed'] += 1
                    write_json(root / 'run-state.json', state)
                    print(f"ACCEPTED {state['completed']}/30 cost_usd={state['recorded_cost_usd']:.6f}", flush=True)
                    break
                retryable = (status in config['retryable_http_statuses'] or
                             failure_code in config['retryable_http_statuses'] or
                             receipt.get('error') == 'transport_timeout')
                if not retryable or attempt == config['max_attempts_per_job']:
                    raise RuntimeError('Unresolved request failure; ' + json.dumps({
                        k: receipt.get(k) for k in ['job_id', 'attempt', 'http_status', 'upstream_error_code', 'error']}))
                wait = retry_seconds(retry_after, attempt, status if status != 200 else failure_code)
                if wait > 600 or time.monotonic() - start + wait > config['run_timeout_seconds']:
                    raise RuntimeError('Retry wait exceeds the declared run window')
                receipt['retry_wait_seconds'] = wait
                write_json(directory / (prefix + '-receipt.json'), receipt)
                print(f"RETRY wait={wait:.1f}s http={status} upstream={failure_code}", flush=True)
                time.sleep(wait)
            assert accepted
        state.update(status='COMPLETED', ended_at=now())
        write_json(root / 'run-state.json', state)
        print('COMPLETED 30/30', flush=True)
    except BaseException as exc:
        state.update(status='STOPPED', ended_at=now(), stop_reason=safe_text(type(exc).__name__ + ': ' + str(exc), secret))
        write_json(root / 'run-state.json', state)
        print('STOPPED ' + state['stop_reason'], flush=True)
        raise SystemExit(2)
    finally:
        secret = ''
        fcntl.flock(lock, fcntl.LOCK_UN)
        lock.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--key-file', type=Path, required=True)
    args = parser.parse_args()
    run(args.root, args.key_file)
