"""Offline package completeness, request identity, credential scan and hashes."""
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import re
from run import verify

def sha(raw):return hashlib.sha256(raw).hexdigest()

def audit(root,manifest=False):
    verify(root)
    config=json.loads((root/'config.json').read_text())
    state=json.loads((root/'run-state.json').read_text())
    assert state['status'] in {'COMPLETED','STOPPED'},'Audit only a stable completed/stopped run'
    jobs=json.loads((root/'schedule.json').read_text())
    planned={j['job_id']:'answer' for j in jobs['recall']}
    for cid in jobs['case_order']:
        for si in range(1,12):
            for phase in ['extraction','summary']:planned[f'{cid}-s{si:02d}-{phase}']=phase
    checked=[];accepted=0
    for path in sorted((root/'requests').glob('*/attempt-*-receipt.json')):
        receipt=json.loads(path.read_text());job=receipt['job_id'];phase=planned[job]
        body_path=path.with_name(path.name.replace('-receipt.json','-request.json.gz'))
        raw=gzip.decompress(body_path.read_bytes());body=json.loads(raw)
        assert sha(raw)==receipt['request_sha256'] and receipt['phase']==phase
        assert set(body)=={'model','top_p','provider','plugins','reasoning','temperature','max_tokens','messages'}
        for name in ['model','top_p','provider','plugins','reasoning']:assert body[name]==config[name]
        for name in ['temperature','max_tokens']:assert body[name]==config['phases'][phase][name]
        assert len(body['messages'])==1 and body['messages'][0]['role']=='user'
        prompt=body['messages'][0]['content']
        assert sha(prompt.encode())==receipt['prompt_sha256']
        assert (root/'constructed-prompts'/f'{job}.txt').read_text()==prompt
        response_path=path.with_name(path.name.replace('-receipt.json','-response.json.gz'))
        if response_path.exists() and 'response_sha256' in receipt:
            assert sha(gzip.decompress(response_path.read_bytes()))==receipt['response_sha256']
        checked.append(str(path.relative_to(root)))
    for path in (root/'requests').glob('*/accepted.json'):
        info=json.loads(path.read_text());answer=(path.parent/'answer.txt').read_bytes()
        assert info['answer_sha256']==sha(answer);accepted+=1
    assert accepted==state['completed_jobs']
    if state['status']=='COMPLETED':assert accepted==270
    files={};total=0
    patterns=[rb'sk-or-v1-[A-Za-z0-9]{32,}',rb'sk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{40,}',
              rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.name in {'RESULTS_MANIFEST.json','.runner.lock','ARTIFACT_AUDIT.json'}:continue
        raw=path.read_bytes();scan=gzip.decompress(raw) if path.suffix=='.gz' else raw
        assert not any(re.search(pattern,scan) for pattern in patterns),'Credential pattern found: '+str(path.relative_to(root))
        files[str(path.relative_to(root))]={'sha256':sha(raw),'bytes':len(raw)};total+=len(raw)
    result={'status':'PASS','state':state['status'],'accepted_jobs':accepted,'checked_attempts':len(checked),
            'files_scanned':len(files),'total_bytes':total,'credential_scan':'All files including decompressed gzip; private key never read',
            'request_check':'Every archived request matches frozen settings and constructed prompt; every stored response and accepted answer hash verified'}
    if manifest:
        (root/'RESULTS_MANIFEST.json').write_text(json.dumps({'schema_version':1,'files':files,'total_bytes':total},indent=2)+'\n')
        (root/'ARTIFACT_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--root',type=Path,required=True);parser.add_argument('--manifest',action='store_true')
    args=parser.parse_args();print(json.dumps(audit(args.root,args.manifest)))
