#!/usr/bin/env python3
"""Only the timeout and no-progress-latch fixes; mocked subprocess, no provider."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
from unittest import mock

SCRIPT = Path(__file__).resolve().parent / "automatic_supervisor.py"
spec = importlib.util.spec_from_file_location("supervisor_two_fixes",SCRIPT)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def setup(root):
    (root/".runner.lock").touch()
    (root/"retrieval").mkdir()
    (root/"retrieval/item.json").write_text("{}\n")
    state = {"status":"STOPPED","attempts":263,"completed_jobs":258}
    (root/"run-state.json").write_text(json.dumps(state))
    (root/"config.json").write_text(json.dumps({"python":sys.executable,
        "run_timeout_seconds":2,"request_timeout_seconds":3}))
    for name in ("FREEZE.json","ANALYSIS_FREEZE.json"):
        (root/name).write_text("{}\n")
    (root/"run.py").write_text("# never executed\n")
    key = root/"private-placeholder"
    key.touch()  # No credential data; wrapper only stats this path.
    return key,(root/"run-state.json").read_bytes()


def test_local_failure(root):
    key,state = setup(root)
    process = mock.Mock(pid=999999,returncode=1)
    process.wait.return_value = 1
    with mock.patch.object(module,"ROOT",root), mock.patch.object(module,"KEY_FILE",key), \
         mock.patch.object(module,"inspect",return_value=module.action("RESUME_ORIGINAL")), \
         mock.patch.object(module.subprocess,"Popen",return_value=process) as launch:
        result = module.run_original()
        assert result["action"] == "HALT_LOCAL_RUN_FAILURE"
        assert launch.call_count == 1
        assert process.wait.call_args.kwargs["timeout"] == 5
        assert launch.call_args.kwargs["start_new_session"] is True
        assert module.check_with_control(root)["action"] == "HALT_LOCAL_RUN_FAILURE"
        assert module.run_original()["action"] == "HALT_LOCAL_RUN_FAILURE"
        assert launch.call_count == 1  # Old402 does NOT cause a second launch.
        assert (root/"run-state.json").read_bytes() == state
        folder = Path(result["snapshot"])
        assert module.read(folder/"LAUNCH.json")["exit_code"] == 1
        assert module.read(module.control_path(root))["action"] == "HALT_LOCAL_RUN_FAILURE"
        # No reset can bypass these pre-existing invariant guards.
        for guard in ("HALT_AUTH_OR_ROUTING","HALT_BUDGET","HALT_INCONSISTENT_COMPLETION"):
            with mock.patch.object(module,"inspect",return_value=module.action(guard)):
                assert module.check_with_control(root)["action"] == guard


def test_timeout(root):
    key,state = setup(root)
    process = mock.Mock(pid=999999,returncode=-15)
    process.wait.side_effect = subprocess.TimeoutExpired("synthetic",5)
    cleanup = {"signals":["SIGTERM","SIGKILL"],"returncode":-15,"cleanup_bound_seconds":10}
    with mock.patch.object(module,"ROOT",root), mock.patch.object(module,"KEY_FILE",key), \
         mock.patch.object(module,"inspect",return_value=module.action("RESUME_ORIGINAL")), \
         mock.patch.object(module.subprocess,"Popen",return_value=process), \
         mock.patch.object(module,"terminate_group",return_value=cleanup) as terminate:
        result = module.run_original()
        assert result["action"] == "HALT_PROCESS_TIMEOUT"
        terminate.assert_called_once_with(process)
        assert module.check_with_control(root)["action"] == "HALT_PROCESS_TIMEOUT"
        receipt = module.read(Path(result["snapshot"])/"LAUNCH.json")
        assert receipt["exit_code"] == -15 and receipt["timeout_cleanup"] == cleanup
        start = module.read(Path(result["snapshot"])/"LAUNCH_START.json")
        assert start["hard_timeout_seconds"] == 5
        assert (root/"run-state.json").read_bytes() == state


def test_postinspect_and_spawn_errors(root):
    key,state = setup(root)
    with mock.patch.object(module,"ROOT",root),mock.patch.object(module,"KEY_FILE",key), \
         mock.patch.object(module,"inspect",return_value=module.action("RESUME_ORIGINAL")), \
         mock.patch.object(module.subprocess,"Popen",side_effect=PermissionError("synthetic")):
        result = module.run_original()
        assert result["action"] == "HALT_LOCAL_RUN_FAILURE"
        assert module.read(Path(result["snapshot"])/"LAUNCH.json")["local_error"] == "PermissionError"
        assert (root/"run-state.json").read_bytes() == state
    second = root/"postinspect-case"
    second.mkdir()
    (second/"worker-output.log").write_bytes(b"")
    with mock.patch.object(module,"inspect",side_effect=ValueError("synthetic")):
        result = module.worker_result(root,second,(263,258),1,False,None,None)
    assert result["action"] == "HALT_LOCAL_RUN_FAILURE"
    assert module.read(second/"LAUNCH.json")["post_inspect_error"] == "ValueError"
    assert module.read(module.control_path(root))["action"] == "HALT_LOCAL_RUN_FAILURE"


with tempfile.TemporaryDirectory(prefix="state-supervisor-two-fixes-",dir="/private/tmp") as tmp:
    base = Path(tmp)
    for name,test in (("local",test_local_failure),("timeout",test_timeout),("errors",test_postinspect_and_spawn_errors)):
        root = base/name
        root.mkdir()
        test(root)
print(json.dumps({"status":"PASS","scope":"Two concrete fixes, including spawn and post-inspect variants",
                  "subprocess":"mocked only","provider_calls":0,"real_study_writes":0,"real_run_state_changed":False}))
