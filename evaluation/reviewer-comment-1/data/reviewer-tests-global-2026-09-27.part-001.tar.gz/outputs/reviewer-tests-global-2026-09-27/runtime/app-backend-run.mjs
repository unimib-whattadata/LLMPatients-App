import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { readFileSync, writeFileSync, existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const appRoot = "/Users/marco/Sites/LLMPatients-App";
const outputDir = dirname(fileURLToPath(import.meta.url));
const appRequire = createRequire(join(appRoot, "package.json"));
const dotenv = appRequire("dotenv");
const localEnv = dotenv.parse(readFileSync(join(appRoot, ".env")));
const credentialPath =
  "/Users/marco/Sites/LLMPatients-Agent/config/vertex-ai-api-key.json";
const apiBase = "http://127.0.0.1:18001";
if (!existsSync(credentialPath)) throw new Error("Agent credential file is missing");

const health = await fetch(`${apiBase}/openapi.json`, {
  signal: AbortSignal.timeout(10_000),
});
if (!health.ok) throw new Error(`Agent health check returned ${health.status}`);

const runEnv = {
  ...localEnv,
  ...process.env,
  API: "remote",
  API_BASE_URL: apiBase,
  API_INITIALIZE_PATIENT_ENDPOINT: "/patient",
  API_CHAT_RESPONSE_ENDPOINT: "/chat-response",
  API_SESSION_END_ENDPOINT: "/session-end",
  API_TIMEOUT_INITIALIZE_PATIENT: "180000",
  API_TIMEOUT_CHAT_RESPONSE: "600000",
  API_TIMEOUT_SESSION_END: "600000",
  GOOGLE_APPLICATION_CREDENTIALS: credentialPath,
  GOOGLE_CLOUD_LOCATION: "global",
  GOOGLE_GENAI_USE_VERTEXAI: "true",
  VERTEX_MODEL_ID: "gemini-3.1-pro-preview",
  TEST_STEP_EVALUATION_TIMEOUT_MS: "600000",
  AUTH_SECRET: "test-auth-secret-which-is-long-enough-12345",
  NEXTAUTH_SECRET: "test-nextauth-secret-which-is-long-enough-12345",
  TTS_PROVIDER: "none",
  EXTERNAL_AI_API_KEY: "",
  LANGCHAIN_TRACING_V2: "false",
  LOG_LEVEL: "info",
};

const startedAt = new Date().toISOString();
const logPath = join(outputDir, "app-backend-real.log");
const statusPath = join(outputDir, "app-backend-real.json");
const run = {
  startedAt,
  status: "running",
  patientApiMode: "remote",
  patientApiBase: apiBase,
  evaluatorModel: runEnv.VERTEX_MODEL_ID,
  evaluatorRegion: runEnv.GOOGLE_CLOUD_LOCATION,
  stepEvaluationTimeoutMs: Number(runEnv.TEST_STEP_EVALUATION_TIMEOUT_MS),
  credentialsProvidedByFile: true,
  disposableDatabase: true,
  command: "node --import tsx scripts/test-backend.ts",
};
writeFileSync(statusPath, JSON.stringify(run, null, 2));
writeFileSync(logPath, "");
let captured = "";
const sensitiveValues = Object.entries(runEnv)
  .filter(([name, value]) => /SECRET|KEY|TOKEN|PASSWORD/.test(name) && value?.length > 12)
  .map(([, value]) => value);
const sanitize = (chunk) => {
  let text = chunk.toString().replace(/\x1b\[[0-9;]*m/g, "");
  for (const value of sensitiveValues) text = text.replaceAll(value, "[REDACTED]");
  return text;
};
const child = spawn(process.execPath, ["--import", "tsx", "scripts/test-backend.ts"], {
  cwd: appRoot,
  env: runEnv,
  stdio: ["ignore", "pipe", "pipe"],
});
for (const stream of [child.stdout, child.stderr]) {
  stream.on("data", (chunk) => {
    captured += sanitize(chunk);
    writeFileSync(logPath, captured);
  });
}
const { code, signal } = await new Promise((resolve, reject) => {
  child.on("error", reject);
  child.on("close", (code, signal) => resolve({ code, signal }));
});
const realResponseVerified = captured.includes("real patient response verified");
const backendPassed = captured.includes("[backend:postgres] passed");
const skipped = captured.includes("[backend:postgres] skipped");
const finalizationStatuses = [
  ...captured.matchAll(/External patient session finalized[^\n]*status: ([^\s,]+)/g),
].map((match) => match[1]);
const finalizationVerified =
  finalizationStatuses.includes("finalized") &&
  !finalizationStatuses.includes("error");
Object.assign(run, {
  endedAt: new Date().toISOString(),
  elapsedSeconds: (Date.now() - Date.parse(startedAt)) / 1000,
  status: code === 0 && backendPassed && realResponseVerified && finalizationVerified ? "passed" : skipped ? "skipped" : "failed",
  exitCode: code,
  signal,
  realPatientResponseVerified: realResponseVerified,
  backendPassed,
  finalizationStatuses,
  finalizationVerified,
});
writeFileSync(statusPath, JSON.stringify(run, null, 2));
console.log(JSON.stringify(run, null, 2));
process.exitCode = run.status === "passed" ? 0 : 1;
